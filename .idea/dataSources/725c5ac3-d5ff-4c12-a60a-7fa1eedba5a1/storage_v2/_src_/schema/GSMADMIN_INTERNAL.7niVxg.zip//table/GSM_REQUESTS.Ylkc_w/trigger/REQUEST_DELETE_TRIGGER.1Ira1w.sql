create trigger REQUEST_DELETE_TRIGGER
    after delete
    on GSM_REQUESTS
    for each row
    dbms_gsm_pooladmin.requestDelete(:old.change_seq#, :old.request, :old.status);
/

