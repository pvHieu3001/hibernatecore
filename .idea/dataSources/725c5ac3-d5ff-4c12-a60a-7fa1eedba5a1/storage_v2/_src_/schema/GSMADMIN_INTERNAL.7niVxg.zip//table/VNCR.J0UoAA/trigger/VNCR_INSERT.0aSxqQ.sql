create trigger VNCR_INSERT
    before insert or update
    on VNCR
    for each row
BEGIN
  IF :new.hostid IS NULL THEN
    :new.hostid := VNCR_SEQUENCE.NEXTVAL;
  END IF;
END;
/

