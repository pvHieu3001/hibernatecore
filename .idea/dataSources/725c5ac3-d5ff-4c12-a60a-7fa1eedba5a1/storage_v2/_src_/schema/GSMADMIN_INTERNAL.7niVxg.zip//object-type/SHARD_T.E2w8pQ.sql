create type shard_t force as object (
  db_id NUMBER,
  conn_str VARCHAR2(256),
  chunks number_list
);
/

