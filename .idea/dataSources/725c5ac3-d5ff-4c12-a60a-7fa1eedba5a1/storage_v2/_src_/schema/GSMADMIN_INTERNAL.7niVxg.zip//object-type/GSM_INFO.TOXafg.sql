create TYPE gsm_info IS OBJECT (
                         cloud_name     varchar2(128),
                         dbpool_name    varchar2(128),
                         region_name    varchar2(128),
                         database_num   number,
                         gsm_list       gsm_list_t,
                         instance_list  instance_list_t,
                         region_list    region_list_t,
                         service_list   service_list_t,
                         scan_name      varchar2(128),
                         ons_port       number,
                         dbrole         varchar(30),
                         cpu_threshold  number,
                         srlat_threshold number,
                         db_vers        number,
                         ddl_id number,
                         minobj_num number,
                         maxobj_num number,
                         reptype number,
                         file_convert varchar2(512),
                         file_dest varchar2(512),
                         chunk_list chunkrange_list_t,
  CONSTRUCTOR FUNCTION gsm_info (SELF IN OUT NOCOPY gsm_info)
                                     RETURN SELF AS RESULT);
/

