create type BODY service_dsc_t AS
  CONSTRUCTOR FUNCTION service_dsc_t (SELF IN OUT NOCOPY service_dsc_t,
                                      name VARCHAR2 )
                                     RETURN SELF AS RESULT IS
  BEGIN
    SELF.service_name := name;
    RETURN;
  END;
END;
/

