create TYPE chunkrange_t FORCE IS OBJECT (
                                         chk_from  number,
                                         chk_to    number );
/

