create TYPE param_value_t FORCE is OBJECT (value_string varchar2(1024));
/

