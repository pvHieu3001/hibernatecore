create trigger CAT_ROLLBACK_TRIGGER
    after update of STATUS
    on GSM_REQUESTS
    for each row
    when (new.status = 'A')
    dbms_gsm_pooladmin.catRollback(:new.request, :new.old_instances);
/

