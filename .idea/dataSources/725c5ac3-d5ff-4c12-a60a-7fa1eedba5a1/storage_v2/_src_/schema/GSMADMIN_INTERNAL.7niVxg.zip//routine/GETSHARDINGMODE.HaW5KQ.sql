create FUNCTION getShardingMode wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
86 c2
jLzAQnSa09Dpmv5I0aMiIW7JXN8wg2JHr54VfHSpOHIQGEuxpYniLY48V/Ezjz7n/T1qG02P
HmRbciS1vyZ6p/UBER7qLP7+m2i6P2LVV2sJAvvdSWC+kwbm9zZpVUZ21WCss3/JrGtz3x6p
EPmseZAEaIk00pSscifMA0TQqElhHGhfJZrmUcHr+2pzFvM=
/

