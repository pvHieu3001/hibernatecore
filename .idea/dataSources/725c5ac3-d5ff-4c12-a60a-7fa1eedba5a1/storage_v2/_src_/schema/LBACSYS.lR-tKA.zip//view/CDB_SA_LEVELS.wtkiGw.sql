create view CDB_SA_LEVELS as
SELECT k."POLICY_NAME",k."LEVEL_NUM",k."SHORT_NAME",k."LONG_NAME",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_LEVELS") k
/

comment on table CDB_SA_LEVELS is ' in all containers'
/

comment on column CDB_SA_LEVELS.CON_ID is 'container id'
/

