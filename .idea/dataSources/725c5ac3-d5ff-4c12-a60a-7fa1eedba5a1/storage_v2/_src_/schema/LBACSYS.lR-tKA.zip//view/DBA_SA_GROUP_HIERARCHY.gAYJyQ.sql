create view DBA_SA_GROUP_HIERARCHY as
SELECT l.pol_name AS policy_name, g.hierarchy_level, g.group_name
   FROM ( SELECT LEVEL AS hierarchy_level,
            RPAD(' ',2*LEVEL,' ') || code || ' - ' ||  name AS group_name,
            pol#
        FROM LBACSYS.ols$groups
        CONNECT BY PRIOR pol#=pol# AND PRIOR group#=parent#
        START WITH parent# IS NULL) g, LBACSYS.ols$pol l
   WHERE g.pol#=l.pol#
/

