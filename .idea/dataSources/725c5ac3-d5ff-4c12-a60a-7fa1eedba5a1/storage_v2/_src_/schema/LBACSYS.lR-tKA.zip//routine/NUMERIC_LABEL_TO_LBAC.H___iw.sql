create FUNCTION         numeric_label_to_lbac wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
c7 c2
upTRggyC+IfLmBwo5syItK3VHbwwg8eZgcfLCNL+XoXV1y5il1lKcqFZ8tf0lvrQcqHyWStQ
jwnd4eTmEEzWepCGEHaQcRCOenNn4dziNexxNeKoazU/niLcSv+v968jyqvoFnXZ+j1V6ygR
HNzpIz/i7gjn4jkYKuw8ceI/0U0rxgfO1j26gqamgX4qJA==
/

