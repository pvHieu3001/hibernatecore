create view DBA_SA_DATA_LABELS as
SELECT l.policy_name, label, label_tag
   FROM LBACSYS.dba_lbac_data_labels l, LBACSYS.dba_lbac_policies p
   WHERE l.policy_name = p.policy_name AND
         p.package = 'LBAC$SA'
/

