create view DBA_SA_USER_GROUPS as
SELECT p.pol_name AS policy_name, ug.usr_name AS user_name,
        g.code AS grp, DECODE(ug.rw_access,'1','WRITE','READ') AS rw_access,
        ug.def_group, ug.row_group
   FROM LBACSYS.ols$pol p, LBACSYS.ols$user_groups ug, LBACSYS.ols$groups g
   WHERE p.pol#=ug.pol# AND ug.pol#=g.pol# AND ug.group# = g.group#
/

