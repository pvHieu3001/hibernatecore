create FUNCTION         fetch_ilabel wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
188 130
eNleH1H3QFawcG+ClPe+NsZp+3YwgxDQf5kVfC8CkPjVSgYOyssGi/X0LRzbCnEJDdHpY1HI
s/oPICfVrE0xuRKc/hlinjxBwEDHENpM5fZXdh7I3f54yjNgBHkBzIiZ20s1swyJ+nzzhplC
1kZ2VF3Y3UepSHaI6jklEud/7+hMan8assQaNmM2CmmYJfDHHpKznRhoeJKn5NP1HIy/ckLw
05Dg81vWYd5JSoMpjBpO5m7wIi0qbukPgBJec86heknwIh+4JyU79eqfHrWB6kbsP/MFo2Is
/yMoJGyHUw==
/

