create FUNCTION         to_numeric_data_label wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
199 128
betfCcZ/q0BedMGPUNVzO5XjiGAwg42uLpmsZy/NNJ3g0J4lawslOHc9bzzMM+99oFRC59jK
irXE9m8yaRHRgmoSIBk0aHDlQgKgnTEehiUZcoASJ5LUn9drzeeQ2A7iNq7+b2uRie9VN1nE
yuqzX2BnFUZco8BW+esRFuQGIQ1pp4zJRLchC60Eaz6rqOZmWN/TVQkby4YY4zYJSb94aA4z
JymYpMvUFDhEgLv4yTt4LEHiimfXZ2pttZDfkvp//vjDiXwzUQias5oTexa4BGpWh3r7RaJx
+Q==
/

