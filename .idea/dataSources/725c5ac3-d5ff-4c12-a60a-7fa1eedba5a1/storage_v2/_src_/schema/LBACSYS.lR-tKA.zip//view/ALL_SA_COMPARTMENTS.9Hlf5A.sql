create view ALL_SA_COMPARTMENTS as
SELECT p.pol_name as policy_name, c.comp# AS comp_num,
          c.code AS short_name, c.name AS long_name
     FROM LBACSYS.sa$pol p, LBACSYS.ols$compartments c
    WHERE p.pol# = c.pol#
      and (p.pol# in (select pol# from LBACSYS.sa$admin
                      where usr_name = SYS_CONTEXT('USERENV', 'CURRENT_USER'))
           OR
          (c.pol#,c.comp#) in (select pol#,comp#
                               from LBACSYS.ols$user_compartments
                            where usr_name = lbacsys.sa_session.sa_user_name(
                                    lbacsys.lbac_cache.policy_name(pol#))))
/

