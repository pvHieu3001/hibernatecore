create FUNCTION         to_numeric_label wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
23f 124
AW13rtr9d4O8hwYnYBzVEjn8/7Iwg9fIAJkVZ3RAkLvqkdiPXaN24nmjHX9isdqvKWlSL+Sm
s7W7DZQk3RhIyb03/qEZeL63dwk+uCKSagGdrXmxP8RxeZ+eksWs5ZHyH4fSdPtacOIuez3J
evwHplRJhbxhQBrO88JFEUCmXHES021Eq4V8sUpi4wscxdY8WB83UaNsVMhGHYmE0rQqKQRL
XokzkrJhYx94hIQmu9vXG+/sjLDbLHO80PhsJewY1m++1CSbMqpxF9zCpf9UAhwo4nMqMHM=

/

