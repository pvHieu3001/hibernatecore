create view SA$POL as
SELECT pol#,
       pol_name,
       column_name,
       DECODE(bitand(flags,1),0,'DISABLED',1,'ENABLED','ERROR') AS status,
       LBACSYS.lbac_cache.option_string(options) AS policy_options,
       pol_role as Admin_Role
  FROM LBACSYS.ols$pol
 WHERE package = 'LBAC$SA'
/

