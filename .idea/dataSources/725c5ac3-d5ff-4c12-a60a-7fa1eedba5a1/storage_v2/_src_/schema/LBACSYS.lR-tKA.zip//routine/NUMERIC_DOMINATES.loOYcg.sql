create FUNCTION         numeric_dominates wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
11f f3
f8t+hydnTJ1OL1NZdD1SHMsavF8wg41KmJ7WZy/pXrvqWSbK0+ujzfwROTzzM8wa8XBWViHI
xrUX6aFanFmCRzcSiytBmYBiauRuQAW0v5weIf/BxrjQNuRlo8V3iC8d+GBrofnjpCItVAT1
GbjKy/YhZysW2PQfpFwOjVaK+ugrnxkpoH794ClQYB61kYGVj0qFutYudUPZ8IMGeJpkbtkO
cpXChLYhw/UgQrwS+9wUJMg=
/

