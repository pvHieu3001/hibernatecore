create FUNCTION         numeric_least_ubound wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
110 e3
BBkxjyz9MuHyBOGGsH/iP/VJVQowg41K2Z4VfC/pTMHVwlkO50XNxd6Astu9Xe6fUIMCDpR3
5J2znjImA+3BaNoKRi4hyzrIlnPNd7O+mposiSixenZEhp1PXKuKrP1ddWGrz4HENG6R+nrb
Xfe7iSDfl5wWfLL21mOBtpTTNN59zQn10uHpaYlRkLppqAkl0TjV1LHlUqKX7Ptht/npPANJ
iG8iPQ==
/

