create TYPE         LDAP_ATTR wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
103 c2
M1zw2o5g8B598zpAC0ajSw4L4qYwg5n0dLhcpVJSdOO/dL29Cbh0K6W/m8Ayy8xQacqmU90U
Wuo0T4xk1VlXR3+FMWp/hVpqhXdZXluhzHWMrk3VRWa2HR0djlzcWpduz+SQfFnj/lKBHZ4w
kgJTRZg5qAwHqTThRHzejheSkpjb+FsOFo8loMmmptU43/o=
/

