create view CDB_SA_PROGRAMS as
SELECT k."SCHEMA_NAME",k."PROGRAM_NAME",k."POLICY_NAME",k."PROG_PRIVILEGES",k."PROG_LABELS",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_SA_PROGRAMS") k
/

comment on table CDB_SA_PROGRAMS is ' in all containers'
/

comment on column CDB_SA_PROGRAMS.CON_ID is 'container id'
/

