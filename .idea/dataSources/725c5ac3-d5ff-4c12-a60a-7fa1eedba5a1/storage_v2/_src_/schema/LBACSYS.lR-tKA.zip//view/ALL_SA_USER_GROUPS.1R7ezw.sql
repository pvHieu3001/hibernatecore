create view ALL_SA_USER_GROUPS as
SELECT p.pol_name AS policy_name, ug.usr_name AS user_name,
          g.code AS grp, DECODE(ug.rw_access,'1','WRITE','READ') AS rw_access,
          ug.def_group, ug.row_group
     FROM LBACSYS.sa$pol p, LBACSYS.ols$user_groups ug, LBACSYS.ols$groups g
    WHERE p.pol#=ug.pol#
      AND ug.pol#=g.pol#
      AND ug.group# = g.group#
      AND (p.pol# in (select pol# from LBACSYS.sa$admin
                      where usr_name = SYS_CONTEXT('USERENV', 'CURRENT_USER'))
           or
           ug.usr_name = lbacsys.sa_session.sa_user_name(
                         lbacsys.lbac_cache.policy_name(p.pol#)))
/

