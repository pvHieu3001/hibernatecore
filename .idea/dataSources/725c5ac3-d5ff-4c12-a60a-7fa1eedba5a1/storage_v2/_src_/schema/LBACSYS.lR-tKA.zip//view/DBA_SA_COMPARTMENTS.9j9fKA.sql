create view DBA_SA_COMPARTMENTS as
SELECT p.pol_name AS policy_name, c.comp# AS comp_num,
          c.code AS short_name, c.name AS long_name
   FROM LBACSYS.ols$pol p, LBACSYS.ols$compartments c
   WHERE p.pol# = c.pol#
/

