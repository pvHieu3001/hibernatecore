create view DBA_SA_PROG_PRIVS as
SELECT owner as schema_name, pgm_name AS program_name,
         pol_name AS policy_name,
         LBACSYS.privs_to_char_n(privs) AS program_privileges
  FROM LBACSYS.ols$pol p, LBACSYS.ols$prog g
  WHERE p.pol# = g.pol#
/

