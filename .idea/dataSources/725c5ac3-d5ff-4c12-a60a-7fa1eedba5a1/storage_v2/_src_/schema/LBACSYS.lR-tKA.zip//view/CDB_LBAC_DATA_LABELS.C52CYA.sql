create view CDB_LBAC_DATA_LABELS as
SELECT k."POLICY_NAME",k."LABEL",k."LABEL_TAG",k."CON_ID", k.CON$NAME, k.CDB$NAME, k.CON$ERRNUM, k.CON$ERRMSG FROM CONTAINERS("LBACSYS"."DBA_LBAC_DATA_LABELS") k
/

comment on table CDB_LBAC_DATA_LABELS is ' in all containers'
/

comment on column CDB_LBAC_DATA_LABELS.CON_ID is 'container id'
/

