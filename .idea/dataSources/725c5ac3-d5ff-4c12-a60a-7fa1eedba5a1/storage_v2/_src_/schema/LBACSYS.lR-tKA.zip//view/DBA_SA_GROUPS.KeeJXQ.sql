create view DBA_SA_GROUPS as
SELECT p.pol_name AS policy_name, g.group# AS group_num,
          g.code AS short_name, g.name AS long_name,
          g.parent# AS parent_num, pg.code AS parent_name
   FROM LBACSYS.ols$pol p, LBACSYS.ols$groups g, LBACSYS.ols$groups pg
   WHERE p.pol# = g.pol# AND
         g.pol# = pg.pol# (+) AND
         g.parent# = pg.group#(+)
/

