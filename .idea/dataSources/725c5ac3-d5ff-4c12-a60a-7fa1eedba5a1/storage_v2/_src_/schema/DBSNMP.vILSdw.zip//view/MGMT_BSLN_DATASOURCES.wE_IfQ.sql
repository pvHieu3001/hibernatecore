create view MGMT_BSLN_DATASOURCES
            (DATASOURCE_GUID, SOURCE_TYPE, TARGET_UID, METRIC_UID, TARGET_GUID, METRIC_GUID, KEY_VALUE, DBID,
             INSTANCE_NUM, INSTANCE_NAME, METRIC_ID)
as
select bsln.datasource_guid(bsln.target_uid(d.dbid, i.instance_number),
                            bsln.metric_uid(bmd.metric_id))
      ,'DB'
      ,bsln.target_uid(d.dbid, i.instance_number)
      ,bsln.metric_uid(bmd.metric_id)
      ,null
      ,null
      ,null
      ,d.dbid
      ,i.instance_number
      ,i.instance_name
      ,bmd.metric_id
  from gv$database d, gv$instance i, bsln_metric_defaults bmd
/

comment on table MGMT_BSLN_DATASOURCES is 'Registered Metric Baseline Datasources (10.2)'
/

