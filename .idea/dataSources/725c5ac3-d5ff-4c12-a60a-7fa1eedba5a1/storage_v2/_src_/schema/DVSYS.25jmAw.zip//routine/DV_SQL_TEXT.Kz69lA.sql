create function       DV_SQL_TEXT return VARCHAR2 as
begin
  -- Fix for Bug 6068504
  return SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'SQL_TEXT');
end;
/

