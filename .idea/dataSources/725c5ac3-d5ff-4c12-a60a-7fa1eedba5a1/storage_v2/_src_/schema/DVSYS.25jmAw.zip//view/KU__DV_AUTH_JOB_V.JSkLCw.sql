create view KU$_DV_AUTH_JOB_V (VERS_MAJOR, VERS_MINOR, OIDVAL, GRANTEE_NAME, SCHEMA_NAME) as
select '0','0',sys_guid(),
          j.grantee,
          j.schema
  from    dvsys.dba_dv_job_auth j
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

