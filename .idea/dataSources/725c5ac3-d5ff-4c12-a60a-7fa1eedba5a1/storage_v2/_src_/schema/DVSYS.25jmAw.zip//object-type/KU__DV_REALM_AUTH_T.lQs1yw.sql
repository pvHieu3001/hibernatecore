create type       ku$_dv_realm_auth_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  realm_name    varchar2(128),              /* name of database vault realm */
  grantee       varchar2(128),        /* owner of (or participant in) realm */
  rule_set_name varchar2(128),     /* rule set used to authorize (optional) */
  auth_options  varchar2(42),       /* authorization (participant or owner) */
  auth_scope    number                         /* realm authorization scope */
)
/

