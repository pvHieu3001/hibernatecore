create type       ku$_dv_index_func_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  object_name   varchar2(128)                           /* name of function */
)
/

