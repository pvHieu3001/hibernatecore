create view DBA_DV_PUB_PRIVS (USERNAME, ACCESS_TYPE, PRIVILEGE, OWNER, OBJECT_NAME) as
SELECT
      'PUBLIC'
    , decode(oa.grantee#,1,'DIRECT',ue.name)
    , tpm.name
    , u.name
    , o.name
FROM sys.objauth$ oa,
    sys.obj$ o,
    sys."_BASE_USER" u,
    sys."_BASE_USER" ue,
    sys.table_privilege_map tpm
WHERE oa.obj# = o.obj#
  AND oa.col# IS NULL
  AND oa.privilege# = tpm.privilege
  AND u.user# = o.owner#
  AND oa.grantee# = ue.user#
  AND (oa.grantee# = 1
        or
       oa.grantee# in (SELECT /*+ connect_by_filtering */ DISTINCT privilege#
                        FROM (select * from sys.sysauth$ where privilege#>0)
                        CONNECT BY grantee#=prior privilege#
                        START WITH grantee#=1))
/

