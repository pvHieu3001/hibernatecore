create type         "SYS_YOID0000073139$"              as object( "SYS_NC00001$" VARCHAR2(128 BYTE))
/

