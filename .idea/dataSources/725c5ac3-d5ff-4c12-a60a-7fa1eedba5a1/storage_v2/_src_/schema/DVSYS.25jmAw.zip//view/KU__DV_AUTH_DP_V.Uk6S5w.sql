create view KU$_DV_AUTH_DP_V (VERS_MAJOR, VERS_MINOR, OIDVAL, GRANTEE_NAME, SCHEMA_NAME, OBJECT_NAME, ACTION) as
select '0','0', sys_guid(),
          d.grantee,
          d.schema,
          d.object,
          d.action
  from    dvsys.dba_dv_datapump_auth d
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

