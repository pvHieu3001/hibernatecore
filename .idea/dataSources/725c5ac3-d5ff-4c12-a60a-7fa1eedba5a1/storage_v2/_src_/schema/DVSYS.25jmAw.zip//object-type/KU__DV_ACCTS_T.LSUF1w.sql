create type       ku$_dv_accts_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  state         varchar2(128)                   /* DVSYS/DVF Accounts state */
)
/

