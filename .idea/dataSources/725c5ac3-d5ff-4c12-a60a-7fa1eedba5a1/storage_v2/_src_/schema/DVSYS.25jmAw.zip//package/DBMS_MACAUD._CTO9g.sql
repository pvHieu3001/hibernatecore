create PACKAGE       dbms_macaud AS

  /*********************/
  /*  Global Constants */
  /*********************/

  PROCEDURE create_admin_audit(actcode  IN PLS_INTEGER,
                               actobjnm IN varchar2,
                               actobjid IN PLS_INTEGER,
                               actcmd   IN varchar2,
                               retcode  IN PLS_INTEGER,
                               rsetid   IN PLS_INTEGER,
                               comment  IN varchar2);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_admin_audit, AUTO);

END;
/

