create view EVENT_STATUS as
SELECT "EVENT","ENABLED" FROM TABLE(DVSYS.dbms_macutl.get_event_status())
/

