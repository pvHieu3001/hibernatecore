create type         "SYS_YOID0000073049$"              as object( "SYS_NC00001$" CHARACTER(1 BYTE))
/

