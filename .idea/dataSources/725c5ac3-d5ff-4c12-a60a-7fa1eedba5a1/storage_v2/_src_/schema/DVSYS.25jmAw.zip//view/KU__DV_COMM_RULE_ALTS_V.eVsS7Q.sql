create view KU$_DV_COMM_RULE_ALTS_V
            (VERS_MAJOR, VERS_MINOR, OIDVAL, COMMAND, RULE_SET_NAME, OBJECT_OWNER, OBJECT_NAME, ENABLED, CLAUSE_NAME,
             PARAMETER_NAME, EVENT_NAME, COMPONENT_NAME, ACTION_NAME, SCOPE)
as
select '0','0',sys_guid(),
          cvcr.command,
          cvcr.rule_set_name,
          '%',
          '%',
          cvcr.enabled,
          cvcr.clause_name,
          cvcr.parameter_name,
          cvcr.event_name,
          cvcr.component_name,
          cvcr.action_name,
          decode(cr.scope, 1, 1,
                           2, 2,
                           3, 2)
  from    dvsys.dv$command_rule cvcr, dvsys.command_rule$ cr
  where   cvcr.id# >= 5000 and cvcr.id# = cr.id#
    and   (cvcr.command = 'ALTER SYSTEM' or cvcr.command = 'ALTER SESSION')
    and   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

