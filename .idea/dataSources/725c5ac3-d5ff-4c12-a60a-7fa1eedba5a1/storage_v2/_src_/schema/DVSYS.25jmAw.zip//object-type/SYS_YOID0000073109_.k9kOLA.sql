create type         "SYS_YOID0000073109$"              as object( "SYS_NC00001$" VARCHAR2(128 BYTE), "SYS_NC00002$" VARCHAR2(128 BYTE))
/

