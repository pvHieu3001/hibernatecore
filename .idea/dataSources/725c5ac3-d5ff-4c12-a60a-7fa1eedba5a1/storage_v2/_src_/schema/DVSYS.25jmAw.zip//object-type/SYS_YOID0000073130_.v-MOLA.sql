create type         "SYS_YOID0000073130$"              as object( "SYS_NC00001$" RAW(16))
/

