create view DBA_DV_STATUS as
select 'DV_CONFIGURE_STATUS' as name,
       DECODE(status, '1', 'TRUE', 'FALSE') as status
from dvsys.config$
union
select 'DV_ENABLE_STATUS' AS name, value AS status
from sys.v_$option
where parameter = 'Oracle Database Vault'
/

