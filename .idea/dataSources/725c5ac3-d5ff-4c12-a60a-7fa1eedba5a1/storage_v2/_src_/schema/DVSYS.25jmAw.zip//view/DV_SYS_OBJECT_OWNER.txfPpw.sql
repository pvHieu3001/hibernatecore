create view DV$SYS_OBJECT_OWNER as
SELECT
      u.username
FROM sys.dba_users u
/

