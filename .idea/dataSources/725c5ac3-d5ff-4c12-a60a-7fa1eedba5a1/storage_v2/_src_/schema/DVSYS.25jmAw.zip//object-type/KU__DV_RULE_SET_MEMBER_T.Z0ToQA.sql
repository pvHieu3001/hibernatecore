create type       ku$_dv_rule_set_member_t as object
(
  vers_major      char(1),                           /* UDT major version # */
  vers_minor      char(1),                           /* UDT minor version # */
  oidval          raw(16),                                     /* unique id */
  rule_set_name   varchar2(128),                        /* name of Rule Set */
  rule_name       varchar2(128),                            /* name of Rule */
  rule_order      number,                         /* unused in this release */
  enabled         varchar2(1)       /* the Rule Set is enabled ('Y' or 'N') */
)
/

