create view KU$_DV_ORADEBUG_V (VERS_MAJOR, VERS_MINOR, STATE) as
select '0','0',
          o.state
  from    dvsys.dba_dv_oradebug o
  where   (SYS_CONTEXT('USERENV','CURRENT_USERID') = 1279990
           or exists ( select 1
                         from sys.session_roles
                        where role='DV_OWNER' ))
/

