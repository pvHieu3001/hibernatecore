create view DBA_DV_DBREPLAY_AUTH as
SELECT
    u1.name
FROM dvsys.dv_auth$ da,
     (select user#, name from sys."_BASE_USER"
      union
      select id as user#, name from sys.xs$obj where type = 1) u1
WHERE da.grant_type = 'DBREPLAY' and da.grantee_id = u1.user#
/

