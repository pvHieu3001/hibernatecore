create type       ku$_dv_command_rule_t as object
(
  vers_major      char(1),                           /* UDT major version # */
  vers_minor      char(1),                           /* UDT minor version # */
  oidval          raw(16),                                     /* unique id */
  command         varchar2(128),                /* SQL statement to protect */
  rule_set_name   varchar2(128),                        /* name of Rule Set */
  object_owner    varchar2(128),                            /* schema owner */
  object_name     varchar2(128),       /* object name (may be wildcard '%') */
  enabled         varchar2(1),  /* the Command Rule is enabled ('Y' or 'N') */
  scope           number
)
/

