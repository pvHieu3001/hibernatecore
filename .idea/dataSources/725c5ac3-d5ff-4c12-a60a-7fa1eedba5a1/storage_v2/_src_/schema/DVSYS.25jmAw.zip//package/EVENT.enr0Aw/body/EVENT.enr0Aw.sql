create PACKAGE BODY       event AS

 PROCEDURE set_c (P_SYSEVENT        VARCHAR2,
                  P_LOGIN_USER      VARCHAR2,
                  P_INSTANCE_NUM    VARCHAR2,
                  P_DATABASE_NAME   VARCHAR2,
                  P_DICT_OBJ_TYPE   VARCHAR2,
                  P_DICT_OBJ_OWNER  VARCHAR2,
                  P_DICT_OBJ_NAME   VARCHAR2,
                  P_SQL_TEXT        VARCHAR2)
 IS LANGUAGE C
   NAME "kzvdvssetup"
   LIBRARY DVSYS.KZV$RUL_LIBT
   WITH CONTEXT
   PARAMETERS (CONTEXT,
               P_SYSEVENT, P_SYSEVENT INDICATOR,
               P_LOGIN_USER, P_LOGIN_USER INDICATOR,
               P_INSTANCE_NUM, P_INSTANCE_NUM INDICATOR,
               P_DATABASE_NAME, P_DATABASE_NAME INDICATOR,
               P_DICT_OBJ_TYPE, P_DICT_OBJ_TYPE INDICATOR,
               P_DICT_OBJ_OWNER, P_DICT_OBJ_OWNER INDICATOR,
               P_DICT_OBJ_NAME, P_DICT_OBJ_NAME INDICATOR,
               P_SQL_TEXT, P_SQL_TEXT INDICATOR);

 PROCEDURE set (P_SYSEVENT        VARCHAR2,
                P_LOGIN_USER      VARCHAR2,
                P_INSTANCE_NUM    NUMBER,
                P_DATABASE_NAME   VARCHAR2,
                P_DICT_OBJ_TYPE   VARCHAR2,
                P_DICT_OBJ_OWNER  VARCHAR2,
                P_DICT_OBJ_NAME   VARCHAR2,
                P_SQL_TEXT        VARCHAR2) AS
   l_loginuser VARCHAR2(128);
   l_instancenum VARCHAR2(100);
   l_sqltext VARCHAR2(4000);
 BEGIN
   IF (P_LOGIN_USER IS NULL) OR (LENGTH(P_LOGIN_USER) = 0) THEN
      l_loginuser := SYS_CONTEXT ( 'USERENV','SESSION_USER' );
   ELSE
      l_loginuser := P_LOGIN_USER;
   END IF;

   l_instancenum := TO_CHAR(P_INSTANCE_NUM);

   IF (P_SQL_TEXT IS NOT NULL) THEN
      l_sqltext := SUBSTRB(UPPER(P_SQL_TEXT), 1, 4000);
   ELSE
      l_sqltext := '';
   END IF;

   dvsys.event.set_c(P_SYSEVENT, l_loginuser, l_instancenum, P_DATABASE_NAME,
                     P_DICT_OBJ_TYPE, P_DICT_OBJ_OWNER, P_DICT_OBJ_NAME, l_sqltext);
 END;

 PROCEDURE setdefault AS
 BEGIN
   dvsys.event.set(SYS.SYSEVENT, SYS.LOGIN_USER, SYS.INSTANCE_NUM, SYS.DATABASE_NAME,
                   SYS.DICTIONARY_OBJ_TYPE, SYS.DICTIONARY_OBJ_OWNER, SYS.DICTIONARY_OBJ_NAME, '');
 END;
END event;
/

