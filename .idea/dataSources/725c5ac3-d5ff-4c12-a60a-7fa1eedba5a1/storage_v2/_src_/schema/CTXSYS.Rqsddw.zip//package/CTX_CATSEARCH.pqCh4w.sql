create package ctx_catsearch authid current_user as

function catsearch(
  Colval  in     varchar2,
  Text    in     varchar2,
  condcls in     varchar2,
  ia      in     sys.odciindexctx,
  sctx    in out CatIndexMethods,
  cflg    in     number
)
  return number parallel_enable is language C
  name "catsearch"
  library dr$lib
  with context
  parameters(
        context,
        Colval,
        Colval INDICATOR,
        Text,
        Text INDICATOR,
        Text LENGTH,
        condcls,
        condcls INDICATOR,
        condcls LENGTH,
        ia,
        ia INDICATOR STRUCT,
        sctx,
        sctx INDICATOR STRUCT,
        cflg,
        cflg INDICATOR,
        return OCINumber
      );

function catsearch(
  Colval  in     varchar2,
  Text    in     clob,
  condcls in     varchar2,
  ia      in     sys.odciindexctx,
  sctx    in out CatIndexMethods,
  cflg    in     number
)
  return number parallel_enable is language C
  name "catsearch_clob"
  library dr$lib
  with context
  parameters(
        context,
        Colval,
        Colval INDICATOR,
        Text,
        Text INDICATOR,
        condcls,
        condcls INDICATOR,
        condcls LENGTH,
        ia,
        ia INDICATOR STRUCT,
        sctx,
        sctx INDICATOR STRUCT,
        cflg,
        cflg INDICATOR,
        return OCINumber
      );

function catsearch(
  Colval  in     clob,
  Text    in     varchar2,
  condcls in     varchar2,
  ia      in     sys.odciindexctx,
  sctx    in out CatIndexMethods,
  cflg    in     number
)
  return number parallel_enable is language C
  name "catsearch"
  library dr$lib
  with context
  parameters(
        context,
        Colval,
        Colval INDICATOR,
        Text,
        Text INDICATOR,
        Text LENGTH,
        condcls,
        condcls INDICATOR,
        condcls LENGTH,
        ia,
        ia INDICATOR STRUCT,
        sctx,
        sctx INDICATOR STRUCT,
        cflg,
        cflg INDICATOR,
        return OCINumber
      );

function catsearch(
  Colval  in     clob,
  Text    in     clob,
  condcls in     varchar2,
  ia      in     sys.odciindexctx,
  sctx    in out CatIndexMethods,
  cflg    in     number
)
  return number parallel_enable is language C
  name "catsearch_clob"
  library dr$lib
  with context
  parameters(
        context,
        Colval,
        Colval INDICATOR,
        Text,
        Text INDICATOR,
        condcls,
        condcls INDICATOR,
        condcls LENGTH,
        ia,
        ia INDICATOR STRUCT,
        sctx,
        sctx INDICATOR STRUCT,
        cflg,
        cflg INDICATOR,
        return OCINumber
      );
end ctx_catsearch;
/

