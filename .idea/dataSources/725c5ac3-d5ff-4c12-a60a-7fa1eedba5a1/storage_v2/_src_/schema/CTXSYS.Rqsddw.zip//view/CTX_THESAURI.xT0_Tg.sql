create view CTX_THESAURI as
select u.name ths_owner,
       ths_name
  from dr$ths, sys."_BASE_USER" u
 where ths_owner# = u.user#
/

