create PACKAGE drvtmt AUTHID current_user AS

type col_phrases IS TABLE OF varchar2(200) INDEX BY BINARY_INTEGER;

FUNCTION noex_tabname(
	l_owner  IN varchar2,
	prx      IN varchar2) return VARCHAR2;

/* validate the result table, if not exists, create one
   The table should have three columns
          cat_id  number,
	  type    number,
	  rule    blob
*/
PROCEDURE model_tab(
	tabname     IN OUT varchar2);

/* validate the table, if not exists, create one
   The table should have three columns
	 docid     number -- document ID to identify a document
	 clusterid number -- the ID of the cluster the document is assigned to
	 score     number -- the similarity score between document and cluster
*/
PROCEDURE doccls_tab(
	tabname     IN OUT varchar2);

/* validate the table, if not exists, create one
   The table should have three columns
	 clusterid number         -- cluster ID to identify a cluster
	 descript  varchar2(4000) -- a string to describe the cluster
         label     varchar2(200)  -- a suggested label for the cluster
         sze       number         -- number of documents assigned to the cluster
	 quality_score number     -- the quality score of the cluster
	 parent    number         -- parent cluster id. negative means no parent
*/
PROCEDURE cluster_tab(
	tabname     IN OUT varchar2);

/* verify the train document tables  */
PROCEDURE verify_traindoc(
	lv_doctab IN OUT varchar2,
	docid     IN     varchar2);

PROCEDURE verify_traincat(
	cattab    IN OUT varchar2,
        catdocid  IN     varchar2,
	catid     IN     varchar2);

/* verify result model table */
PROCEDURE verify_modeltab (
	lv_restab IN OUT varchar2 );

END drvtmt;
/

