create package driload as

/*---------------------------- resolve_sqe --------------------------------*/
/*
  NAME
    resolve_sqe

  NOTES
    TODO: move this to a more appropriate place
*/
FUNCTION resolve_sqe( p_idx_id in number, p_sqe_name in varchar2)
return clob;

/*--------------------------- reverse_pattern -------------------------------*/
/*
  NAME
    reverse_pattern

  NOTES

   Reverse a regular expression pattern.

*/
FUNCTION reverse_pattern(p_str in varchar2)
return varchar2;

/*--------------------------- getleadingchars -------------------------------*/
/*
  NAME
    getleadingchars

  NOTES

   Get the leading alphabetic characters from a regular
   expression string.

*/
FUNCTION getleadingchars(p_str in varchar2)
  return clob;

end driload;
/

