create type          SYS_PLSQL_330A2FA6_131_1 as table of "CTXSYS"."SYS_PLSQL_330A2FA6_106_1";
/

