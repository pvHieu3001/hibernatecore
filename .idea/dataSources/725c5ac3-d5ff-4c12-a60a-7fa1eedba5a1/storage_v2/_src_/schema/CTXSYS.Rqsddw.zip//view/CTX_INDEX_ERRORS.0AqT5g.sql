create view CTX_INDEX_ERRORS as
select u.name         err_index_owner,
       idx_name       err_index_name,
       err_timestamp,
       err_textkey,
       err_text
  from dr$index_error, dr$index, sys."_BASE_USER" u
 where idx_id = err_idx_id
   and idx_owner# = u.user#
/

