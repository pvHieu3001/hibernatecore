create type          SYS_PLSQL_A130829_DUMMY_1 as table of number;
/

