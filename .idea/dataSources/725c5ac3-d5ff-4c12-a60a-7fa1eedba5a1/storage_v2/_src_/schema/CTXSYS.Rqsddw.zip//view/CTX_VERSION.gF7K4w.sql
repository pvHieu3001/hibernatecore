create view CTX_VERSION as
select substr(dri_version,1,10) ver_dict,
substr(dri_version,1,10) ver_code from dual
/

