create type          SYS_PLSQL_330A2FA6_36_1 as table of "CTXSYS"."SYS_PLSQL_330A2FA6_18_1";
/

