create type          SYS_PLSQL_330A2FA6_72_1 as table of "CTXSYS"."SYS_PLSQL_330A2FA6_44_1";
/

