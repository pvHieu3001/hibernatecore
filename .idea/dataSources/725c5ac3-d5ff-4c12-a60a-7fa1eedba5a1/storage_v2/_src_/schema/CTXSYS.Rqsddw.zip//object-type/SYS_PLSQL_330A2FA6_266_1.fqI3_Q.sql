create type          SYS_PLSQL_330A2FA6_266_1 as object (ID NUMBER,
VALUE VARCHAR2(128 BYTE));
/

