create view DRV$DELETE2 as
select "DEL_IDX_ID","DEL_IXP_ID","DEL_DOCID","DEL_UPDATED" from dr$delete
where del_idx_id = SYS_CONTEXT('DR$APPCTX','IDXID')
with check option
/

