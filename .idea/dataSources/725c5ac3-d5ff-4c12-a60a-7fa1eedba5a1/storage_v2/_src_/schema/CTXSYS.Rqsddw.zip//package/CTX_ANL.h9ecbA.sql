create package CTX_ANL authid current_user as
/*
name            IN      A unique name (per user) identifying dictionary.
language        IN      Which language does this dictionary belong to?
dictionary              IN      The actual dictionary
*/

PROCEDURE add_dictionary(name     in VARCHAR2,
                         language in VARCHAR2,
                         dictionary  in CLOB);

PROCEDURE drop_dictionary(name in VARCHAR2);

END CTX_ANL;
/

