create type          SYS_PLSQL_A130829_611_1 as table of "CTXSYS"."SYS_PLSQL_A130829_591_1";
/

