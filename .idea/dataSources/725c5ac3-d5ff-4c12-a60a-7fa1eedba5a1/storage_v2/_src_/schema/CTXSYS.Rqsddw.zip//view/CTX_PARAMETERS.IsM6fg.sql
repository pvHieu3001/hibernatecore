create view CTX_PARAMETERS as
select par_name, par_value
     from dr$parameter
/

