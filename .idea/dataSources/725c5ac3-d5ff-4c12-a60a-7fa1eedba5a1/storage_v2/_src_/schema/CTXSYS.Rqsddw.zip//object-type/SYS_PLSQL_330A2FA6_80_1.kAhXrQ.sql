create type          SYS_PLSQL_330A2FA6_80_1 as object (DOCID NUMBER,
CATID NUMBER,
SCR NUMBER);
/

