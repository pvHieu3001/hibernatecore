create package drirepz as

/*--------------------------- index_size --------------------------------*/

procedure index_size(
  index_name    in varchar2,
  report        in out nocopy clob,
  part_name     in varchar2 default null,
  report_format in varchar2 DEFAULT 'TEXT'
);

/*------------------------ get_gtab_size ---------------------------------*/
procedure get_gtab_size (
  index_name in varchar2,
  partid in number,
  tka   in out number,
  tba   in out number,
  tku   in out number,
  tbu   in out number
);
end drirepz;
/

