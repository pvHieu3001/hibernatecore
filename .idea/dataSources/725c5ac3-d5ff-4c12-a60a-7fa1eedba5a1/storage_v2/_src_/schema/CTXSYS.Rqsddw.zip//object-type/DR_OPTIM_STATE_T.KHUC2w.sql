create type dr$optim_state_t as object(
  session_state   dr$session_state_t,
  optmode         varchar2(256),
  maxtime         varchar2(256),
  maxhash         number,
  ttype           number,
  background      number
);
/

