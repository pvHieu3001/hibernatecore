create type          SYS_PLSQL_330A2FA6_281_1 as table of "CTXSYS"."SYS_PLSQL_330A2FA6_266_1";
/

