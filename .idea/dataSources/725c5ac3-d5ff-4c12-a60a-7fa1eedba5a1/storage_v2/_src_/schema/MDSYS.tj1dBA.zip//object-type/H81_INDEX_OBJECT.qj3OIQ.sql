create type H81_INDEX_OBJECT as OBJECT ( sdo_groupcode RAW(255), sdo_code RAW(255), sdo_maxcode RAW(255), sdo_status varchar2(1))
/

