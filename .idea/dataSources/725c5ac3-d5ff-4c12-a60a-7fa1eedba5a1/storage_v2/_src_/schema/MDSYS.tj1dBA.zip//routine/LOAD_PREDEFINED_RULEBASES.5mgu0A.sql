create PROCEDURE load_predefined_rulebases(
  user_name varchar2
) IS
  predefined_RB_list mdsys.rdf_rulebases :=
    mdsys.rdf_rulebases('RDF','RDFS','RDFS++','OWLSIF','OWLPRIME','SKOSCORE','OWL2RL','OWL2EL');
BEGIN
  mdsys.rdf_apis_internal.create_predefined_RBs(
    user_name, predefined_RB_list);
  mdsys.rdf_apis_internal.grants_for_predefined_RBs(predefined_RB_list);

  mdsys.rdf_apis_internal.populate_RDF_and_RDFS_RBs;
  commit;

   EXCEPTION
        WHEN OTHERS THEN
                MDERR.RAISE_MD_ERROR('MD', 'SDO', -13199, 'RDF: Error in load_predefined_rulebases(): SQLERRM=' || SQLERRM
          || chr(10) || '['
          || chr(10) || dbms_utility.format_error_backtrace
          || chr(10) || ']');
END load_predefined_rulebases;
/

