create type       rdfsa_labelgen authid current_user as object (
  gen_option   NUMBER,

  --
  --- SETDEPRESOURCES : to set the dependent resources for the label
  --- generator. Information about these resources will be passed to the
  --- the getNumericLabel method at runtime
  ---
  --- Usage:  setDepResources(sem_rdfsa.USE_SUBJECT_LABEL+
  ---                         sem_rdfsa.USE_RULE_LABEL)
  --
  final member procedure setDepResources(useres number),

  --
  --- FINDOMINATINGOF : Find a clear dominating label out of the labels
  --- passed in. -1 is returned if a clear dominating label is not found --
  final static function findDominatingOf(labels MDSYS.INT_ARRAY) return number,

  --
  --- GETNUMERICLABEL : Extensible implementations for this type should
  --- override this method to return a custom label based on the resources
  --- passed in. The exact list of resources passed in is dependent on
  --- options passed to the setDepResource method
  --
  member function getNumericLabel (subject   rdfsa_resource,
                                   predicate rdfsa_resource,
                                   object    rdfsa_resource,
                                   rule      rdfsa_resource,
                                   anteced   rdfsa_resource)
       return number

) not final
/

