create TYPE SDO_ROWIDPAIR
AS OBJECT (
        rowid1 varchar2(24),
        rowid2 varchar2(24))
/

