create type prllidx_create authid current_user as object (

      c1 number,

      static function index_merge(
               idxschema IN varchar2,
               idxname   IN varchar2,
               moderr    IN sys.odcinumberlist,
               c1        IN SYS_REFCURSOR) return sys.odcinumberlist
         parallel_enable (partition c1 by any),

      static function index_load(
            filedir   varchar2,
            filterpl  varchar2,
            basepol   sys.ODCIVarchar2List,
            ctxpref   fn_xmlpref,
            extarr    fn_extarr,
            modarr    sys.ODCINumberList,
            polrids   sys.ODCIvarchar2List,
            loadMethod varchar2,
            cur       SYS_REFCURSOR) return  doublenumlist
        parallel_enable (partition cur by any) pipelined
    )
 alter type prllidx_create
      drop static function index_merge(
            idxschema IN varchar2,
            idxname   IN varchar2,
            moderr    IN sys.odcinumberlist,
            c1        IN SYS_REFCURSOR) return sys.odcinumberlist
        parallel_enable (partition c1 by any)
       cascade
 alter type prllidx_create
      drop static function index_load(
            filedir   varchar2,
            filterpl  varchar2,
            basepol   sys.ODCIVarchar2List,
            ctxpref   fn_xmlpref,
            extarr    fn_extarr,
            modarr    sys.ODCINumberList,
            polrids   sys.ODCIvarchar2List,
            loadMethod varchar2,
            cur       SYS_REFCURSOR) return  doublenumlist
        parallel_enable (partition cur by any) pipelined
       cascade
 alter type prllidx_create
      add static function index_merge(
            idxschema IN varchar2,
            idxname   IN varchar2,
            moderr    IN sys.odcinumberlist,
            flags     IN number,
            c1        IN SYS_REFCURSOR) return sys.odcinumberlist
        parallel_enable (partition c1 by any)
       cascade
 alter type prllidx_create
      add static function index_load(
            idxschema IN varchar2,
            idxname   IN varchar2,
            filedir   varchar2,
            filterpl  varchar2,
            basepol   sys.ODCIVarchar2List,
            extrParams sys.ODCIVarchar2List,
            ctxpref   fn_xmlpref,
            extarr    fn_extarr,
            modarr    sys.ODCINumberList,
            polrids   sys.ODCIvarchar2List,
            loadMethod varchar2,
            stagtab_name   varchar2,
            docUri2Rid_name varchar2,
            docVid2Rid_name varchar2,
            is_batchpol     sys.ODCINumberList,
            flags           number,
            cur       SYS_REFCURSOR) return  doublenumlist
        parallel_enable (partition cur by any) pipelined
       cascade
 alter type prllidx_create
      add static function build_index_partition(
            idxinfo sys.ODCIIndexInfo,
            l_modarr sys.ODCINumberList,
            filedir VARCHAR2,
            filterpl varchar2,
            l_basepol sys.ODCIVarchar2List,
            l_extrParams sys.ODCIVarchar2List,
            l_ctxpref fn_xmlpref,
            t_extarr fn_extarr,
            l_polrids sys.ODCIVarchar2List,
            loadMethod   varchar2,
            stagtab_name varchar2,
            docUri2Rid_name varchar2,
            docVid2Rid_name varchar2,
            xinfotab_name   varchar2,
            flags           number) return number
       cascade
 alter type prllidx_create
      add static function build_index_batch_extr(
            idxinfo        sys.ODCIIndexInfo,
            l_modarr       sys.ODCINumberList,
            filedir        varchar2,
            filterpl       varchar2,
            l_basepol      sys.ODCIVarchar2List,
            l_batchpol     sys.ODCINumberList,
            l_extrParams   sys.ODCIVarchar2List,
            l_ctxpref      fn_xmlpref,
            t_extarr       fn_extarr,
            l_polrids      sys.ODCIVarchar2List,
            l_errcnt in out sys.ODCINumberList,
            l_docUriPfx     varchar2,
            l_docUriShortPfx  varchar2,
            loadMethod     varchar2,
            stagtab_name    varchar2,
            l_stagtab_suffixes  sys.ODCIvarchar2List,
            docUri2Rid_name  varchar2,
            docVid2Rid_name  varchar2,
            xinfotab_name   varchar2,
            l_sel_basetab  varchar2,
            flags          number) return number
        cascade
/

