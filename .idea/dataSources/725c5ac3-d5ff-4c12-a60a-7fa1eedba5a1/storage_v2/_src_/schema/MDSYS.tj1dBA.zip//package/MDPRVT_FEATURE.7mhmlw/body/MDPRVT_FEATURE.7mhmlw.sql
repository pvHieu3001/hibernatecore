create PACKAGE BODY       mdprvt_feature wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
255 171
r2qEQw78z4v55KJXBGkDRb/uJacwg+1pNUgVfC+KWOrYU6YJ3HGtYgg5Ky6KEXklwBhR1A5a
Y+Xmj3MqJy8+O4O6/uD2oILagq3U0FNmVKsNAoRzGUGYwMEKuXcjZ9qr+13g4An9qEuXidiZ
WZNrjGWo9ftBM5ZLQOFsh4xHF93faSkx9xFZauoLYHwid7ALDf6LY+7Ex4GDd1zBt3L2hkuJ
mwlpYXCiAfzlDznSZjPbSLIts9FNh35rNvoOILAABET1fAAArBMklX977wOV/nHm1WE1zcTD
v1s/q2Fj17N/6IRmFvK4t3t1EYI6mP0I+Iu0OjO1E766NGP0vBv9jqGjNejAPmg9PAbuHdSu
7F4=
/

