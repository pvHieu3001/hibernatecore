create PACKAGE sdo_rdf AUTHID CURRENT_USER AS

--
--  !!!!! PLEASE READ BEFORE YOU ADD APIS IN THIS PACKAGE !!!!!!!!!!!!
--
--  All APIs in sdo_rdf should be wrapped and duplicated in sdordf.sql
--  That way, we have a consolidated view of sem_apis package
--

 /*---------------------------- Constants --------------------------*/
  XSDNSP                 CONSTANT VARCHAR2(33) := 'http://www.w3.org/2001/XMLSchema#';
  GML31RDFNSP            CONSTANT VARCHAR2(31) := 'http://www.opengis.net/ont/gml#';
  SFRDFNSP               CONSTANT VARCHAR2(30) := 'http://www.opengis.net/ont/sf#';
  GEOSPARQLNSP           CONSTANT VARCHAR2(37) := 'http://www.opengis.net/ont/geosparql#';
  GEOEPSGNSP             CONSTANT VARCHAR2(38) := 'http://www.opengis.net/def/crs/EPSG/0/';
  EPSG_DEFAULT           CONSTANT VARCHAR2(44) := 'http://www.opengis.net/def/crs/OGC/1.3/CRS84';
  ORARDFNSP              CONSTANT VARCHAR2(28) := 'http://xmlns.oracle.com/rdf/';
  ORAGEONSP              CONSTANT VARCHAR2(32) := ORARDFNSP || 'geo/';
  ORAGEOSRIDNSP          CONSTANT VARCHAR2(37) := ORAGEONSP || 'srid/';

  XSD_DECIMAL            CONSTANT VARCHAR2(40) := XSDNSP || 'decimal';
  XSD_DOUBLE             CONSTANT VARCHAR2(39) := XSDNSP || 'double';
  XSD_FLOAT              CONSTANT VARCHAR2(38) := XSDNSP || 'float';
  XSD_INTEGER            CONSTANT VARCHAR2(40) := XSDNSP || 'integer';
  XSD_INT                CONSTANT VARCHAR2(36) := XSDNSP || 'int';
  XSD_NONPOSITIVEINTEGER CONSTANT VARCHAR2(51) := XSDNSP || 'nonPositiveInteger';
  XSD_NEGATIVEINTEGER    CONSTANT VARCHAR2(48) := XSDNSP || 'negativeInteger';
  XSD_LONG               CONSTANT VARCHAR2(37) := XSDNSP || 'long';
  XSD_SHORT              CONSTANT VARCHAR2(38) := XSDNSP || 'short';
  XSD_BYTE               CONSTANT VARCHAR2(37) := XSDNSP || 'byte';
  XSD_NONNEGATIVEINTEGER CONSTANT VARCHAR2(51) := XSDNSP || 'nonNegativeInteger';
  XSD_UNSIGNEDLONG       CONSTANT VARCHAR2(45) := XSDNSP || 'unsignedLong';
  XSD_UNSIGNEDINT        CONSTANT VARCHAR2(44) := XSDNSP || 'unsignedInt';
  XSD_UNSIGNEDSHORT      CONSTANT VARCHAR2(46) := XSDNSP || 'unsignedShort';
  XSD_UNSIGNEDBYTE       CONSTANT VARCHAR2(45) := XSDNSP || 'unsignedByte';
  XSD_POSITIVEINTEGER    CONSTANT VARCHAR2(48) := XSDNSP || 'positiveInteger';
  XSD_BOOLEAN            CONSTANT VARCHAR2(40) := XSDNSP || 'boolean';
  XSD_STRING             CONSTANT VARCHAR2(39) := XSDNSP || 'string';
  XSD_DATE               CONSTANT VARCHAR2(37) := XSDNSP || 'date';
  XSD_TIME               CONSTANT VARCHAR2(37) := XSDNSP || 'time';
  XSD_DATETIME           CONSTANT VARCHAR2(41) := XSDNSP || 'dateTime';
  XSD_DAYTIMEDURATION    CONSTANT VARCHAR2(48) := XSDNSP || 'dayTimeDuration';

  GML31LITERAL           CONSTANT VARCHAR2(47) := GEOSPARQLNSP || 'gmlLiteral';
  OGC_WKT_LITERAL        CONSTANT VARCHAR2(47) := GEOSPARQLNSP || 'wktLiteral';
  ORA_GML31_LIT          CONSTANT VARCHAR2(44) := ORAGEONSP    || 'GML31Literal';
  WKT_LITERAL            CONSTANT VARCHAR2(42) := ORAGEONSP    || 'WKTLiteral';
  WKT_DEFAULT_SRID       CONSTANT NUMBER       := 8307; -- WGS 84 (Long Lat) in that order

  ORATEXT_DTYPE          CONSTANT VARCHAR2(32) := ORARDFNSP || 'text';
  ORALIKE_DTYPE          CONSTANT VARCHAR2(32) := ORARDFNSP || 'like';

  -- max VC2 literal length for SPARQL query functions --
  --SPARQL_MAX_LIT_LEN     CONSTANT INTEGER := 3500;
  SPARQL_MAX_VC_LEN      CONSTANT INTEGER := 4000;

  -- RDB2RDF constants
  RR_TAB_NAME_PREFIX              CONSTANT varchar2(30) := 'RDF_RR$TAB';
  RR_LTC_NAME_PREFIX              CONSTANT varchar2(30) := 'RDF_RR$LTC'; -- description of Logical Table Cols
  RR_TAB_NAME_MIDFMT              CONSTANT varchar2(30) := 'FMXXXXXXXX';

  SAVED_RR_TAB_NAME_PREFIX        CONSTANT varchar2(30) := 'RDF$RR$TAB';
  SAVED_RR_LTC_NAME_PREFIX        CONSTANT varchar2(30) := 'RDF$RR$LTC';

  -- two constants for STATS APIS
  VALUE_TAB_ONLY          CONSTANT VARCHAR2(32) := 'VALUE_TAB_ONLY';
  LINK_TAB_ONLY           CONSTANT VARCHAR2(32) := 'LINK_TAB_ONLY';

 /*---------------------- Procedures and Functions -----------------*/
  FUNCTION raise_parse_error (
    errtext VARCHAR2, lexval VARCHAR2, new_lexval VARCHAR2 default NULL)
  return varchar2 deterministic;
  pragma restrict_references (raise_parse_error,WNDS,RNDS,WNPS,RNPS);

  FUNCTION replace_rdf_prefix (
    string                       VARCHAR2
  , options                      VARCHAR2 default NULL
  ) RETURN                       VARCHAR2 deterministic;
  pragma restrict_references (replace_rdf_prefix,WNDS,RNDS,WNPS,RNPS);

  FUNCTION pov_typed_literal (
    lexval IN     VARCHAR2
  , options IN    VARCHAR2 default NULL
  ) RETURN        VARCHAR2;
  pragma restrict_references (pov_typed_literal,WNDS,RNDS,WNPS);

  FUNCTION get_esc_val (
    lexval varchar2 CHARACTER SET ANY_CS
  , esc_reserved_chars_bit pls_integer default 0
  , options varchar2 default null
  ) RETURN varchar2 CHARACTER SET lexval%CHARSET deterministic parallel_enable;

  FUNCTION url_escape (
    url                   IN VARCHAR2 CHARACTER SET ANY_CS,
    esc_reserved_chars    IN integer  DEFAULT  0,
    url_charset           IN VARCHAR2 DEFAULT  NULL
  )
  RETURN VARCHAR2 deterministic parallel_enable;

  FUNCTION url_unescape (
    url                   IN VARCHAR2 CHARACTER SET ANY_CS,
    url_charset           IN VARCHAR2 DEFAULT  NULL
  )
  RETURN VARCHAR2 deterministic parallel_enable;

  FUNCTION pencd (
    url                   IN VARCHAR2 CHARACTER SET ANY_CS,
    esc_reserved_chars    IN integer  DEFAULT  0,
    url_charset           IN VARCHAR2 DEFAULT  NULL,
    options               IN varchar2 DEFAULT  NULL
  )
  RETURN VARCHAR2 CHARACTER SET url%CHARSET deterministic parallel_enable;

  function tescp (val varchar2 CHARACTER SET ANY_CS, options varchar2 default null) return varchar2 CHARACTER SET val%CHARSET deterministic parallel_enable;
           pragma restrict_references (tescp,WNDS,RNDS,WNPS,RNPS);
  FUNCTION tuesc (val varchar2 CHARACTER SET ANY_CS) return varchar2 CHARACTER SET val%CHARSET deterministic parallel_enable;
           --pragma restrict_references (tuesc,WNDS,RNDS,WNPS,RNPS);

  FUNCTION criri (base_prefix varchar2 CHARACTER SET ANY_CS, val varchar2 CHARACTER SET ANY_CS, num_flag number default 0, options varchar2 default NULL)
           RETURN varchar2 CHARACTER SET val%CHARSET deterministic parallel_enable;
           --pragma restrict_references (criri,WNDS,RNDS,WNPS,RNPS);
  FUNCTION cbnod (val varchar2, options varchar2 default NULL)
           RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (cbnod,WNDS,RNDS,WNPS,RNPS);

  -- these functions return components of a non-CLOB RDF term

  FUNCTION vname (rdfterm varchar2, flags varchar2 default null)
           RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (vname,WNDS,RNDS,WNPS,RNPS);

  FUNCTION vnpfx (rdfterm varchar2, flags varchar2 default null)
           RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (vnpfx,WNDS,RNDS,WNPS,RNPS);

  FUNCTION vnsfx (rdfterm varchar2, flags varchar2 default null)
           RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (vnsfx,WNDS,RNDS,WNPS,RNPS);

  FUNCTION vtype (rdfterm varchar2, flags varchar2 default null)
           RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (vtype,WNDS,RNDS,WNPS,RNPS);

  FUNCTION ltype (rdfterm varchar2, flags varchar2 default null)
           RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (ltype,WNDS,RNDS,WNPS,RNPS);

  FUNCTION latag (rdfterm varchar2, flags varchar2 default null)
           RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (latag,WNDS,RNDS,WNPS,RNPS);

  -- CLOB to VARCHAR2 encoding: used in bulk-load to convert a CLOB value to VARCHAR2 using a specific encoding scheme
  FUNCTION clob2vc (lexval IN CLOB, options varchar2 default NULL)
           RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  -- function to obtain canonical value for a lex value (even if identical)
  FUNCTION get_canon_val (lexval varchar2, flags varchar2 default null) RETURN varchar2 deterministic parallel_enable;
  pragma restrict_references (get_canon_val,WNDS,RNDS,WNPS,RNPS);

  FUNCTION get_roles_and_privs (options varchar2 default NULL) RETURN varchar2;

  FUNCTION checkAppTabPriv (
    owner        IN  varchar2
  , App_Tabname  IN  varchar2
  , App_Colname  IN  varchar2 default NULL
  , options      IN  varchar2 default NULL
  )
  return number;

  -- functions to get in-memory virtual columns
  FUNCTION GetVal(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetPref(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetSuff(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetValTyp(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetOrdTyp(i_id NUMBER)
         RETURN NUMBER DETERMINISTIC parallel_enable;

  FUNCTION GetOrdNum(i_id NUMBER)
         RETURN NUMBER DETERMINISTIC parallel_enable;

  FUNCTION GetOrdDate(i_id NUMBER)
         RETURN TIMESTAMP WITH TIME ZONE DETERMINISTIC parallel_enable;

  FUNCTION GetLitType(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  FUNCTION GetLangType(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC parallel_enable;

  PROCEDURE CREATE_SOURCE_EXTERNAL_TABLE (
    source_table         varchar2
  , def_directory        varchar2
  , log_directory        varchar2 default NULL
  , bad_directory        varchar2 default NULL
  , log_file             varchar2 default NULL
  , bad_file             varchar2 default NULL
  , parallel             PLS_INTEGER default NULL
  , source_table_owner   varchar2 default NULL
  , prep_directory       varchar2 default NULL
  , preprocessor         varchar2 default NULL
  , flags                varchar2 default NULL
  );

  PROCEDURE LOAD_INTO_STAGING_TABLE (
    staging_table        varchar2
  , source_table         varchar2
  , input_format         varchar2 default NULL
  , parallel             PLS_INTEGER default NULL
  , staging_table_owner  varchar2 default NULL
  , source_table_owner   varchar2 default NULL
  , flags                varchar2 default NULL
  );

  PROCEDURE BULK_LOAD_FROM_STAGING_TABLE (
    model_name     IN          varchar2,
    table_owner    IN          varchar2,
    table_name     IN          varchar2,
    flags          IN          varchar2 default NULL,
    debug          IN          PLS_INTEGER default NULL,
    start_comment  IN          varchar2 default NULL,
    end_comment    IN          varchar2 default NULL
  );

  PROCEDURE PRIVILEGE_ON_APP_TABLES (
    command varchar2 default 'GRANT'
  , privilege varchar2 default 'SELECT'
  );

  PROCEDURE PURGE_UNUSED_VALUES (
    flags               IN              varchar2 default NULL
  );

  PROCEDURE RESUME_LOAD_FROM_STAGING_TABLE (
    model_name          IN              varchar2,
    table_owner         IN              varchar2,
    table_name          IN              varchar2,
    session_id          IN              varchar2,
    flags               IN              varchar2 default NULL,
    start_comment       IN              varchar2 default NULL,
    end_comment         IN              varchar2 default NULL
  );

  FUNCTION get_model_id (
    model_name       IN  VARCHAR2
  ) RETURN               NUMBER;

  FUNCTION get_model_name(
    model_id         IN  NUMBER
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
    model_id         IN  NUMBER
  , rdf_t_id         IN  VARCHAR2
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
    model_name       IN  VARCHAR2
  , rdf_t_id         IN  VARCHAR2
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
    model_name           VARCHAR2
  , subject              VARCHAR2
  , property             VARCHAR2
  , object               VARCHAR2
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
      model_id        IN NUMBER
    , subject         IN VARCHAR2
    , property        IN VARCHAR2
    , object          IN VARCHAR2
  ) RETURN               VARCHAR2;


  FUNCTION is_triple (
    model_name           VARCHAR2
  , subject              VARCHAR2
  , property             VARCHAR2
  , object          CLOB
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
      model_id        IN NUMBER
    , subject         IN VARCHAR2
    , property        IN VARCHAR2
    , object     IN CLOB
  ) RETURN               VARCHAR2;

  FUNCTION get_triple_id (
    model_id             NUMBER
  , subject              VARCHAR2
  , property             VARCHAR2
  , object               VARCHAR2
  ) RETURN               VARCHAR2;

  FUNCTION get_triple_id (
    model_name           VARCHAR2
  , subject              VARCHAR2
  , property             VARCHAR2
  , object               VARCHAR2
  ) RETURN               VARCHAR2;


  FUNCTION get_triple_id (
    model_id             NUMBER
  , subject              VARCHAR2
  , property             VARCHAR2
  , object          CLOB
  ) RETURN               VARCHAR2;


  FUNCTION get_triple_id (
    model_name           VARCHAR2
  , subject              VARCHAR2
  , property             VARCHAR2
  , object          CLOB
  ) RETURN               VARCHAR2;


  FUNCTION is_reified_quad (
    model_id                IN  NUMBER
  , subject                 IN  VARCHAR2
  , property                IN  VARCHAR2
  , object                  IN  VARCHAR2
  ) RETURN                      VARCHAR2;

  FUNCTION is_reified_quad (
    model_name              IN  VARCHAR2
  , subject                 IN  VARCHAR2
  , property                IN  VARCHAR2
  , object                  IN  VARCHAR2
  ) RETURN                      VARCHAR2;

  PROCEDURE refresh_sem_tablespace_names (
    model_name                 VARCHAR2 default NULL  -- NULL => all
  );

  FUNCTION get_user_or_dba_schema RETURN VARCHAR2;

  PROCEDURE create_rdf_model (
    model_name          IN  VARCHAR2
  , table_name          IN  VARCHAR2
  , column_name         IN  VARCHAR2
  , model_tablespace    IN  VARCHAR2 default NULL
  , options             IN  VARCHAR2 default NULL
  );
  PROCEDURE drop_rdf_model (model_name IN VARCHAR2);

  PROCEDURE create_sem_model (
    model_name          IN  VARCHAR2
  , table_name          IN  VARCHAR2
  , column_name         IN  VARCHAR2
  , model_tablespace    IN  VARCHAR2 default NULL
  , options             IN  VARCHAR2 default NULL
  );
  PROCEDURE drop_sem_model (model_name IN VARCHAR2);

  /**
   * Note only owner of model and rules index (or dba) is
   * allowed to create a virtual model.
   */
  PROCEDURE create_virtual_model (
    vm_name             IN VARCHAR2
  , models              IN MDSYS.RDF_Models default NULL
  , rulebases           IN MDSYS.RDF_Rulebases default NULL
  , options             IN VARCHAR2 default NULL
  , entailments         IN MDSYS.RDF_Entailments default NULL
  );
  /**
   * Note only owner of virtual model (or dba) is allowed
   * to drop the virtual model.
   */
  PROCEDURE drop_virtual_model (vm_name IN VARCHAR2);

  PROCEDURE create_pg_rdfview (
    model_name          IN VARCHAR2
  , pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE create_pg_rdfview (
    model_name          IN VARCHAR2
  , pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2
  , pg_stag_tab         IN VARCHAR2
  , pg_edge_kv_tab      IN VARCHAR2
  , pg_node_kv_tab      IN VARCHAR2
  , pg_edge_tab         IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_pg_rdfview (
    model_name          IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_pg_rdfview (
    model_name          IN VARCHAR2
  , pg_stag_tab         IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE build_pg_rdfview_indexes (
    pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE build_pg_rdfview_indexes (
    pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2
  , pg_edge_kv_tab      IN VARCHAR2
  , pg_node_kv_tab      IN VARCHAR2
  , pg_edge_tab         IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_pg_rdfview_indexes (
    pg_name             IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  FUNCTION get_RegularExpresion_For(
    regExp_type         VARCHAR2
  )
  RETURN VARCHAR2;

  FUNCTION materialize_error_launch RETURN VARCHAR2;

  -- $$$TBD$$$ temporary begin ----------
  FUNCTION sqlTempl2sqlExpr(
    r2rmlTemplsql       VARCHAR2
  , termType            VARCHAR2
  , alias               VARCHAR2 -- alias_plus_dot
  , notNullColCondExpr IN OUT VARCHAR2
  , ltab_colList        VARCHAR2 default NULL -- for validation: ('col1','col2',...)
  , options             VARCHAR2 default NULL
  ) RETURN              VARCHAR2 deterministic;

  FUNCTION get_RESOURCE_From_Template(
    tabName          IN VARCHAR2
  , template         IN VARCHAR2
  , notNullColCondExpr IN OUT VARCHAR2
  , options             VARCHAR2   default NULL
  ) RETURN              VARCHAR2 deterministic;
  -- $$$TBD$$$ temporary end ----------

  FUNCTION bfloat2LexFloat(val binary_float) RETURN varchar2 deterministic parallel_enable;
  FUNCTION bdouble2LexDouble(val binary_double) RETURN varchar2 deterministic parallel_enable;

  FUNCTION min_frac_sec (lexval varchar) RETURN varchar2 deterministic parallel_enable;
           pragma restrict_references (min_frac_sec,WNDS,RNDS,WNPS,RNPS);

  PROCEDURE export_rdfview_model (
    model_name          IN VARCHAR2
  , rdf_table_owner     IN VARCHAR2 default NULL
  , rdf_table_name      IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE create_rdfview_model (
    model_name          IN VARCHAR2
  , tables              IN SYS.ODCIVarchar2List
  , prefix              IN VARCHAR2 default NULL
  , r2rml_table_owner   IN VARCHAR2 default NULL
  , r2rml_table_name    IN VARCHAR2 default NULL
  , schema_table_owner  IN VARCHAR2 default NULL
  , schema_table_name   IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  , r2rml_string        IN CLOB CHARACTER SET ANY_CS default NULL
  , r2rml_string_fmt    IN VARCHAR2 default NULL
  );

  PROCEDURE drop_rdfview_model (model_name IN VARCHAR2,
                                options IN VARCHAR2 default NULL);

  /**
   * Note only the owner of the model (or dba) is allowed
   * to gather statistics for the model.
   */
  PROCEDURE gather_model_stats (
    model_name     IN VARCHAR2
  , options        IN VARCHAR2 default NULL
  );
  /**
   * Note only the owner of the model (or dba) is allowed
   * to drop statistics for the model.
   */
  PROCEDURE drop_model_stats (
    model_name     IN VARCHAR2
  );
  /**
   * Gets statistics information for the model.  This method is
   * meant to be used internally by SEM_MATCH, and not by a regular
   * user.  Note that any user with select privileges on the model
   * view will have access to the statistics
   */
  FUNCTION get_model_stats (
     model_name       IN VARCHAR2
  ,  stats_type       IN VARCHAR2
  ,  value_ids        IN SYS.ODCINumberList
  ,  options          IN VARCHAR2 default NULL
  )
  RETURN SYS_REFCURSOR;

 /**
  * Applies a sequence of SPARQL 1.1 UPDATE operations
  * to apply_model. Match operations from the WHERE clause
  * are matched against match_models and match_rulebases.
  */
  PROCEDURE update_model (
    apply_model        IN VARCHAR2
  , update_stmt        IN CLOB
  , match_models       IN MDSYS.RDF_Models    default NULL
  , match_rulebases    IN MDSYS.RDF_Rulebases default NULL
  , match_index_status IN VARCHAR2            default NULL
  , match_options      IN VARCHAR2            default NULL
  , options            IN VARCHAR2            default NULL
  );

 /**
  *  Translates a SPARQL query into SQL like SEM_MATCH
  *  table function does, but this one returns the
  *  translated SQL as a CLOB
  */
  FUNCTION sparql_to_sql (
    sparql_query   IN CLOB                CHARACTER SET ANY_CS
  , models         IN MDSYS.RDF_Models
  , rulebases      IN MDSYS.RDF_Rulebases default NULL
  , aliases        IN MDSYS.RDF_Aliases   default NULL
  , index_status   IN VARCHAR2            default NULL
  , options        IN VARCHAR2            default NULL
  , graphs         MDSYS.RDF_Graphs       default NULL
  , named_graphs   MDSYS.RDF_Graphs       default NULL
  )
  RETURN CLOB;

 /**
   * If user has performed a series up id-only updates,
   * blank node identifiers may not be updated. This
   * procedure scans apply_model and resets blank node
   * prefixes according to current prefixing scheme.
   */
  PROCEDURE cleanup_bnodes (
    model_name         IN VARCHAR2
  , tablespace_name    IN VARCHAR2  default NULL
  , options            IN VARCHAR2  default NULL
  );

  /**
  * This procedure performs a delete as insert operation.
  * The model is truncated and everything, except triples
  * in del_tab_name is re-inserted.
  */
  PROCEDURE delete_as_insert (
    model_name         IN VARCHAR2
  , model_id_value     IN NUMBER   default NULL
  , del_tab_name       IN VARCHAR2
  , tablespace_name    IN VARCHAR2 default NULL
  , options            IN VARCHAR2 default NULL
  , mm_options         IN VARCHAR2 default NULL
  );

  /**
   * This procedure creates three required temporary tables for
   * SPARQL_UPDATE: RDF_UPD_INS$, RDF_UPD_INS_CLOB$, RDF_UPD_DEL$
   */
  PROCEDURE create_sparql_update_tables;

  /**
   * This procedure drops three required temporary tables for
   * SPARQL_UPDATE: RDF_UPD_INS$, RDF_UPD_INS_CLOB$, RDF_UPD_DEL$
   */
  PROCEDURE drop_sparql_update_tables;

  /**
   * This procedure takes a list of FROM graphs (graphs), a list of
   * FROM NAMED graphs (named_graphs), and a rules index name and
   * populates a models list and IDs list for the default graph and
   * and any named graphs
   */
  PROCEDURE processGraphs(graphs               MDSYS.RDF_Graphs,
                          named_graphs         MDSYS.RDF_Graphs,
                          precompIdx           VARCHAR2,
                          defaultGIDs      OUT SYS.ODCINumberList,
                          namedGIDs        OUT SYS.ODCINumberList,
                          defaultModels    OUT MDSYS.RDF_Models,
                          defaultMIDs      OUT SYS.ODCINumberList,
                          flag          IN OUT NUMBER);

  PROCEDURE parse_property_value (
    v_property       IN  VARCHAR2
  , pv_type          IN  VARCHAR2
  , pv_id            OUT NUMBER
  , new_pv           OUT BOOLEAN
  , flags            IN  VARCHAR2 DEFAULT NULL
  );

  PROCEDURE parse_object_node (
    v_object         IN  VARCHAR2
  , lit_type         IN  VARCHAR2
  , lit_lang         IN  VARCHAR2
  , ov_type          IN  VARCHAR2
  , ov_id            OUT NUMBER
  , cov_id           OUT NUMBER
  , new_ov           OUT BOOLEAN
  );

  PROCEDURE parse_object_node (
    v_object         IN  CLOB
  , lit_type         IN  VARCHAR2
  , lit_lang         IN  VARCHAR2
  , ov_type          IN  VARCHAR2
  , ov_id            OUT NUMBER
  , cov_id           OUT NUMBER
  , new_ov           OUT BOOLEAN
  );

  PROCEDURE cleanup_batch_load (table_name IN VARCHAR2);
  PROCEDURE cleanup_batch_load (
    table_name                  IN  VARCHAR2
  , temp_tab_name               IN  VARCHAR2
  );

  PROCEDURE move_sem_network_data (
    dest_schema      dbms_id
  , dest_tbs_name    dbms_id default NULL
  , degree           pls_integer
  , options          varchar2 default NULL
  );

  PROCEDURE restore_sem_network_data (
    from_schema      dbms_id
  , degree           pls_integer
  , options          varchar2 default NULL
  );

  PROCEDURE append_sem_network_data (
    from_schema      dbms_id
  , degree           pls_integer
  , options          varchar2 default NULL
  );

---------

  PROCEDURE create_rdf_network (
    tablespace_name in varchar2
  , options         in varchar2 default null);
  PROCEDURE drop_rdf_network (cascade in boolean default false);

  PROCEDURE create_sem_network (
    tablespace_name in varchar2
  , options in varchar2 default null);
  PROCEDURE drop_sem_network (cascade in boolean default false);

  PROCEDURE create_logical_network (model_name IN VARCHAR2);
  PROCEDURE drop_logical_network (model_name IN VARCHAR2);

  PROCEDURE migrate_data_to_current (options IN VARCHAR2 default NULL);
  PROCEDURE alter_sem_indexes (attr_name IN varchar2, new_val IN varchar2,
                               options IN varchar2 default null);
  PROCEDURE enable_inmemory (populate_wait IN BOOLEAN);
  PROCEDURE disable_inmemory;

  /**
   * Note only model owner (or dba) is allowed to perform this action.
   * All information in the existing application table will be lost.
   * 'Triple' column will be reconstructed.
   * A commit will be performed at the very beginning of the procedure.
   */
  PROCEDURE remove_duplicates(model_name       IN VARCHAR2,
                        threshold       IN FLOAT DEFAULT 0.3,
                        rebuild_index    IN BOOLEAN DEFAULT TRUE);

  PROCEDURE get_change_tracking_info(model_name          IN     VARCHAR2,
                                     enabled             OUT BOOLEAN,
                                     tracking_start_time OUT TIMESTAMP);

  PROCEDURE get_inc_inf_info(entailment_name     IN     VARCHAR2,
                             enabled             OUT BOOLEAN,
                             prev_inf_start_time OUT TIMESTAMP);

  PROCEDURE merge_models(source_model           IN VARCHAR2,
                         destination_model      IN VARCHAR2,
                         rebuild_index          IN BOOLEAN DEFAULT TRUE,
                         drop_source_model      IN BOOLEAN DEFAULT FALSE,
                         options                IN VARCHAR2 DEFAULT NULL,
                         update_change_tracking IN BOOLEAN DEFAULT TRUE,
                         source_table           IN VARCHAR2 DEFAULT NULL);

  /**
   * Note only model owner (or dba) is allowed perform this action. Not all
   * parameters of dbms_stats.gather_table_stats makes sense here.
   */
  PROCEDURE analyze_model(
      model_name       IN VARCHAR2,
      estimate_percent IN NUMBER   DEFAULT DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       IN VARCHAR2 DEFAULT NULL,
      degree           IN NUMBER   DEFAULT NULL,
      cascade          IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_CASCADE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );

  /**
   * Note only rules index owner (or dba) is allowed perform this action. Not all
   * parameters of dbms_stats.gather_table_stats makes sense here.
   */
  PROCEDURE analyze_rules_index(
      index_name IN VARCHAR2,
      estimate_percent IN NUMBER   DEFAULT DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       IN VARCHAR2 DEFAULT NULL,
      degree           IN NUMBER   DEFAULT NULL,
      cascade          IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_CASCADE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  PROCEDURE analyze_entailment(
      entailment_name  IN VARCHAR2,
      estimate_percent IN NUMBER   DEFAULT DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       IN VARCHAR2 DEFAULT NULL,
      degree           IN NUMBER   DEFAULT NULL,
      cascade          IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_CASCADE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  procedure export_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );


  procedure import_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  procedure export_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );


  procedure import_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  --
  -- This method will swap the names of two models and also the names of
  -- the two underlying application tables that correspond to these two models.
  --
  -- The input to this method are two model names. This method requires that the
  -- current session user is the owner of both models.
  --
  -- Note that a commit will be executed at the very beginning and very end of
  -- this method call.
  PROCEDURE swap_names(model1  in VARCHAR2,
                       model2  in VARCHAR2);

  PROCEDURE rename_model(old_name  in VARCHAR2,
                         new_name  in VARCHAR2);
  PROCEDURE rename_entailment(old_name  in VARCHAR2,
                              new_name  in VARCHAR2);


  /**
   * Note only model owner (or dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  PROCEDURE delete_model_stats(
      model_name       IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  /**
   * Note only model owner (or dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  PROCEDURE delete_entailment_stats(
      entailment_name  IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  PROCEDURE set_model_stats (
   model_name    VARCHAR2,
   numrows       NUMBER    DEFAULT NULL,
   numblks       NUMBER    DEFAULT NULL,
   avgrlen       NUMBER    DEFAULT NULL,
   flags         NUMBER    DEFAULT NULL,
   no_invalidate BOOLEAN   DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk     NUMBER    DEFAULT NULL,
   cachehit      NUMBER    DEFAULT NULL,
   force         BOOLEAN   DEFAULT FALSE
  );


  PROCEDURE set_entailment_stats (
   entailment_name  VARCHAR2,
   numrows          NUMBER   DEFAULT NULL,
   numblks          NUMBER   DEFAULT NULL,
   avgrlen          NUMBER   DEFAULT NULL,
   flags            NUMBER   DEFAULT NULL,
   no_invalidate    BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk        NUMBER   DEFAULT NULL,
   cachehit         NUMBER   DEFAULT NULL,
   force            BOOLEAN  DEFAULT FALSE
  );


  PROCEDURE add_sem_index (
    index_code      IN  VARCHAR2
  , tablespace_name IN  VARCHAR2 default NULL
  , compression_length IN  PLS_INTEGER default NULL
  );

  PROCEDURE drop_sem_index (
    index_code      IN   VARCHAR2
  );

  PROCEDURE add_datatype_index(
    datatype            IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_datatype_index(
    datatype            IN VARCHAR2
  , force_drop          IN BOOLEAN default FALSE
  );

  PROCEDURE alter_datatype_index(
    datatype            IN VARCHAR2
  , command             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  );

  PROCEDURE alter_index_on_sem_graph (
    graph_name       IN  VARCHAR2
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , parallel         IN  PLS_INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  , tablespace_name  IN  VARCHAR2 default NULL
  , is_rules_index   IN  BOOLEAN default FALSE
  , use_compression  IN  BOOLEAN default NULL
  );

  PROCEDURE refresh_sem_network_index_info (
    options             IN VARCHAR2 default NULL
  );

  PROCEDURE alter_sem_graph (
    graph_name       IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , parallel         IN  PLS_INTEGER default NULL
  , is_rules_index   IN  BOOLEAN default FALSE
  );

  -- Helper functions for SPARQL FILTER --
  FUNCTION castToBoolean(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToDouble(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              BINARY_DOUBLE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToFloat(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              BINARY_FLOAT DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToDecimal(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToInteger(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToDateTime(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToString(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION isV$CLOB(
    vname            IN VARCHAR2
  ) RETURN              BOOLEAN DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$LitTypeFam(
    dTypeURI         IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$TypeFam(
    vType            IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION langMatches(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION rdfTermComp(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION rdfTermEqual(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION dateTimeComp(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION dateTimeEqual(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$EBVVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$NumericVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;
  pragma restrict_references (getV$NumericVal,WNDS,RNDS,WNPS,RNPS);

  FUNCTION getV$StringVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$StringAndLangVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$DateTimeTZVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$DateTZVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$TimeTZVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$BooleanVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$DatatypeVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$LangVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN               VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$STRVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$GeometryVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , srid             IN NUMBER
  ) RETURN              MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;

  -- VC rdfterm version
  FUNCTION getV$GeometryVal (
    term             IN VARCHAR2
  , srid             IN NUMBER
  ) RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$GeoSRID (
    geom             IN MDSYS.SDO_GEOMETRY
  , col_SRID         IN NUMBER default null
  ) RETURN              VARCHAR2 PARALLEL_ENABLE;

  FUNCTION getV$GeoSRID_SDO (
    geom             IN MDSYS.SDO_GEOMETRY
  , col_SRID         IN NUMBER default null
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION convert_to_gml311_literal(
    geom             IN MDSYS.SDO_GEOMETRY
  , options          IN VARCHAR2 DEFAULT NULL
  ) RETURN              CLOB DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION convert_to_wkt_literal(
    geom             IN MDSYS.SDO_GEOMETRY
  , srid_prefix      IN VARCHAR2 DEFAULT NULL
  , options          IN VARCHAR2 DEFAULT NULL
  , col_SRID         IN NUMBER default null
  ) RETURN              CLOB DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_if (
    if_cond          IN NUMBER
  , value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_coalesce (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_uri (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , base_prefix      IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_bnode (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , no_args          IN PLS_INTEGER
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strlang (
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , long_value       IN CLOB
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strdt (
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , long_value1      IN CLOB
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_timezone (
    value_type      IN VARCHAR2
  , vname_prefix    IN VARCHAR2
  , vname_suffix    IN VARCHAR2
  , literal_type    IN VARCHAR2
  , language_type   IN VARCHAR2
  , time_zone_func  IN PLS_INTEGER
  ) RETURN             MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$RDFTermString (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_substr (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , offset           IN NUMBER
  , len              IN NUMBER
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_ucase (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

 FUNCTION sparql_lcase (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

 FUNCTION sparql_strbefore (
   value_types       IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strafter (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_replace (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , reg_exp          IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_concat (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_contains (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strlen (
    value_type       IN Varchar2
  , vname_prefix     IN Varchar2
  , vname_suffix     IN Varchar2
  , literal_type     IN Varchar2
  , language_type    IN Varchar2
  , long_value       IN CLOB
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strstarts (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strends (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_encode_for_uri (
    value_name       IN VARCHAR2
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

 -- Begin VARCHAR rdf term versions of helper functions for simpler SQL generation
  FUNCTION rdfTermComp(
    term1            IN VARCHAR2
  , term2            IN VARCHAR2
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION rdfTermEqual(
    term1            IN VARCHAR2
  , term2            IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

 FUNCTION sparql_substr (
    term             IN VARCHAR2
  , offset           IN NUMBER
  , len              IN NUMBER
  , canon            IN NUMBER
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_ucase (
    term             IN VARCHAR2
  , canon            IN NUMBER
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_lcase (
    term             IN VARCHAR2
  , canon            IN NUMBER
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strbefore (
    term1            IN VARCHAR2
  , term2            IN VARCHAR2
  , canon            IN NUMBER
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strafter (
    term1            IN VARCHAR2
  , term2            IN VARCHAR2
  , canon            IN NUMBER
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_regex (
    terms      IN SYS.ODCIVarchar2List
  , reg_exp    IN VARCHAR2
  ) RETURN     NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_replace (
    terms      IN SYS.ODCIVarchar2List
  , reg_exp    IN VARCHAR2
  , canon      IN NUMBER
  ) RETURN     VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_concat (
    terms      IN SYS.ODCIVarchar2List
  , canon      IN NUMBER
  ) RETURN     VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_contains (
    terms            IN SYS.ODCIVarchar2List
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strlen (
    term             IN Varchar2
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

 FUNCTION sparql_strstarts (
    terms            IN SYS.ODCIVarchar2List
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

 FUNCTION sparql_strends (
    terms            IN SYS.ODCIVarchar2List
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;
  -- End VC RDF term functions


  -- End SPARQL FILTER functions --

  -- Helper functions for SPARQL SOLUTION MODIFIER --
  FUNCTION getV$OrderFamily (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;
  pragma restrict_references (getV$OrderFamily,WNDS,RNDS,WNPS,RNPS);

  FUNCTION getV$CalendarOrderVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , dir              IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;
  pragma restrict_references (getV$CalendarOrderVal,WNDS,RNDS,WNPS,RNPS);
  -- End SPARQL SOLUTION MODIFIER functions --

  -- Character escaping/unescaping functions --
  FUNCTION unescape_rdf_value(
    val       IN VARCHAR2 CHARACTER SET ANY_CS
  , options   IN VARCHAR2 DEFAULT NULL
  ) RETURN  VARCHAR2 CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION unescape_clob_value(
    val           IN CLOB CHARACTER SET ANY_CS
  , start_offset  IN NUMBER   DEFAULT 1
  , end_offset    IN NUMBER   DEFAULT 0
  , include_start IN NUMBER   DEFAULT 0
  , options       IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION unescape_rdf_term(
    term      IN VARCHAR2 CHARACTER SET ANY_CS
  , options   IN VARCHAR2 DEFAULT NULL
  ) RETURN  VARCHAR2 CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION unescape_clob_term(
    term      IN CLOB CHARACTER SET ANY_CS
  , options   IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_rdf_value(
    val            IN VARCHAR2 CHARACTER SET ANY_CS
  , utf_encode     IN NUMBER   DEFAULT 1
  , allow_long     IN NUMBER   DEFAULT 0
  , options        IN VARCHAR2 DEFAULT NULL
  , term_padding   IN NUMBER   DEFAULT 0
  ) RETURN  VARCHAR2 CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_clob_value(
    val            IN CLOB CHARACTER SET ANY_CS
  , start_offset   IN NUMBER DEFAULT 1
  , end_offset     IN NUMBER DEFAULT 0
  , utf_encode     IN NUMBER DEFAULT 1
  , include_start  IN NUMBER DEFAULT 0
  , options        IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_rdf_term(
    term           IN VARCHAR2 CHARACTER SET ANY_CS
  , utf_encode     IN NUMBER DEFAULT 1
  , options        IN VARCHAR2 DEFAULT NULL
  ) RETURN  VARCHAR2 CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_clob_term(
    term           IN CLOB CHARACTER SET ANY_CS
  , utf_encode     IN NUMBER DEFAULT 1
  , options        IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;
  -- End character escaping/unescaping functions --

  -- UTL_URL wrapper encode/decode funcs (NOTE: different default values)
  FUNCTION form_url_encode (
    data              IN VARCHAR2
  , charset           IN VARCHAR2 default NULL) RETURN VARCHAR2 PARALLEL_ENABLE;

  FUNCTION form_url_decode (
    data             IN VARCHAR2
  , charset          IN VARCHAR2 default NULL) RETURN VARCHAR2;

  FUNCTION expand_uri_w_base (
    base                   IN varchar2
  , query                  IN varchar2) RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

END sdo_rdf ;
/

