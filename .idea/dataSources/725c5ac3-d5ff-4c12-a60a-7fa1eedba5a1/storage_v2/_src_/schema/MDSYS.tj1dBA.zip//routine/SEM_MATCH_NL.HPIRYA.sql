create function SEM_MATCH_NL wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
356 138
NtdWHJGlaiiaUO1R+siPp7x0JQwwg2O3mEhqfHTp2sHVIRtns2v2GxVRC2/TY6Xzd7f5tZb8
G+cvjCi0StSZQR0I4YqQ2owVNX/EdDyy8Os/H/kQJyX/SmUZHQa4+yk5yP6xRH7R87dIC/Tv
P98qfLGAM9/zLVuub7Reo+DVgRJCcwi3eWG3Z6Q/MfYT8KgLNNpPwsx+ttgor5v/lsiLpZ48
aZt0h68/jgadtIGyw7E4xV5pSeYg36QynpL/6W1HfgcKLlBx4gsg3Qs2HemZjcUb4F+vjc4h
mBNgvujJxpyWfHsKhA==
/

