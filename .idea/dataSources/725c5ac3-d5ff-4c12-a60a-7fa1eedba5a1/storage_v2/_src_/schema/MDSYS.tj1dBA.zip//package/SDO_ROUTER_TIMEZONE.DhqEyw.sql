create PACKAGE       SDO_ROUTER_TIMEZONE AUTHID current_user AS
  PROCEDURE cleanup_timezones;
  PROCEDURE create_router_timezones_edges(log_file_name IN VARCHAR2 := 'sdo_router_timezones.log');
  PROCEDURE create_sdo_timezones_index(log_file_name IN VARCHAR2 := 'sdo_router_timezones.log');
END SDO_ROUTER_TIMEZONE;
/

