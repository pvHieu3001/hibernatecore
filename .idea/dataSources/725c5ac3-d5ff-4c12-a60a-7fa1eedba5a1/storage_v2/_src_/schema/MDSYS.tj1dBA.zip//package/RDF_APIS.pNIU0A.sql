create PACKAGE rdf_apis authid current_user AS
  REACH_CLOSURE constant integer := 0;

  -- flag for syn_orig_value
  STRIP_TIME_PREFIX constant integer := 1;

  -- flag for indicating rules index status during sem_contains
  RULESIDX_VALID constant integer := 0;
  RULESIDX_INCOMPLETE constant integer := 1;
  RULESIDX_INVALID constant integer := 2;

  -- invalidates cursors with unresolved values
  PROCEDURE refresh_query_state;

  -- create entailment based on the subset of OWL-DL
  -- that we implemented
  procedure create_entailment(index_name_in          varchar2,
                              models_in              mdsys.rdf_models,
                              rulebases_in           mdsys.rdf_rulebases,
                              passes                 integer  default 0,
                              inf_components_in      varchar2 default null,
                              options                varchar2 default null,
                              delta_in               mdsys.rdf_models default null,
                              label_gen              mdsys.RDFSA_LABELGEN default null,
                              ng_tab_name            varchar2,
                              ng_tab_schema          varchar2 default null,
                              inf_ng_name            varchar2 default null,
                              inf_ext_user_func_name varchar2 default null,
                              ols_ladder_inf_lbl_seq varchar2 default null  -- A string a numeric labels
                                                                            -- delimited by a space
                              );

  -- create entailment based on the subset of OWL-DL
  -- that we implemented
  procedure create_entailment(index_name_in     varchar2,
                              models_in         mdsys.rdf_models,
                              rulebases_in      mdsys.rdf_rulebases,
                              passes            integer  default 0,
                              inf_components_in varchar2 default null,
                              options           varchar2 default null,
                              delta_in          mdsys.rdf_models default null,
                              label_gen         mdsys.RDFSA_LABELGEN default null,
                              include_named_g         sem_graphs       default null,
                              include_default_g       mdsys.rdf_models default null,
                              include_all_g           mdsys.rdf_models default null,
                              inf_ng_name             varchar2 default null,
                              inf_ext_user_func_name  varchar2 default null,
                              ols_ladder_inf_lbl_seq  varchar2 default null  -- A string a numeric labels
                                                                             -- delimited by a space
                              );

  procedure drop_entailment(index_name_in     varchar2,
                            named_g_in        sem_graphs default null,
                            dop               int        default 1);

  procedure enable_inc_inference(entailment_name varchar2);
  procedure disable_inc_inference(entailment_name varchar2);
  procedure enable_change_tracking(models_in mdsys.rdf_models);
  procedure disable_change_tracking(models_in mdsys.rdf_models);

  procedure analyze_intermediate;

  function validate_model(models_in         mdsys.rdf_models,
                          criteria_in       varchar2 default null,
                          max_conflict      int default 100,
                          options           varchar2 default null
                          )
  return mdsys.rdf_longVarcharArray;


  function validate_entailment(models_in         mdsys.rdf_models,
                               rulebases_in      mdsys.rdf_rulebases,
                               criteria_in       varchar2 default null,
                               max_conflict      int default 100,
                               options           varchar2 default null
                               )
  return mdsys.rdf_longVarcharArray;

   -- Create a Rulebase
   PROCEDURE CREATE_RULEBASE (
        rulebase_name   VARCHAR2);

   -- Delete a Rulebase
   PROCEDURE DROP_RULEBASE (
        rulebase_name   VARCHAR2);

   -- Infer + store triples for specified models + rules
   PROCEDURE CREATE_RULES_INDEX (
        index_name_in   varchar2,
        models_in       MDSYS.RDF_Models,
        rulebases_in    MDSYS.RDF_Rulebases);

   -- Remove inferred triples for specified rulesindex
   PROCEDURE DROP_RULES_INDEX (
        index_name      varchar2,
        named_g_in      sem_graphs default null,
        dop             int        default 1);

   FUNCTION LOOKUP_RULES_INDEX (
        models          MDSYS.RDF_Models,
        rulebases       MDSYS.RDF_Rulebases)
   RETURN varchar2;


   FUNCTION LOOKUP_ENTAILMENT (
        models          MDSYS.RDF_Models,
        rulebases       MDSYS.RDF_Rulebases)
   RETURN varchar2;

   -- CLEANUP_FAILED: cleanup a failed operation
   --   typ: 'RULEBASE' or 'RULES_INDEX'
   --   name: rulebase or ruleindex name.
   PROCEDURE CLEANUP_FAILED(
         rdf_object_type    varchar2,
         rdf_object_name    varchar2);

   PROCEDURE DROP_USER_INFERENCE_OBJS(uname varchar2);

   ---------------------------------------------------------------------------
   -- Interfaces below this line are intended for internal use only;
   -- they should not be documented or directly invoked by the user.
   ---------------------------------------------------------------------------

   FUNCTION  raiseURIError(rulename varchar2, pos int) RETURN int;

   -- needed for internal use
   FUNCTION hashCLOB(c CLOB) return number deterministic parallel_enable;

   --
   -- LOOKUP_LITERAL
   -- bug #4486600: we need LOOKUP_LITERAL to be publicly executable.
   -- For now public doesn't need access to the CLOB variant of
   -- LOOKUP_LITERAL or to LOOKUP_CREATE_LITERAL.
   --
   PROCEDURE LOOKUP_LITERAL(
        lit varchar2, typ varchar2, lang varchar2,
        canonID OUT int, exactID OUT int);

   -- Alternate version of LOOKUP_LITERAL with parameterized
   -- values table. Used to allow local value$ use with
   -- SEM_MATCH
   PROCEDURE LOOKUP_LITERAL(
        vTab varchar2, lit varchar2, typ varchar2, lang varchar2,
        canonID OUT int, exactID OUT int);

   -- CLOB version of LOOKUP_LITERAL needed for SPARQL update
   PROCEDURE LOOKUP_LITERAL(
       lit CLOB,     typ varchar2, lang varchar2,
       canonID OUT int, exactID OUT int);


  --
  -- START (PROXY) APIS MERGED FROM SDO_RDF PACKAGE (sdordfxh.sql) --
  --
  PROCEDURE CREATE_SOURCE_EXTERNAL_TABLE (
    source_table         varchar2
  , def_directory        varchar2
  , log_directory        varchar2 default NULL
  , bad_directory        varchar2 default NULL
  , log_file             varchar2 default NULL
  , bad_file             varchar2 default NULL
  , parallel             PLS_INTEGER default NULL
  , source_table_owner   varchar2 default NULL
  , prep_directory       varchar2 default NULL
  , preprocessor         varchar2 default NULL
  , flags                varchar2 default NULL
  );

  PROCEDURE LOAD_INTO_STAGING_TABLE (
    staging_table        varchar2
  , source_table         varchar2
  , input_format         varchar2 default NULL
  , parallel             PLS_INTEGER default NULL
  , staging_table_owner  varchar2 default NULL
  , source_table_owner   varchar2 default NULL
  , flags                varchar2 default NULL
  );

  PROCEDURE BULK_LOAD_FROM_STAGING_TABLE (
    model_name     IN          varchar2,
    table_owner    IN          varchar2,
    table_name     IN          varchar2,
    flags          IN          varchar2 default NULL,
    debug          IN          PLS_INTEGER default NULL,
    start_comment  IN          varchar2 default NULL,
    end_comment    IN          varchar2 default NULL
  );

  PROCEDURE PRIVILEGE_ON_APP_TABLES (
    command varchar2 default 'GRANT'
  , privilege varchar2 default 'SELECT'
  );

  PROCEDURE PURGE_UNUSED_VALUES (
    flags               IN              varchar2 default NULL
  );

  PROCEDURE RESUME_LOAD_FROM_STAGING_TABLE (
    model_name          IN              varchar2,
    table_owner         IN              varchar2,
    table_name          IN              varchar2,
    session_id          IN              varchar2,
    flags               IN              varchar2 default NULL,
    start_comment       IN              varchar2 default NULL,
    end_comment         IN              varchar2 default NULL
  );

  PROCEDURE get_change_tracking_info(model_name          IN     VARCHAR2,
                                     enabled             OUT BOOLEAN,
                                     tracking_start_time OUT TIMESTAMP);

  PROCEDURE get_inc_inf_info(entailment_name     IN     VARCHAR2,
                             enabled             OUT BOOLEAN,
                             prev_inf_start_time OUT TIMESTAMP);

  PROCEDURE merge_models(source_model          IN VARCHAR2,
                         destination_model     IN VARCHAR2,
                         rebuild_apptab_index  IN BOOLEAN DEFAULT TRUE,
                         drop_source_model     IN BOOLEAN DEFAULT FALSE,
                         options               IN varchar2 DEFAULT NULL);

        FUNCTION get_model_id (
                model_name IN VARCHAR2
        ) RETURN NUMBER ;

        FUNCTION get_model_name (
                model_id IN NUMBER
        ) RETURN VARCHAR2 ;

        FUNCTION is_triple (
                model_id IN NUMBER,
                rdf_t_id IN VARCHAR2
        ) RETURN VARCHAR2 ;

        FUNCTION is_triple (
                model_name IN VARCHAR2,
                rdf_t_id IN VARCHAR2
        ) RETURN VARCHAR2 ;

        FUNCTION is_triple (
                model_id IN NUMBER,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN VARCHAR2
        ) RETURN VARCHAR2 ;

        FUNCTION is_triple (
                model_name IN VARCHAR2,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN VARCHAR2
        ) RETURN VARCHAR2 ;

        FUNCTION is_triple (
                model_id IN NUMBER,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN CLOB
        ) RETURN VARCHAR2 ;

        FUNCTION is_triple (
                model_name IN VARCHAR2,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN CLOB
        ) RETURN VARCHAR2 ;


        FUNCTION get_triple_id (
                model_id IN NUMBER,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN CLOB
        ) RETURN VARCHAR2 ;

        FUNCTION get_triple_id (
                model_name IN VARCHAR2,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN CLOB
        ) RETURN VARCHAR2 ;

        FUNCTION get_triple_id (
                model_id IN NUMBER,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object   IN VARCHAR2
        ) RETURN VARCHAR2 ;

        FUNCTION get_triple_id (
                model_name IN VARCHAR2,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object   IN VARCHAR2
        ) RETURN VARCHAR2 ;

        FUNCTION get_object_id (
                object   IN VARCHAR2
        ) RETURN NUMBER;

        FUNCTION is_reified_quad (
                model_id IN NUMBER,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN VARCHAR2
        ) RETURN VARCHAR2 ;

        FUNCTION is_reified_quad (
                model_name IN VARCHAR2,
                subject IN VARCHAR2,
                property IN VARCHAR2,
                object IN VARCHAR2
        ) RETURN VARCHAR2 ;

  PROCEDURE refresh_sem_tablespace_names (
    model_name                 VARCHAR2 default NULL  -- NULL => all
  );
  PROCEDURE create_rdf_model (model_name IN VARCHAR2, table_name IN VARCHAR2, column_name IN VARCHAR2, model_tablespace IN VARCHAR2 default NULL, options IN VARCHAR2 default NULL);
  PROCEDURE drop_rdf_model (model_name IN VARCHAR2);
  PROCEDURE create_sem_model (model_name IN VARCHAR2, table_name IN VARCHAR2, column_name IN VARCHAR2, model_tablespace IN VARCHAR2 default NULL, options IN VARCHAR2 default Null);
  PROCEDURE drop_sem_model (model_name IN VARCHAR2);

  PROCEDURE create_virtual_model (
    vm_name             IN VARCHAR2
  , models              IN MDSYS.RDF_Models default NULL
  , rulebases           IN MDSYS.RDF_Rulebases default NULL
  , options             IN VARCHAR2 default NULL
  , entailments         IN MDSYS.RDF_Entailments default NULL
  );
  PROCEDURE drop_virtual_model (vm_name IN VARCHAR2);

  PROCEDURE create_pg_rdfview (
    model_name          IN VARCHAR2
  , pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE create_pg_rdfview (
    model_name          IN VARCHAR2
  , pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2
  , pg_stag_tab         IN VARCHAR2
  , pg_edge_kv_tab      IN VARCHAR2
  , pg_node_kv_tab      IN VARCHAR2
  , pg_edge_tab         IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_pg_rdfview (
    model_name          IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_pg_rdfview (
    model_name          IN VARCHAR2
  , pg_stag_tab         IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE build_pg_rdfview_indexes (
    pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE build_pg_rdfview_indexes (
    pg_name             IN VARCHAR2
  , tablespace_name     IN VARCHAR2
  , pg_edge_kv_tab      IN VARCHAR2
  , pg_node_kv_tab      IN VARCHAR2
  , pg_edge_tab         IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_pg_rdfview_indexes (
    pg_name             IN VARCHAR2
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE export_rdfview_model (
    model_name          IN VARCHAR2
  , rdf_table_owner     IN VARCHAR2 default NULL
  , rdf_table_name      IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE create_rdfview_model (
    model_name          IN VARCHAR2
  , tables              IN SYS.ODCIVarchar2List
  , prefix              IN VARCHAR2 default NULL
  , r2rml_table_owner   IN VARCHAR2 default NULL
  , r2rml_table_name    IN VARCHAR2 default NULL
  , schema_table_owner  IN VARCHAR2 default NULL
  , schema_table_name   IN VARCHAR2 default NULL
  , options             IN VARCHAR2 default NULL
  , r2rml_string        IN CLOB CHARACTER SET ANY_CS default NULL
  , r2rml_string_fmt    IN VARCHAR2 default NULL
  );

  PROCEDURE drop_rdfview_model (
    model_name IN VARCHAR2
  , options IN VARCHAR2 default NULL
  );

  PROCEDURE gather_model_stats (
    model_name     IN VARCHAR2
  , options        IN VARCHAR2 default NULL
  );
  PROCEDURE drop_model_stats (
    model_name     IN VARCHAR2
  );
  FUNCTION get_model_stats (
     model_name       IN VARCHAR2
  ,  stats_type       IN VARCHAR2
  ,  value_ids        IN SYS.ODCINumberList
  ,  options          IN VARCHAR2 default NULL
  )
  RETURN SYS_REFCURSOR;

  PROCEDURE update_model (
    apply_model        IN VARCHAR2
  , update_stmt        IN CLOB                CHARACTER SET ANY_CS
  , match_models       IN MDSYS.RDF_Models    default NULL
  , match_rulebases    IN MDSYS.RDF_Rulebases default NULL
  , match_index_status IN VARCHAR2            default NULL
  , match_options      IN VARCHAR2            default NULL
  , options            IN VARCHAR2            default NULL
  );

  PROCEDURE create_sparql_update_tables;
  PROCEDURE drop_sparql_update_tables;

  FUNCTION sparql_to_sql (
    sparql_query   IN CLOB                CHARACTER SET ANY_CS
  , models         IN MDSYS.RDF_Models
  , rulebases      IN MDSYS.RDF_Rulebases default NULL
  , aliases        IN MDSYS.RDF_Aliases   default NULL
  , index_status   IN VARCHAR2            default NULL
  , options        IN VARCHAR2            default NULL
  , graphs         MDSYS.RDF_Graphs       default NULL
  , named_graphs   MDSYS.RDF_Graphs       default NULL
  )
  RETURN CLOB;

  PROCEDURE move_sem_network_data (
    dest_schema      dbms_id
  , dest_tbs_name    dbms_id default NULL
  , degree           pls_integer default NULL
  , options          varchar2 default NULL
  );

  PROCEDURE restore_sem_network_data (
    from_schema      dbms_id
  , degree           pls_integer default NULL
  , options          varchar2 default NULL
  );

  PROCEDURE append_sem_network_data (
    from_schema      dbms_id
  , degree           pls_integer default NULL
  , options          varchar2 default NULL
  );

  PROCEDURE cleanup_batch_load (table_name IN VARCHAR2);
  PROCEDURE cleanup_batch_load (table_name IN VARCHAR2, temp_tab_name IN VARCHAR2);
  PROCEDURE create_rdf_network (tablespace_name in varchar2, options in varchar2 default null);
  PROCEDURE drop_rdf_network (cascade in boolean default false);
  PROCEDURE create_sem_network (tablespace_name in varchar2, options in varchar2 default null);
  PROCEDURE drop_sem_network (cascade in boolean default false);
  -- PROCEDURE update_user_table$ (model_id  IN NUMBER);
  PROCEDURE create_logical_network (model_name IN VARCHAR2);
  PROCEDURE drop_logical_network (model_name IN VARCHAR2);
  PROCEDURE migrate_data_to_current (options IN VARCHAR2 default NULL);
  PROCEDURE alter_sem_indexes(attr_name IN varchar2, new_val IN varchar2, options in varchar2 default null);
  PROCEDURE enable_inmemory (populate_wait IN BOOLEAN);
  PROCEDURE disable_inmemory;
  --
  -- DONE  APIS MERGED FROM SDO_RDF PACKAGE (sdordfxh.sql) --
  --
        PROCEDURE start_batch$ (
                tempTblName IN VARCHAR2, model_id IN NUMBER, model_name IN VARCHAR2, rdf_tablespace IN VARCHAR2
        );

        PROCEDURE start_batch$ (tempTblName IN VARCHAR2, model_id IN NUMBER, model_name IN VARCHAR2,
                          rdf_tablespace IN VARCHAR2, exchange IN NUMBER DEFAULT NULL);

        PROCEDURE start_batch$ (
                model_id IN NUMBER, model_name IN VARCHAR2, rdf_tablespace IN VARCHAR2
        );

        PROCEDURE start_batch$ (
                model_id IN NUMBER, model_name IN VARCHAR2, rdf_tablespace IN VARCHAR2,
    exchange IN NUMBER
        );

        PROCEDURE exchange_model_part$ (
                model_id       IN NUMBER,
    rdf_tablespace IN VARCHAR2);

  function res2vid(vTab in varchar2,
                   uri in varchar2,
                   lt in varchar2 default null,
                   lang in varchar2  default null,
                   lval in clob default null)
  return number;

  FUNCTION get_value$_type$_func (
    model_id    NUMBER
  , lexval      VARCHAR2
  , pos         VARCHAR2
  , model_name  VARCHAR2 default NULL
  ) return sdo_rdf_term deterministic parallel_enable;

  FUNCTION syn_orig_value (
    value_name    varchar2,
    value_type    varchar2,
    literal_type  varchar2,
    language_type varchar2,
    flag          integer default 0
  )
  RETURN varchar2 DETERMINISTIC parallel_enable;
  pragma restrict_references (syn_orig_value,WNDS,RNDS,WNPS);

  FUNCTION compose_canon_term (
    value_name   varchar2,
    value_type   varchar2,
    literal_type varchar2,
    language_type varchar2
  )
  RETURN varchar2 DETERMINISTIC parallel_enable;
  pragma restrict_references (compose_canon_term,WNDS,RNDS,WNPS);

  FUNCTION compose_rdf_term (
    value_name   varchar2,
    value_type   varchar2,
    literal_type varchar2,
    language_type varchar2
  )
  RETURN varchar2 DETERMINISTIC parallel_enable;
  pragma restrict_references (compose_rdf_term,WNDS,RNDS,WNPS);

  FUNCTION compose_rdf_term (
    value_name    varchar2,
    value_type    varchar2,
    literal_type  varchar2,
    language_type varchar2,
    long_value    CLOB,
    options       varchar2 default NULL
  )
  RETURN CLOB DETERMINISTIC parallel_enable;

  -- function to return the body (CASE END statement) of syn_orig_value func.
  FUNCTION syn_orig_value_body (alias VARCHAR2 default NULL)
  RETURN VARCHAR2 DETERMINISTIC;
  pragma restrict_references (syn_orig_value_body,WNDS,RNDS,WNPS,RNPS);

  -- function to return the expr for computing URI prefix and suffix
  FUNCTION value_name_prefix (
    value_name                     VARCHAR2
  , value_type                     VARCHAR2
  ) RETURN                         VARCHAR2 DETERMINISTIC parallel_enable;
  pragma restrict_references (value_name_prefix,WNDS,RNDS,WNPS,RNPS);

  FUNCTION value_name_suffix (
    value_name                     VARCHAR2
  , value_type                     VARCHAR2
  ) RETURN                         VARCHAR2 DETERMINISTIC parallel_enable;
  pragma restrict_references (value_name_suffix,WNDS,RNDS,WNPS,RNPS);

  FUNCTION value_name_prefix_expr (
    vname_expr                     VARCHAR2
  ) RETURN                         VARCHAR2 DETERMINISTIC;
  pragma restrict_references (value_name_prefix_expr,WNDS,RNDS,WNPS,RNPS);

  FUNCTION value_name_suffix_expr (
    vname_expr                     VARCHAR2
  ) RETURN                         VARCHAR2 DETERMINISTIC;
  pragma restrict_references (value_name_suffix_expr,WNDS,RNDS,WNPS,RNPS);

  /**
   * Note only model owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.gather_table_stats makes sense here.
   */
  PROCEDURE analyze_model(
      model_name       IN VARCHAR2,
      estimate_percent IN NUMBER   DEFAULT DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       IN VARCHAR2 DEFAULT NULL,
      degree           IN NUMBER   DEFAULT NULL,
      cascade          IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_CASCADE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );

  /**
   * Note only rules index owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.gather_table_stats makes sense here.
   */
  PROCEDURE analyze_rules_index(
      index_name IN VARCHAR2,
      estimate_percent IN NUMBER   DEFAULT DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       IN VARCHAR2 DEFAULT NULL,
      degree           IN NUMBER   DEFAULT NULL,
      cascade          IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_CASCADE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  PROCEDURE analyze_entailment(
      entailment_name  IN VARCHAR2,
      estimate_percent IN NUMBER   DEFAULT DBMS_STATS.AUTO_SAMPLE_SIZE,
      method_opt       IN VARCHAR2 DEFAULT NULL,
      degree           IN NUMBER   DEFAULT NULL,
      cascade          IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_CASCADE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  procedure export_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );


  procedure import_model_stats(
   model_name      varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  procedure export_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
  );


  procedure import_entailment_stats(
   entailment_name varchar2,
   stattab         VARCHAR2,
   statid          VARCHAR2 DEFAULT NULL,
   cascade         BOOLEAN  DEFAULT TRUE,
   statown         VARCHAR2 DEFAULT NULL,
   no_invalidate   BOOLEAN DEFAULT FALSE,
   force           BOOLEAN DEFAULT FALSE,
   stat_category   VARCHAR2 DEFAULT 'OBJECT_STATS'
   );


  PROCEDURE set_model_stats (
   model_name    VARCHAR2,
   numrows       NUMBER    DEFAULT NULL,
   numblks       NUMBER    DEFAULT NULL,
   avgrlen       NUMBER    DEFAULT NULL,
   flags         NUMBER    DEFAULT NULL,
   no_invalidate BOOLEAN   DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk     NUMBER    DEFAULT NULL,
   cachehit      NUMBER    DEFAULT NULL,
   force         BOOLEAN   DEFAULT FALSE
  );


  PROCEDURE set_entailment_stats (
   entailment_name  VARCHAR2,
   numrows          NUMBER   DEFAULT NULL,
   numblks          NUMBER   DEFAULT NULL,
   avgrlen          NUMBER   DEFAULT NULL,
   flags            NUMBER   DEFAULT NULL,
   no_invalidate    BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
   cachedblk        NUMBER   DEFAULT NULL,
   cachehit         NUMBER   DEFAULT NULL,
   force            BOOLEAN  DEFAULT FALSE
  );


  /**
   * Note only model owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  PROCEDURE delete_model_stats(
      model_name       IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  /**
   * Note only model owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  PROCEDURE delete_entailment_stats(
      entailment_name  IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );

  /**
   * Note only model owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  -- PROCEDURE delete_model_stats(
  --     model_name       IN VARCHAR2,
  --     cascade_parts    IN BOOLEAN  DEFAULT TRUE,
  --     cascade_columns  IN BOOLEAN  DEFAULT TRUE,
  --     cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
  --     no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
  --     force            IN BOOLEAN  DEFAULT FALSE
  --    );


  /**
   * Note only model owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  -- PROCEDURE delete_rules_index_stats(
  --     index_name       IN VARCHAR2,
  --     cascade_parts    IN BOOLEAN  DEFAULT TRUE,
  --     cascade_columns  IN BOOLEAN  DEFAULT TRUE,
  --     cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
  --     no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
  --     force            IN BOOLEAN  DEFAULT FALSE
  --    );
  --

  PROCEDURE swap_names(model1  in VARCHAR2,
                       model2  in VARCHAR2);

  PROCEDURE rename_model(old_name  in VARCHAR2,
                         new_name  in VARCHAR2);

  PROCEDURE rename_entailment(old_name  in VARCHAR2,
                              new_name  in VARCHAR2);

  /**
   * This procedure removes duplicates from a model.
   * Note only model owner (or sys dba) is allowed to perform this action.
   * All information in the existing application table will be lost.
   * 'Triple' column will be reconstructed.
   * A commit will be performed at the very beginning of the procedure
   * and at the very end of the procedure.
   */
  PROCEDURE remove_duplicates(model_name     IN VARCHAR2,
                        threshold            IN FLOAT DEFAULT 0.3,
                        rebuild_apptab_index IN BOOLEAN DEFAULT TRUE);

  PROCEDURE get_sem_index_info (flags VARCHAR2 default NULL);

  PROCEDURE add_sem_index (
    index_code      IN  VARCHAR2
  , tablespace_name IN  VARCHAR2 default NULL
  , compression_length IN  INTEGER default NULL
  );

  PROCEDURE drop_sem_index (
    index_code      IN   VARCHAR2
  );

  PROCEDURE add_datatype_index(
    datatype            IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_datatype_index(
    datatype            IN VARCHAR2
  , force_drop          IN BOOLEAN default FALSE
  );

  PROCEDURE alter_datatype_index(
    datatype            IN VARCHAR2
  , command             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  );

  /*
  PROCEDURE alter_index_on_sem_graph (
    graph_name       IN  VARCHAR2
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , parallel         IN  INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  , tablespace_name  IN  VARCHAR2 default NULL
  , is_rules_index   IN  BOOLEAN default FALSE
  , use_compression  IN  BOOLEAN default NULL
  );


  PROCEDURE alter_index_on_sem_graph (
    graph_name       IN  VARCHAR2
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , parallel         IN  INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  , tablespace_name  IN  VARCHAR2 default NULL
  , is_entailment    IN  BOOLEAN default FALSE
  , use_compression  IN  BOOLEAN default NULL
  );
  */


  PROCEDURE alter_sem_index_on_model (
    model_name       IN  VARCHAR2
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , use_compression  IN  BOOLEAN default NULL
  , parallel         IN  INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  );


  /*
  PROCEDURE alter_sem_index_on_rules_index (
    rules_index_name IN  VARCHAR2
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , use_compression  IN  BOOLEAN default NULL
  , parallel         IN  INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  );
  */

  PROCEDURE alter_sem_index_on_entailment (
    entailment_name  IN  VARCHAR2
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , use_compression  IN  BOOLEAN default NULL
  , parallel         IN  INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  );


  PROCEDURE refresh_sem_network_index_info (
    options             IN VARCHAR2 default NULL
  );


  /*
  PROCEDURE alter_sem_graph (
    graph_name       IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2
  , parallel         IN  INTEGER default NULL
  , is_entailment    IN  BOOLEAN default FALSE
  );


  PROCEDURE alter_sem_graph (
    graph_name       IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2
  , parallel         IN  INTEGER default NULL
  , is_rules_index   IN  BOOLEAN default FALSE
  );
  */

  PROCEDURE alter_model (
    model_name       IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , parallel         IN  INTEGER default NULL
  );


  /*
  PROCEDURE alter_rules_index (
    rules_index_name IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2
  , parallel         IN  INTEGER default NULL
  );
  */


  PROCEDURE alter_entailment (
    entailment_name  IN  VARCHAR2
  , command          IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , parallel         IN  INTEGER default NULL
  );


  -- Helper functions for SPARQL FILTER --
  FUNCTION castToBoolean(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToDouble(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              BINARY_DOUBLE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToFloat(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              BINARY_FLOAT DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToDecimal(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToInteger(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToDateTime(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToString(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION castToString(
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION rdfTermComp(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION rdfTermEqual(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION dateTimeComp(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION dateTimeEqual(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$EBVVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$NumericVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$StringVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$StringAndLangVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION langMatches(
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$DateTimeTZVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$DateTZVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$TimeTZVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$BooleanVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$DatatypeVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$LangVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN               VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$STRVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$STRVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$GeometryVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , srid             IN NUMBER
  ) RETURN              MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$GeoSRID (
    geom             IN MDSYS.SDO_GEOMETRY
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION convert_to_gml311_literal(
    geom             IN MDSYS.SDO_GEOMETRY
  , options          IN VARCHAR2 DEFAULT NULL
  ) RETURN              CLOB DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION convert_to_wkt_literal(
    geom             IN MDSYS.SDO_GEOMETRY
  , srid_prefix      IN VARCHAR2 DEFAULT NULL
  , options          IN VARCHAR2 DEFAULT NULL
  ) RETURN              CLOB DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_if (
    if_cond          IN NUMBER
  , value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_coalesce (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

   FUNCTION sparql_uri (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , base_prefix      IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

   FUNCTION sparql_bnode (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , no_args          IN PLS_INTEGER
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strlang (
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , long_value1      IN CLOB
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  , literal_type2    IN VARCHAR2
  , language_type2   IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strdt (
    value_type1      IN VARCHAR2
  , vname_prefix1    IN VARCHAR2
  , vname_suffix1    IN VARCHAR2
  , literal_type1    IN VARCHAR2
  , language_type1   IN VARCHAR2
  , long_value1      IN CLOB
  , value_type2      IN VARCHAR2
  , vname_prefix2    IN VARCHAR2
  , vname_suffix2    IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_timezone (
    value_type      IN VARCHAR2
  , vname_prefix    IN VARCHAR2
  , vname_suffix    IN VARCHAR2
  , literal_type    IN VARCHAR2
  , language_type   IN VARCHAR2
  , time_zone_func  IN PLS_INTEGER
  ) RETURN             MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$RDFTermString (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_substr (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , offset           IN NUMBER
  , len              IN NUMBER
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_ucase (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

 FUNCTION sparql_lcase (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , long_value       IN CLOB
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strbefore (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strafter (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_replace (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , reg_exp          IN VARCHAR2
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_concat (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  ) RETURN              MDSYS.SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_contains (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strlen (
    value_type       IN Varchar2
  , vname_prefix     IN Varchar2
  , vname_suffix     IN Varchar2
  , literal_type     IN Varchar2
  , language_type    IN Varchar2
  , long_value       IN CLOB
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strstarts (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_strends (
    value_types      IN SYS.ODCIVarchar2List
  , vname_prefixes   IN SYS.ODCIVarchar2List
  , vname_suffixes   IN SYS.ODCIVarchar2List
  , literal_types    IN SYS.ODCIVarchar2List
  , language_types   IN SYS.ODCIVarchar2List
  , long_values      IN MDSYS.RDF_CLOBS
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION sparql_uuid
  RETURN               VARCHAR2 PARALLEL_ENABLE;

  FUNCTION sparql_struuid
  RETURN               VARCHAR2 PARALLEL_ENABLE;

  FUNCTION sparql_encode_for_uri (
    value_name       IN VARCHAR2
  , do_unescape      IN NUMBER DEFAULT 1
  ) RETURN              VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;

  -- End SPARQL FILTER functions --

  -- Helper functions for SPARQL SOLUTION MODIFIER --
  FUNCTION getV$OrderFamily (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  ) RETURN              NUMBER DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION getV$CalendarOrderVal (
    value_type       IN VARCHAR2
  , vname_prefix     IN VARCHAR2
  , vname_suffix     IN VARCHAR2
  , literal_type     IN VARCHAR2
  , language_type    IN VARCHAR2
  , dir              IN VARCHAR2
  ) RETURN              TIMESTAMP WITH TIME ZONE DETERMINISTIC PARALLEL_ENABLE;

  -- End SPARQL SOLUTION MODIFIER functions --

  -- Character escaping/unescaping functions --
  FUNCTION unescape_rdf_value(
    val       IN VARCHAR2 CHARACTER SET ANY_CS
  , options   IN VARCHAR2 DEFAULT NULL
  ) RETURN  VARCHAR2 CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION unescape_clob_value(
    val           IN CLOB CHARACTER SET ANY_CS
  , start_offset  IN NUMBER   DEFAULT 1
  , end_offset    IN NUMBER   DEFAULT 0
  , include_start IN NUMBER   DEFAULT 0
  , options       IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION unescape_rdf_term(
    term      IN VARCHAR2 CHARACTER SET ANY_CS
  , options   IN VARCHAR2 DEFAULT NULL
  ) RETURN  VARCHAR2 CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION unescape_clob_term(
    term      IN CLOB CHARACTER SET ANY_CS
  , options   IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_rdf_value(
    val            IN VARCHAR2 CHARACTER SET ANY_CS
  , utf_encode     IN NUMBER   DEFAULT 1
  , allow_long     IN NUMBER   DEFAULT 0
  , options        IN VARCHAR2 DEFAULT NULL
  ) RETURN  VARCHAR2 CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_clob_value(
    val            IN CLOB CHARACTER SET ANY_CS
  , start_offset   IN NUMBER   DEFAULT 1
  , end_offset     IN NUMBER   DEFAULT 0
  , utf_encode     IN NUMBER   DEFAULT 1
  , include_start  IN NUMBER   DEFAULT 0
  , options        IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET val%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_rdf_term(
    term           IN VARCHAR2 CHARACTER SET ANY_CS
  , utf_encode     IN NUMBER   DEFAULT 1
  , options        IN VARCHAR2 DEFAULT NULL
  ) RETURN  VARCHAR2 CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;

  FUNCTION escape_clob_term(
    term           IN CLOB CHARACTER SET ANY_CS
  , utf_encode     IN NUMBER   DEFAULT 1
  , options        IN VARCHAR2 DEFAULT NULL
  ) RETURN  CLOB CHARACTER SET term%CHARSET DETERMINISTIC PARALLEL_ENABLE;
  -- End character escaping/unescaping functions --

  procedure set_session_param(param_name   in varchar2,
                              value        in boolean);
  function delete_triples( model_name  varchar2,
                           subject     varchar2,
                           property    varchar2,
                           object      varchar2) return number;

  PROCEDURE validate_geometries (model_name       IN VARCHAR2,
                                 SRID             IN NUMBER,
                                 tolerance        IN NUMBER,
                                 parallel         IN PLS_INTEGER default null,
                                 tablespace_name  IN VARCHAR2    default null,
                                 options          IN VARCHAR2    default null);

END rdf_apis;
/

