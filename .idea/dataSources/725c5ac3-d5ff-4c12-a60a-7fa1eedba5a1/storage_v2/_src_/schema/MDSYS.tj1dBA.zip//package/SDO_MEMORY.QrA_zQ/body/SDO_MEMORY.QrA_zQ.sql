create PACKAGE BODY       sdo_memory wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
1cf 117
BJdQhv+q2uSpXMXevo2MOr4MA8Ywgw3ImJ4VZy/pO06UhMVzOQr6uXDmHP3J6iE9ZhvKEXQU
3uQSSahv3+BrVbi+bhJ101wY2qyFfZ5ARU55659zHVA5+2f6YPcZgjcyhf/Bif3iNBihY8hU
3lCz8x91+pNw3C9hDS/kfEGSUjg6TmOtD4TekaHbhZQEPL5BcIfx9MBacXSXjty461bCSzZ+
sQxTMbweaWudnN65gSxci3OcWWDOMQFvdX5I1ylbZptbS4NWTgU9tjslN+c=
/

