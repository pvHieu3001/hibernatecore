create TYPE       sdo_geor_mosaic_0 wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
1bc e3
Wz+souhh07EymCkzAd6GKww5z7EwgzLX7Z4VfI5EcMEilaS6uONMdm6bW2AhPnjERLBpw9s1
4TNzNfN0wyNyklL/a8cXOEWL9Z1D6iOL3s9x8aaIqE3WPTYyRE9XHWy8JD5t9s7hq8V8WncS
9HlVSOlOTlpj2paeyczHDlfdsniVNwYOJNPADq1p2SwjVPnnpMe51vcUt06LKF9tISBnPYor
IHTZ6vs=
/

