create TYPE RDF_MATCH_impl_t authid current_user AS OBJECT
(
  curnum           integer,
  nCols            integer,
  done             integer,
  cnt              integer,        -- count, for count(*) optimization
  el_typ           SYS.AnyType,    -- return type
  attrset          SYS.ODCINumberList,
  isCLOBvec        SYS.ODCINumberList,
  startcnt         integer,
  iUseMagicSets    integer,
  modelIDs         SYS.ODCINumberList,
  rulebaseIds      SYS.ODCINumberList,
  filter           varchar2(4000),
  aliases          MDSYS.RDF_Aliases,
  index_status     varchar2(30),
  options          varchar2(4000),
  iBadFilter       integer,            -- 1 if we are handling bad filter special case
  iUnionQuery      integer,            -- 1 if this is a SPARQL UNION query
  coveringColsPos  SYS.ODCINumberList, -- positions of value_id columns in covering order
  currCoveringRow  SYS.ODCINumberList, -- value_ids of the current covering row
  unionKey         varchar2(4000),     -- identifier the current union component ... used to
                                       -- determine a covering relationship for union queries

  static function genVMExprHint(vmId NUMBER)
  return VARCHAR2,

  STATIC PROCEDURE record_given_and_trans_query(
    Query_Trans_Tabname     varchar2
  , trans_start_time        timestamp
  , trans_end_time          timestamp
  , given_query             varchar2
  , trans_query             varchar2
  , comments                varchar2 default NULL
  ),

  static function ODCIGetInterfaces(ifclist OUT SYS.ODCIObjectList)
  return number,

  static function ODCITableDescribe(rtype OUT SYS.AnyType,
                                    query         varchar2 character set any_cs,
                                    models        MDSYS.RDF_Models,
                                    rulebases     MDSYS.RDF_Rulebases,
                                    aliases       MDSYS.RDF_Aliases,
                                    filter        varchar2,
                                    index_status  varchar2 default NULL,
                                    options       varchar2 default null,
                                    graphs        MDSYS.RDF_Graphs default NULL,
                                    named_graphs  MDSYS.RDF_Graphs default NULL)
  return number,

  static function ODCITableRewrite(sctx         OUT RDF_MATCH_impl_t,
                                   ti           IN SYS.ODCITabFuncInfo,
                                   str          OUT CLOB,
                                   query        varchar2 character set any_cs,
                                   models_in    MDSYS.RDF_Models,
                                   rulebases_in MDSYS.RDF_Rulebases,
                                   aliases      MDSYS.RDF_Aliases,
                                   filter       varchar2,
                                   index_status varchar2 default NULL,
                                   options      varchar2 default null,
                                   graphs       MDSYS.RDF_Graphs default NULL,
                                   named_graphs MDSYS.RDF_Graphs default NULL)
  return number,

  static function ODCITablePrepare(sctx    OUT NOCOPY RDF_MATCH_impl_t,
                                   ti      IN         SYS.ODCITabFuncInfo,
                                   query              varchar2 character set any_cs,
                                   models             MDSYS.RDF_Models,
                                   rulebases          MDSYS.RDF_Rulebases,
                                   aliases            MDSYS.RDF_Aliases,
                                   filter             varchar2,
                                   index_status       varchar2 default NULL,
                                   options            varchar2 default null,
                                   graphs             MDSYS.RDF_Graphs default NULL,
                                   named_graphs       MDSYS.RDF_Graphs default NULL)
  return number,

  STATIC FUNCTION ODCITableStart(sctx    IN OUT NOCOPY RDF_MATCH_impl_t,
                                 query                 varchar2 character set any_cs,
                                 models_in             MDSYS.RDF_Models,
                                 rulebases_in          MDSYS.RDF_Rulebases,
                                 aliases               MDSYS.RDF_Aliases,
                                 filter                varchar2,
                                 index_status          varchar2 default NULL,
                                 options               varchar2 default null,
                                 graphs                MDSYS.RDF_Graphs default NULL,
                                 named_graphs          MDSYS.RDF_Graphs default NULL)
  RETURN PLS_INTEGER ,

  MEMBER FUNCTION ODCITableFetch(self   IN OUT NOCOPY RDF_MATCH_impl_t,
                                 nrows  IN            NUMBER,
                                 outSet OUT NOCOPY    SYS.AnyDataSet)
  RETURN PLS_INTEGER,

  MEMBER FUNCTION Fetch_CountStar(self   IN OUT NOCOPY RDF_MATCH_impl_t,
                                  nrows  IN            NUMBER,
                                  outSet OUT NOCOPY    SYS.AnyDataSet)
  RETURN PLS_INTEGER,

  MEMBER FUNCTION ODCITableClose(self IN RDF_MATCH_impl_t)
  RETURN PLS_INTEGER,

  MEMBER PROCEDURE dump,

  STATIC FUNCTION getTdwnOpt
  RETURN VARCHAR2,

  STATIC PROCEDURE populateGraphs(graphs              MDSYS.RDF_Graphs,
                                  named_graphs        MDSYS.RDF_Graphs,
                                  sGraphs      IN OUT MDSYS.RDF_Graphs,
                                  sNamedGraphs IN OUT MDSYS.RDF_Graphs),

  STATIC FUNCTION R_PARSE_SPARQL(sctx             RDF_MATCH_impl_t,
                               ps_attrset         SYS.ODCINumberList,
                               query              varchar2,
                               models             MDSYS.RDF_Models,
                               modelIDs           SYS.ODCINumberList,
                               rulebaseIDs        SYS.ODCINumberList,
                               graphs             MDSYS.RDF_Graphs,
                               named_graphs       MDSYS.RDF_Graphs,
                               aliases            MDSYS.RDF_Aliases,
                               filter             varchar2,
                               reqIdxStatus       varchar2,
                               precompIdx     OUT varchar2,
                               precompIdxId   OUT number,
                               stmt IN OUT NOCOPY MDSYS.RDF_longVarcharArray,
                               options            varchar2,
                               vmViewName         varchar2,
                               flag_out       OUT int,
                               model_types        SYS.ODCINumberList,
                               isRdfVModel        number,
                               vmId               number)
  return number,

  STATIC FUNCTION PARSE_SPARQL(sctx IN OUT NOCOPY RDF_MATCH_impl_t,
                               query               varchar2,
                               models  IN OUT      MDSYS.RDF_Models,
                               modelIDs IN OUT     SYS.ODCINumberList,
                               rulebaseIDs         SYS.ODCINumberList,
                               graphs              MDSYS.RDF_Graphs,
                               named_graphs        MDSYS.RDF_Graphs,
                               aliases             MDSYS.RDF_Aliases,
                               filter              varchar2,
                               reqIdxStatus        varchar2,
                               precompIdx     OUT  varchar2,
                               options             varchar2,
                               vmViewName          varchar2,
                               vmId                number,
                               model_types         SYS.ODCINumberList,
                               isRdfVModel         number)
  return number,

  MEMBER FUNCTION belongsInResult(self IN OUT NOCOPY RDF_MATCH_impl_t)
  return boolean,

  STATIC FUNCTION extractBindVals(options  varchar2)
  return SYS.ODCIVarchar2List,

  STATIC PROCEDURE SPARQL_to_SQL(attrs       SYS.ODCINumberList,
                                 query       varchar2,
                                 models      RDF_Models,
                                 precompIdx  varchar2,
                                 idxStatus   varchar2,
                                 nsp         MDSYS.RDF_Aliases,
                                 flag        number,
                                 str_out OUT RDF_longVarcharArray,
                                 sig_out OUT RDF_varcharArray) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       java.lang.String,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[])',


  STATIC PROCEDURE SPARQL_to_SQL(attrs              SYS.ODCINumberList,
                                 query              varchar2,
                                 models             RDF_Models,
                                 precompIdx         varchar2,
                                 precompIdxID       number,
                                 idxStatus          varchar2,
                                 defaultGIDs        SYS.ODCINumberList,
                                 namedGIDs          SYS.ODCINumberList,
                                 defaultMIDs        SYS.ODCINumberList,
                                 defaultModels      MDSYS.RDF_Models,
                                 nsp                MDSYS.RDF_Aliases,
                                 flag               number,
                                 str_out        OUT RDF_longVarcharArray,
                                 sig_out        OUT RDF_varcharArray,
                                 options            varchar2,
                                 vmViewName         varchar2,
                                 flag_out       OUT number,
                                 valIdCover_out OUT SYS.ODCINumberList,
                                 orderBy_out    OUT varchar2,
                                 model_types        SYS.ODCINumberList,
                                 isRDFVModel        number) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQueryPattern(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       long,
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY,
       int,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[],
       java.lang.String,
       java.lang.String,
       int[],
       oracle.sql.ARRAY[],
       java.lang.String[],
       oracle.sql.ARRAY,
       int)',

  STATIC FUNCTION SPARQL_to_PRED(attrs       SYS.ODCINumberList,
                                 query       varchar2,
                                 models      RDF_Models,
                                 precompIdx  varchar2,
                                 idxStatus   varchar2,
                                 nsp         MDSYS.RDF_Aliases,
                                 flag        number)
 return sem_pred_array as
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.translateQuerytoPredicates(
       oracle.sql.ARRAY,
       java.lang.String,
       oracle.sql.ARRAY,
       java.lang.String,
       java.lang.String,
       oracle.sql.ARRAY,
       int)
  return oracle.sql.ARRAY',

  STATIC FUNCTION SPARQL_get_cols(query varchar2,
                                  hint  varchar2)
  return RDF_varcharArray as
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getPatternVariables(
       java.lang.String,
       java.lang.String)
  return oracle.sql.STRUCT',

  STATIC PROCEDURE SPARQL_get_sources(query             varchar2,
                                      nsp               MDSYS.RDF_Aliases,
                                      defaultG_out  OUT MDSYS.RDF_GRAPHS,
                                      namedG_out    OUT MDSYS.RDF_GRAPHS) is
  language java name
    'oracle.spatial.rdf.server.SQLEntryPoints.getSources(
       java.lang.String,
       oracle.sql.ARRAY,
       oracle.sql.ARRAY[],
       oracle.sql.ARRAY[])'
)
/

