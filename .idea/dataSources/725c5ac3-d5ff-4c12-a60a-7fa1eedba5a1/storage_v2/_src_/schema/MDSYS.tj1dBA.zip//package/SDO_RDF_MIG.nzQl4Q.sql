create PACKAGE sdo_rdf_mig wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
ee c2
S+88mBbaMSUeP+ZKBSJJ8r63LA0wg/BKmJ4VaS+iO3MYYpTYfl47mIw5u20u4s3fNS3Iqfkk
zn3b59yCfB0HXlTLNB1VB7MgavpknIJSeEnFp0SjshQ5ue7outCT8xEI0a52NXlR7xOKMTzV
/EK2fC0kUmRayyro9J2fS2RCMc9UTUOb0GqWb/HfA1uZTSLG
/

