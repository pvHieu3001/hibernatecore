create PACKAGE       sdo_memory wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
94 a6
4vU2REWUhQXGIjRiS0Jf7MuxiVYwg5m49TOf9b9cFtz60HIu19eW5cO4dLIIpfXMuMuynsCB
mfQosp+yCbh0i+EdRAKpyqoX6pxQyuoCjy/GDsgwD+oPtQ6FMBco6hcg9sNE4j/Rzhqv4HxE
IuJKykIOb/Y5ppoJSZ8=
/

