create Type notification_msg as object (
      object_id     INTEGER,
      region_id     INTEGER,
      time          TIMESTAMP,
      x             NUMBER,
      y             NUMBER,
      state         VARCHAR2(8))
/

