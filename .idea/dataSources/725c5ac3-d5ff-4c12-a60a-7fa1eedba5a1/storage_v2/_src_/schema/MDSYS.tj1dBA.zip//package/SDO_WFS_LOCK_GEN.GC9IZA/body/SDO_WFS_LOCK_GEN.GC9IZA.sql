create PACKAGE BODY       SDO_WFS_LOCK_GEN wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
ec f3
HatkBaJ//jtX5nJ3RxOrawBeqHswg+ncmG+sfHQyueqRuFACr40+oPsSFiboPpd3tbWZbcrJ
Wv++vmRbg/NbrNFFRPFtQz2w01Gk2Wd+fIjrF2H874REWmmhhlqKpOfeb0CIlRnMSGn6a+RB
brBKGiqkskGyircWyFx1caMJTmOn0np4WSCQf6kX8KX+fWzcS2VM1FAcGxK5o98KKNdvXFwB
zVKt0rE8BODq/p+uLOuDehU=
/

