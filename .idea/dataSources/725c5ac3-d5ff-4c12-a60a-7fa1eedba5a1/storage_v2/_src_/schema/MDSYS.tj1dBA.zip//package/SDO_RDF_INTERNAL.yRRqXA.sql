create PACKAGE sdo_rdf_internal  AS

  -- constants for network compression
  COMPRESS_FLAG CONSTANT VARCHAR2(8) := 'COMPRESS';
  -- ROW STORE COMPRESS BASIC
  COMPRESS_RSCB_FLAG     CONSTANT VARCHAR2(13)  := 'COMPRESS=RSCB';
  COMPRESS_RSCB_COMMAND  CONSTANT VARCHAR2(26)  := ' COMPRESS ';
  -- ROW STORE COMPRESS ADVANCED
  COMPRESS_RSCA_FLAG     CONSTANT VARCHAR2(13)  := 'COMPRESS=RSCA';
  COMPRESS_RSCA_COMMAND  CONSTANT VARCHAR2(29)  := ' COMPRESS FOR OLTP ';
  -- COLUMN STORE COMPRESS FOR QUERY HIGH
  COMPRESS_CSCQH_FLAG    CONSTANT VARCHAR2(14)  := 'COMPRESS=CSCQH';
  COMPRESS_CSCQH_COMMAND CONSTANT VARCHAR2(38)  := ' COMPRESS FOR QUERY HIGH ';
  -- COLUMN STORE COMPRESS FOR QUERY LOW
  COMPRESS_CSCQL_FLAG    CONSTANT VARCHAR2(14)  := 'COMPRESS=CSCQL';
  COMPRESS_CSCQL_COMMAND CONSTANT VARCHAR2(37)  := ' COMPRESS FOR QUERY LOW ';
  -- DEFAULT compression
  COMPRESS_DEFAULT_FLAG  CONSTANT VARCHAR2(512) := COMPRESS_RSCB_FLAG;

  -- constants for syntax related regular expression
  REGEXP_BNODE_SYNTAX    CONSTANT VARCHAR2(100) := '^(_:)[[:alpha:]_][[:alnum:]_-]*$';

  -- constants for rules index status values
  RIDX_VALID      CONSTANT VARCHAR2(5)  := 'VALID';
  RIDX_INCOMPLETE CONSTANT VARCHAR2(10) := 'INCOMPLETE';
  RIDX_INVALID    CONSTANT VARCHAR2(7)  := 'INVALID';
  RIDX_INPROGRESS CONSTANT VARCHAR2(10) := 'INPROGRESS';
  RIDX_NORIDX     CONSTANT VARCHAR2(6)  := 'NORIDX';
  RIDX_VERSIONED  CONSTANT VARCHAR2(10) := 'VERSIONED';

  -- constants for named graph-related flags
  FLAG_PROJ_ALL_COLUMNS  CONSTANT SIMPLE_INTEGER      := 1;
  FLAG_NG_ALL_UNNAMED    CONSTANT SIMPLE_INTEGER      := 32;
  FLAG_USE_ENT_UNNAMED   CONSTANT SIMPLE_INTEGER      := 64;

  -- constants for model types: ids and names
  MODEL_TYPE_ID_REGULAR   CONSTANT SIMPLE_INTEGER :=     1;
  MODEL_TYPE_ID_VIRTUAL   CONSTANT SIMPLE_INTEGER :=     2;
  MODEL_TYPE_ID_RDFCTX    CONSTANT SIMPLE_INTEGER :=     4;
  MODEL_TYPE_ID_RDB2RDF   CONSTANT SIMPLE_INTEGER :=     8;
  MODEL_TYPE_ID_VERSIONED CONSTANT SIMPLE_INTEGER :=     16;

  MODEL_TYPE_REGULAR   CONSTANT CHAR(1) :=     'M';
  MODEL_TYPE_VIRTUAL   CONSTANT CHAR(1) :=     'V';
  MODEL_TYPE_RDFCTX    CONSTANT CHAR(1) :=     'X';
  MODEL_TYPE_RDB2RDF   CONSTANT CHAR(1) :=     'D';
  MODEL_TYPE_VERSIONED CONSTANT CHAR(1) :=     'W';

  RDF$pv_M_G_SPTR  CONSTANT VARCHAR2(10) := ':'; -- Model/Graph name SeParaToR
  RDF$pv_MID_BITS  CONSTANT SIMPLE_INTEGER := 32; --4294967295; -- bits 0-31
  RDF$pv_GID_BITS  CONSTANT SIMPLE_INTEGER := 64; --79228162514264337589248983040; --bits 32-95


  DEFAULT_BATCHLOAD_TMP_TAB_NAME CONSTANT VARCHAR2(30) DEFAULT 'RDF_LINK$_TEMPBM$';

  DEFAULT_MODEL_ID CONSTANT NUMBER := 0;

  -- constants for data type indexes
  GEO_MDATA_COL         CONSTANT VARCHAR2(200) :=
      'mdsys.sdo_rdf.getv$geometryval(value_type,vname_prefix,vname_suffix,literal_type,language_type,long_value,';
  GEO_MDATA_MCOL        CONSTANT VARCHAR2(4) := 'GEOM';

  -- record type to remember info for the current call (NOT for session)
  type callContextRecord_type is record (
    subpartitioning_type     VARCHAR2(30) -- from SYS.all_part_tables
  , def_subpartition_count   NUMBER       -- from SYS.all_part_tables
  , model_triple_cnt         NUMBER       -- via select count(*)
  , model_partition_cnt      NUMBER       -- from SYS.all_tab_subpartitions
  , model_partition_clause   VARCHAR2(4000)  -- for use in table creation
  , model_index_local_clause VARCHAR2(100)   -- LOCAL or not
  , TL_partition_type        VARCHAR2(30) -- REMEMBER after creating the RDF$TL table
  , TL_partition_clause      VARCHAR2(4000) -- REMEMBER partition_clause [ONLY IF TL_partitioning_type=MODEL_PARTITIONING]
  , enable_pdml_hint         VARCHAR2(100) -- query-scope PDML hint
  , proc_sig                 VARCHAR2(200) -- poc_sig for a BLFST
  , proc_sid                 VARCHAR2(30)  -- poc_sid for a BLFST
  , Bad_Rows_Tabname         VARCHAR2(30)
  , value_errors_cnt         NUMBER
  , bad_rows_cnt             NUMBER
  );

  PROCEDURE set_network_partition_info;
  PROCEDURE set_model_partition_info (modelID number);
  FUNCTION  get_model_pxn_clause RETURN VARCHAR2;
  FUNCTION  get_model_idx_clause RETURN VARCHAR2;

  -- given two sql templates, returns true or false to indicate they are matchable (by checking min-pfx and min-sfx)
  --FUNCTION matchableSqlTemplatePair(sqlTemplate1 VARCHAR2, sqlTemplate2 VARCHAR2, ctx_R2RFlags NUMBER) RETURN BOOLEAN;

  FUNCTION get_rules_index_pname(index_name IN VARCHAR2) RETURN VARCHAR2;

  procedure create_rdf_ddl_trigger;

  procedure create_rdf_triggers(model_name varchar2, tab_owner_name varchar2 default null);
  --
  -- TYPE_FAMILY: Given a type, returns type's "family": 'STRING', 'NUMERIC',
  -- 'DATE', 'TIME', 'DATETIME', or 'OTHER'.
  --
  FUNCTION TYPE_FAMILY(
      literal_type varchar2, flags varchar2 default null)
    return varchar2 deterministic;
  pragma restrict_references (type_family, WNDS, RNDS, WNPS, RNPS);

  -- value replacement
  PROCEDURE FIND_VALUES_TO_REPLACE (
    valueMapTab_owner        varchar2
  , valueMapTab_name         varchar2
  , esc_reserved_chars       boolean default false
  , options                  varchar2 default NULL
  );

  PROCEDURE REPLACE_VALUES (
    valueMapTab_owner        varchar2
  , valueMapTab_name         varchar2
  , options                  varchar2 default NULL
  );

  -- exposed for testing collision handling
  PROCEDURE LOAD_BATCH_VALUES_TABLE (
    Batch_Values_Tab       IN  varchar2
  , tbs_name               IN  varchar2
  , Staging_Tab            IN  varchar2
  , modelID                IN  number
  , Event_Trace_Tab        IN  varchar2
  , flags                  IN  varchar2
  , owner                  IN  varchar2 default 'MDSYS'
  , Bad_Rows_Tab           IN  dbms_id default NULL
  );

  PROCEDURE MERGE_BATCH_VALUES (
    Batch_Values_Tab           IN  varchar2
  , modelID                    IN  number
  , owner                      IN  varchar2 default 'MDSYS'
  , collision_cnt              IN  number default 0
  , Event_Trace_Tabname        IN  varchar2 default NULL
  , flags                      IN  varchar2 default NULL
  );

  PROCEDURE REMOVE_IM_VIRTUAL_COLUMNS;

  -- functions to extract parts from lex_value stored in staging table
  FUNCTION pov_value_name (ov varchar2) RETURN varchar2 DETERMINISTIC;
  pragma restrict_references (pov_value_name,WNDS,RNDS,WNPS,RNPS);
  FUNCTION pov_value_type (ov varchar2) RETURN varchar2 DETERMINISTIC;
  pragma restrict_references (pov_value_type,WNDS,RNDS,WNPS,RNPS);
  FUNCTION pov_literal_type (ov varchar2) RETURN varchar2 DETERMINISTIC;
  pragma restrict_references (pov_literal_type,WNDS,RNDS,WNPS,RNPS);
  FUNCTION pov_language_type (ov varchar2) RETURN varchar2 DETERMINISTIC;
  pragma restrict_references (pov_language_type,WNDS,RNDS,WNPS,RNPS);

  -- functions exposed here just for testing: not for general use
  FUNCTION validate_user_options (flags VARCHAR2)
  RETURN NUMBER deterministic;

  function check_user_option (flags varchar2, item varchar2)
  return boolean deterministic;

  function get_user_option_choice (flags varchar2, item varchar2)
  return varchar2 deterministic;

  -- check for validity of decimal (or integer, if flags contains INTEGER): returns NULL if valid
  FUNCTION chk_numeric (val varchar2, ltype varchar2, flags varchar2 default null) return varchar2 deterministic parallel_enable;
           pragma restrict_references (chk_numeric,WNDS,RNDS,WNPS,RNPS);

  -- function to obtain canonical value for a lex value (NULL if identical)
  function get_canon_val_null (lexval varchar2, flags varchar2 default null) return varchar2 deterministic parallel_enable;
  pragma restrict_references (get_canon_val_null,WNDS,RNDS,WNPS,RNPS);

  -- function to obtain canonical entry for a lex value (used by user-defined inference rules logic)
  function get_canon_term (
    lexval     varchar2
  , model_id   number
  , pos        varchar2
  , model_name varchar2 default null
  , flags      varchar2 default null)
  return sdo_rdf_term deterministic parallel_enable;

  -- convenience method
  function get_canon_id (
    lexval     varchar2
  , model_id   number
  , pos        varchar2
  , model_name varchar2 default null
  , flags      varchar2 default null)
  return number deterministic parallel_enable;

  -- function to validate/convert user-supplied names for owner,table,col,tbs..
  FUNCTION validate_and_convert_name (name VARCHAR2)
  RETURN VARCHAR2 DETERMINISTIC;

  -- function to validate/convert user-supplied names for model, vm, rb, ridx
  FUNCTION val_cvt_rdf_name (name VARCHAR2)
  RETURN VARCHAR2 DETERMINISTIC;

  -- function to convert numeric pos code (0..7) to list of sub/pred/obj
  FUNCTION get_pos_list_from_code (pos_code NUMBER)
    RETURN varchar2 deterministic parallel_enable;

  -- procedure to update collision summary
  PROCEDURE UPDATE_COLLISION_SUMMARY;
  PROCEDURE CHECK_CLEAR_COLLISION_SUMMARY (options varchar2 default null);

  -- decodes model-graph: returns model and graph name
  FUNCTION decode_model_name (
    model_name           VARCHAR2
  , graph            OUT VARCHAR2
  ) RETURN               VARCHAR2 deterministic;

  -- main routine for batch load from staging table
  PROCEDURE BULK_LOAD_FROM_STAGING_TABLE (
    model               IN            varchar2,
    staging_table_owner IN            varchar2,
    staging_table_name  IN            varchar2,
    user_name           IN            varchar2,
    flags               IN            varchar2 default NULL,
    debug               IN            PLS_INTEGER default NULL,
    start_comment       IN            varchar2 default NULL,
    end_comment         IN            varchar2 default NULL,
    roles_and_privs     IN            varchar2 default ' MDSYS.RDF_PRIV$:READ '
  );

  PROCEDURE RESUME_LOAD_FROM_STAGING_TABLE (
    model               IN              varchar2,
    staging_table_owner IN              varchar2,
    staging_table_name  IN              varchar2,
    session_id          IN              varchar2,
    user_name           IN              varchar2,
    flags               IN              varchar2 default NULL,
    start_comment       IN              varchar2 default NULL,
    end_comment         IN              varchar2 default NULL
  );

  -- invalidates cursors with unresolved values
  PROCEDURE refresh_query_state;

  FUNCTION check_lexval_for_validity(
    lexval  varchar2
  , min_pos PLS_INTEGER
  , options varchar2 default NULL
  ) RETURN  varchar2 deterministic parallel_enable;
  pragma restrict_references (check_lexval_for_validity,WNDS,RNDS,WNPS,RNPS);

  FUNCTION chklex(
    lexval  varchar2
  ) RETURN  NUMBER deterministic parallel_enable;
  pragma restrict_references (chklex,WNDS,RNDS,WNPS,RNPS);

  FUNCTION esclex (
    lexval varchar2 CHARACTER SET ANY_CS
  , esc_reserved_chars_bit pls_integer default 0
  , options varchar2 default null
  ) RETURN varchar2 CHARACTER SET lexval%CHARSET deterministic parallel_enable;
  --pragma restrict_references (esclex,WNDS,RNDS,WNPS,RNPS);

  -- replace prefix at beginning with expanded form
  FUNCTION replace_rdf_prefix (
    string                       VARCHAR2
  , options                      VARCHAR2 default NULL
  ) RETURN                       VARCHAR2 deterministic;
  pragma restrict_references (replace_rdf_prefix,WNDS,RNDS,WNPS,RNPS);

  PROCEDURE CREATE_PARALLEL_HINTS (
    flags             VARCHAR2
  , dop           OUT PLS_INTEGER -- NULL=>non-parallel,0=>default,otherwise n
  , par_hint1     OUT VARCHAR2
  , par_hint2     OUT VARCHAR2
  , par_hint3     OUT VARCHAR2
  , table_name1       VARCHAR2 default NULL
  , table_name2       VARCHAR2 default NULL
  , table_name3       VARCHAR2 default NULL
  , skip_parallel     VARCHAR2 default NULL
  ) deterministic parallel_enable;

  PROCEDURE get_geo_mindex_info(
    spa_m_idx_exists  OUT BOOLEAN
  , srid              OUT NUMBER
  );

  FUNCTION get_object_node_type (object CLOB) RETURN VARCHAR2 deterministic;
  FUNCTION get_literal (object IN CLOB) RETURN CLOB deterministic;
  FUNCTION get_literaltype (object IN CLOB) RETURN VARCHAR2 deterministic;

  FUNCTION get_model_id (
    model_name       IN  VARCHAR2
  , flags            IN  VARCHAR2 default NULL
  ) RETURN               NUMBER;

  FUNCTION get_model_name (
    model_id         IN  NUMBER
  , flags            IN  VARCHAR2 default NULL
  ) RETURN               VARCHAR2;

  PROCEDURE GET_USER_SPEC_BATCH_VALUES_TAB (
    flags              IN  varchar2
  , table_name         OUT varchar2
  , owner_name         OUT varchar2
  );

  -- given model id, return tablespace name
  FUNCTION GET_TABLESPACE_NAME( modelID IN number DEFAULT DEFAULT_MODEL_ID ) RETURN VARCHAR2 DETERMINISTIC;

  -- given model name, return owner, model Id, app table name and col name
  PROCEDURE GET_MODEL_INFO (
    model_owner OUT varchar2
  , model_name  IN  varchar2
  , modelID     OUT number
  , App_Tabname OUT varchar2
  , App_Colname OUT varchar2
  , flags       IN  varchar2 default NULL
  );

  FUNCTION is_triple (
    model_id             NUMBER
  , subject              VARCHAR2
  , property             VARCHAR2
  , object               VARCHAR2
  , model_name           VARCHAR2 default NULL
  ) RETURN               VARCHAR2;

  FUNCTION is_triple (
    model_id             NUMBER
  , subject              VARCHAR2
  , property             VARCHAR2
  , object               CLOB
  , model_name           VARCHAR2 default NULL
  ) RETURN               VARCHAR2;



  FUNCTION is_reified (
    model_id           NUMBER
  , rdf_t_id           VARCHAR2
  ) RETURN             VARCHAR2;

  FUNCTION is_reified (
    model_name         VARCHAR2
  , rdf_t_id           VARCHAR2
  ) RETURN             VARCHAR2;

  FUNCTION is_reified (
    model_id           NUMBER
  , subject            VARCHAR2
  , property           VARCHAR2
  , object             VARCHAR2
  ) RETURN             VARCHAR2;

  FUNCTION is_reified (
    model_name         VARCHAR2
  , subject            VARCHAR2
  , property           VARCHAR2
  , object             VARCHAR2
  ) RETURN             VARCHAR2;

  FUNCTION get_triple_cost (
    model_id         IN  NUMBER
  , sub_id           IN  NUMBER
  , pred_id          IN  NUMBER
  , canon_id         IN  NUMBER
  ) RETURN               NUMBER;

  PROCEDURE set_triple_cost(
    model_id         IN  NUMBER
  , sub_id           IN  NUMBER
  , pred_id          IN  NUMBER
  , canon_id         IN  NUMBER
  );

  PROCEDURE delete_link$_id (
    model_id         IN  NUMBER
  , sub_id           IN  NUMBER
  , pred_id          IN  NUMBER
  , canon_id         IN  NUMBER
  );


  PROCEDURE decr_link_cost_del_if_zeroed (
    model_id         IN  NUMBER
  , sub_id           IN  NUMBER
  , pred_id          IN  NUMBER
  , canon_id         IN  NUMBER
  , label_num        IN  NUMBER DEFAULT NULL
  , res_level_ols    IN  BOOLEAN DEFAULT FALSE
  );

  PROCEDURE parse_subject_node (
    v_subject        IN  VARCHAR2
  , sv_type          IN  VARCHAR2
  , sv_id            OUT NUMBER
  , new_sv           OUT BOOLEAN
  );

  PROCEDURE parse_property_value (
    v_property       IN  VARCHAR2
  , pv_type          IN  VARCHAR2
  , pv_id            OUT NUMBER
  , new_pv           OUT BOOLEAN
  , flags            IN  VARCHAR2 DEFAULT NULL
  );

  PROCEDURE parse_object_node (
    v_object         IN  VARCHAR2
  , lit_type         IN  VARCHAR2
  , lit_lang         IN  VARCHAR2
  , ov_type          IN  VARCHAR2
  , ov_id            OUT NUMBER
  , cov_id           OUT NUMBER
  , new_ov           OUT BOOLEAN
  );

  PROCEDURE parse_object_node (
    v_object         IN  CLOB
  , lit_type         IN  VARCHAR2
  , lit_lang         IN  VARCHAR2
  , ov_type          IN  VARCHAR2
  , ov_id            OUT NUMBER
  , cov_id           OUT NUMBER
  , new_ov           OUT BOOLEAN
  );

  -- used in before row insert/update trigger on app-table (triple col)
  PROCEDURE parse_triple (
    m_id             IN  NUMBER
  , pv_id            IN  NUMBER
  , sv_id            IN  NUMBER
  , ov_id            IN  NUMBER
  , cov_id           IN  NUMBER
  , new_sv           IN  BOOLEAN
  , new_ov           IN  BOOLEAN
  , new_pv           IN  BOOLEAN
  , pl_id            OUT NUMBER
  , label_num        IN  NUMBER DEFAULT NULL
  , triple_level_ols IN  BOOLEAN DEFAULT FALSE
  );

  PROCEDURE insert_triple (
    m_id             IN  NUMBER
  , subject          IN  VARCHAR2
  , property         IN  VARCHAR2
  , object           IN  VARCHAR2
  , pl_id            OUT NUMBER
  , sv_id            OUT NUMBER
  , pv_id            OUT NUMBER
  , ov_id            OUT NUMBER
  , batch_mode       IN  BOOLEAN -- true => old batch mode insert(from NTriple)
  , reuse_mode       IN  BOOLEAN -- true => reuse blank nodes from same model
  , m_name           IN  VARCHAR2 default NULL -- (chg to REQUIRED param) model name optionally including graph name
  , nonauto          IN  BOOLEAN  default FALSE -- true => use non-autonomous value creation
  );

  PROCEDURE insert_triple (
    m_id             IN  NUMBER
  , subject          IN  VARCHAR2
  , property         IN  VARCHAR2
  , object           IN  CLOB -- CLOB version
  , pl_id            OUT NUMBER
  , sv_id            OUT NUMBER
  , pv_id            OUT NUMBER
  , ov_id            OUT NUMBER
  , batch_mode       IN  BOOLEAN -- true => old batch mode insert(from NTriple)
  , reuse_mode       IN  BOOLEAN -- true => reuse blank nodes from same model
  , m_name           IN  VARCHAR2 default NULL -- (chg to REQUIRED param) model name optionally including graph name
  , nonauto          IN  BOOLEAN  default FALSE -- true => use non-autonomous value creation
  );

  PROCEDURE start_batch$ (
    roles_and_privs       IN  VARCHAR2
  , current_user_name     IN  VARCHAR2
  , tempTblName           IN  VARCHAR2
  , model_id              IN  NUMBER
  , model_name            IN  VARCHAR2
  , rdf_tablespace        IN  VARCHAR2
  );

  PROCEDURE start_batch$ (
    roles_and_privs       IN  VARCHAR2
  , current_user_name     IN  VARCHAR2
  , tempTblName           IN  VARCHAR2
  , model_id              IN  NUMBER
  , model_name            IN  VARCHAR2
  , rdf_tablespace        IN  VARCHAR2
  , exchange              IN  NUMBER DEFAULT NULL
  );

  PROCEDURE start_batch$ (
    roles_and_privs       IN  VARCHAR2
  , current_user_name     IN  VARCHAR2
  , model_id              IN  NUMBER
  , model_name            IN  VARCHAR2
  , rdf_tablespace        IN  VARCHAR2
  );

  PROCEDURE start_batch$ (
    roles_and_privs       IN  VARCHAR2
  , current_user_name     IN  VARCHAR2
  , model_id              IN  NUMBER
  , model_name            IN  VARCHAR2
  , rdf_tablespace        IN  VARCHAR2
  , exchange              IN  NUMBER
  );

  -- used in before row insert/update trigger on app-table (triple col)
  PROCEDURE parse_triple_batch_mode (
    m_id             IN  NUMBER
  , pv_id            IN  NUMBER
  , sv_id            IN  NUMBER
  , ov_id            IN  NUMBER
  , cov_id           IN  NUMBER
  , new_sv           IN  BOOLEAN
  , new_ov           IN  BOOLEAN
  , new_pv           IN  BOOLEAN
  , pl_id            OUT NUMBER
  );

  PROCEDURE exchange_model_part$ (
    roles_and_privs       IN  VARCHAR2
  , current_user_name     IN  VARCHAR2
  , model_id       IN  NUMBER
  , rdf_tablespace IN  VARCHAR2
  );

  function get_value$_type$_func (
    model_id    NUMBER
  , lexval      VARCHAR2
  , pos         VARCHAR2 -- 'SUBJECT', 'PREDICATE', or 'OBJECT'
  , model_name  VARCHAR2 default NULL
  ) return sdo_rdf_term deterministic parallel_enable;

  PROCEDURE get_value$_type$ (
    model_id      IN     NUMBER
  , subject       IN OUT VARCHAR2
  , property      IN OUT VARCHAR2
  , object        IN OUT VARCHAR2
  , sv_type       OUT    VARCHAR2
  , pv_type       OUT    VARCHAR2
  , ov_type       OUT    VARCHAR2
  , lit_type      OUT    VARCHAR2
  , lit_lang      OUT    VARCHAR2
  , model_name    IN     VARCHAR2 default NULL -- model name opt w/ graph name
  );

  PROCEDURE get_value$_type$ (
    model_id      IN     NUMBER
  , subject       IN OUT VARCHAR2
  , property      IN OUT VARCHAR2
  , object        IN OUT CLOB
  , sv_type          OUT VARCHAR2
  , pv_type          OUT VARCHAR2
  , ov_type          OUT VARCHAR2
  , lit_type         OUT VARCHAR2
  , lit_lang         OUT VARCHAR2
  , model_name    IN     VARCHAR2 default NULL -- model name opt w/ graph name
  );

  PROCEDURE refresh_sem_tablespace_names (
    model_name                 VARCHAR2 default NULL  -- NULL => all
  , user_id                    NUMBER default NULL    -- NULL => DBA
  );

  PROCEDURE create_rdf_model (
    model_name       IN  VARCHAR2
  , table_name       IN  VARCHAR2
  , column_name      IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , model_tablespace IN  VARCHAR2 default NULL
  , tab_owner_name   IN  VARCHAR2 default NULL
  , model_type_id    IN  NUMBER   default sdo_rdf_internal.MODEL_TYPE_ID_REGULAR
  , options          IN  VARCHAR2 default NULL
  );

  PROCEDURE drop_rdf_model (model_name IN VARCHAR2, user_name IN VARCHAR2,
                            tab_owner_name IN VARCHAR2 default NULL);

  PROCEDURE create_rdf_model_views (
    model_name       IN  VARCHAR2
  , model_id         IN  NUMBER
  , model_type       IN  VARCHAR2
  , semmToo          IN  BOOLEAN
  , recreate         IN  BOOLEAN
  , user_name        IN  VARCHAR2
  , options          IN  VARCHAR2 default NULL
  );

  FUNCTION GetVal(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC;

  FUNCTION GetPref(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC;

  FUNCTION GetSuff(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC;

  FUNCTION GetValTyp(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC;

  FUNCTION GetOrdTyp(i_id NUMBER)
         RETURN NUMBER DETERMINISTIC;

  FUNCTION GetOrdNum(i_id NUMBER)
         RETURN NUMBER DETERMINISTIC;

  FUNCTION GetOrdDate(i_id NUMBER)
         RETURN TIMESTAMP WITH TIME ZONE DETERMINISTIC;

  FUNCTION GetLitType(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC;

  FUNCTION GetLangType(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC;

 /* FUNCTION GetRDFTerm(i_id NUMBER)
         RETURN VARCHAR2 DETERMINISTIC;*/

-- handle in-memory population
  PROCEDURE adjust_imvc_partition;

  /**
   * Note only owner of models and rules index (or sys dba) can
   * create a virtual model.
   */
  PROCEDURE create_virtual_model (
    vm_name          IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , roles_and_privs  IN  VARCHAR2
  , models           IN  MDSYS.RDF_Models default NULL
  , rulebases        IN  MDSYS.RDF_Rulebases default NULL
  , options          IN  VARCHAR2 default NULL
  , entailments      IN  MDSYS.RDF_Entailments default NULL
  );

  /**
   * Creates the duplicates view for a given virtual model
   */
  PROCEDURE create_virtual_model_v_view (
    vm_name        IN VARCHAR2
  , pIDs           IN SYS.ODCINumberList
  , recreate       IN BOOLEAN
  , inmemory       IN BOOLEAN
  , options        IN VARCHAR2 default NULL
  );

  /**
   * Creates the unique view for a given virtual model
   */
  PROCEDURE create_virtual_model_u_view (
    vm_name        IN VARCHAR2
  , pIDs           IN SYS.ODCINumberList
  , recreate       IN BOOLEAN
  , inmemory       IN BOOLEAN
  );

  /**
   * Note only owner of virtual model (or sys dba) can
   * drop the virtual model.
   */
  PROCEDURE drop_virtual_model (vm_name IN VARCHAR2, user_name IN VARCHAR2, roles_and_privs VARCHAR2);

  PROCEDURE truncate_rdfview_model(
    model_id      NUMBER,
    keep_r2rtab   BOOLEAN,
    truncate_model BOOLEAN default true
  );

  -- combines and replaces all the info in rows for a Tmap-G-refPred-PaTmap into a single row
  PROCEDURE replace_ref_prop_rows_with_agg(
    R2R_Tab_Name varchar2
  , options varchar2 default NULL
  );

  -- For a given Tmap, adds DB col info to RR tab rows with column-valued Omaps
  PROCEDURE add_DBColInfo_for_Tmap(
    model_id                  number
  , R2R_Tab_Name              varchar2
  , ltab_tabName              varchar2
  , ltab_Tmap                 varchar2
  , col_cnt                   number
  , desc_tbl                  dbms_sql.desc_tab3
  , Tmap_idx                  number
  , user_name                 varchar2
  , subj_template_prefix      varchar2
  , options                   varchar2 default NULL
  );

  PROCEDURE create_rdfview_model (
    model_name          IN  VARCHAR2
  , user_name           IN  VARCHAR2
  , map_type            OUT VARCHAR2
  , model_id            OUT NUMBER
  , schgraph_id         OUT NUMBER
  , R2R_Tab_Name        OUT VARCHAR2
  , gen_r2rml_tab_name  OUT VARCHAR2
  , gen_schema_tab_name OUT VARCHAR2
  , tables              IN  SYS.ODCIVarchar2List
  , prefix              IN  VARCHAR2 default NULL
  , r2rml_table_owner   IN  VARCHAR2 default NULL
  , r2rml_table_name    IN  VARCHAR2 default NULL
  , schema_table_owner  IN  VARCHAR2 default NULL
  , schema_table_name   IN  VARCHAR2 default NULL
  , options             IN  VARCHAR2 default NULL
  , r2rml_string        IN  CLOB CHARACTER SET ANY_CS default NULL
  , r2rml_string_fmt    IN  VARCHAR2 default NULL
  );

  -- loads RDFView schema from a given staging table into the (shallow) model for the RDFView
  PROCEDURE load_rdfview_schema (
    model_name           varchar2
  , map_type             varchar2
  , model_id             number
  , schgraph_id          number
  , R2R_Tab_Name         varchar2
  , gen_schema_tab_name  varchar2
  , schema_table_owner   varchar2
  , schema_table_name    varchar2
  , options              varchar2 default NULL
  );

  PROCEDURE drop_rdfview_model (model_name IN VARCHAR2, user_name IN VARCHAR2,
                                options IN VARCHAR2 default NULL);

  PROCEDURE drop_extended_stats;

  PROCEDURE gather_stats (just_on_values_table in boolean  default false,
                                        degree in number   default DBMS_STATS.AUTO_DEGREE,
                              estimate_percent in number   default DBMS_STATS.AUTO_SAMPLE_SIZE,
                              value_method_opt in varchar2 default null,
                               link_method_opt in varchar2 default null);

  PROCEDURE gather_rdf_stats;

  /**
   * Note only the owner of the model (or sys dba) is allowed
   * to gather statistics for the model.
   */
  PROCEDURE gather_model_stats (
    model_name     IN VARCHAR2
  , user_name      IN VARCHAR2
  , options        IN VARCHAR2 default NULL
  );
  /**
   * Note only the owner of the model (or sys dba) is allowed
   * to drop statistics for the model.
   */
  PROCEDURE drop_model_stats (
    model_name     IN VARCHAR2
  , user_name      IN VARCHAR2
  );

  PROCEDURE populate_crs_table;

  /**
   * Network compression-related methods
   */
  FUNCTION get_network_compression RETURN VARCHAR2;
  PROCEDURE set_network_compression (compress_val IN VARCHAR2);
  PROCEDURE clear_network_compression;
  FUNCTION extract_compress_option (options_str IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION get_link_compress_cmd (compress_flag IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION get_value_compress_cmd (compress_flag IN VARCHAR2) RETURN VARCHAR2;

  /**
   * NETWORK STATUS related methods
   */
  /***************************************************************************/
  /* clear_network_status                                                    */
  /***************************************************************************/
  PROCEDURE clear_network_status(options varchar2 default NULL);

  PROCEDURE create_rdf_network (
    user_name       in varchar2
  , tablespace_name in varchar2
  , roles_and_privs in varchar2
  , options         in varchar2 default null
  );

  PROCEDURE drop_rdf_network (
    user_name varchar2
  , roles_and_privs varchar2
  , cascade in boolean default false
  );
  PROCEDURE migrate_data_to_current (user_name in VARCHAR2, options in VARCHAR2 default NULL);

 PROCEDURE alter_rdf_indexes (
    attr_name IN varchar2
  , new_val   IN varchar2
  , options   IN varchar2 default null
  , roles_and_privs varchar2
  );

  PROCEDURE enable_inmemory (populate_wait in BOOLEAN, roles_and_privs varchar2);
  PROCEDURE disable_inmemory (roles_and_privs varchar2);

  /**
   * Note only rules index owner is allowed perform this action.Not all
   * parameters of dbms_stats.gather_table_stats makes sense here.
   */
  PROCEDURE analyze_rules_index(index_name IN VARCHAR2,
                          estimate_percent IN NUMBER,
                          method_opt       IN VARCHAR2,
                          degree           IN NUMBER,
                          cascade          IN BOOLEAN,
                          no_invalidate    IN BOOLEAN,
                          force            IN BOOLEAN DEFAULT FALSE
                         );

  /**
   * Note only rules index owner is allowed perform this action.Not all
   * parameters of dbms_stats.gather_table_stats makes sense here.
   */
  PROCEDURE analyze_model(model_name       IN VARCHAR2,
                          estimate_percent IN NUMBER,
                          method_opt       IN VARCHAR2,
                          degree           IN NUMBER,
                          cascade          IN BOOLEAN,
                          no_invalidate    IN BOOLEAN,
                          force            IN BOOLEAN DEFAULT FALSE
                         );

  /**
   * Note only model owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  PROCEDURE delete_model_stats(
      model_name       IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  /**
   * Note only model owner (or sys dba) is allowed perform this action. Not all
   * parameters of dbms_stats.delete_table_stats makes sense here.
   */
  PROCEDURE delete_rules_index_stats(
      index_name       IN VARCHAR2,
      cascade_parts    IN BOOLEAN  DEFAULT TRUE,
      cascade_columns  IN BOOLEAN  DEFAULT TRUE,
      cascade_indexes  IN BOOLEAN  DEFAULT TRUE,
      no_invalidate    IN BOOLEAN  DEFAULT DBMS_STATS.AUTO_INVALIDATE,
      force            IN BOOLEAN  DEFAULT FALSE
     );


  /**
   * This method will swap the names of two models.
   *
   * The input to this method are two model names. This method requires that the
   * current session user is the owner of both models.
   */
  PROCEDURE swap_model_names(m1  in VARCHAR2,
                             m2  in VARCHAR2);

  PROCEDURE rename_model(old_name  in VARCHAR2,
                         new_name  in VARCHAR2, user_id NUMBER);

  PROCEDURE rename_entailment(old_name  in VARCHAR2,
                              new_name  in VARCHAR2, user_name VARCHAR2);

  FUNCTION decode_index_code (
    idx_code VARCHAR2
  , flags    VARCHAR2 default NULL
  )
  RETURN VARCHAR2 DETERMINISTIC;

  PROCEDURE add_rdf_index (
    index_code      IN  VARCHAR
  , table_name      IN  VARCHAR2 default NULL
  , index_name_pfx  IN  VARCHAR2 default NULL
  , index_name_sfx  IN  VARCHAR2 default NULL
  , status          IN  VARCHAR2 default NULL
  , parallel        IN  PLS_INTEGER default NULL
  , online          IN  BOOLEAN default FALSE
  , tablespace_name IN  VARCHAR2 default NULL
  , compression_length IN  PLS_INTEGER default NULL
  , flags           IN  VARCHAR2 default NULL
  );

  PROCEDURE drop_rdf_index (
    index_code      IN   VARCHAR2
  , index_name_pfx  IN  VARCHAR2 default NULL
  , index_name_sfx  IN  VARCHAR2 default NULL
  );

  PROCEDURE add_datatype_index(
    datatype            IN VARCHAR2
  , user_name           IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  , options             IN VARCHAR2 default NULL
  );

  PROCEDURE drop_datatype_index(
    datatype            IN VARCHAR2
  , force_drop          IN BOOLEAN default FALSE
  );

  PROCEDURE alter_datatype_index(
    datatype            IN VARCHAR2
  , command             IN VARCHAR2
  , tablespace_name     IN VARCHAR2 default NULL
  , parallel            IN PLS_INTEGER default NULL
  , online              IN BOOLEAN default FALSE
  );

  PROCEDURE ddl_same_rdf_indexes (
    table_name           IN  VARCHAR2
  , modelID              IN  NUMBER
  , index_name_pfx       IN  VARCHAR2
  , index_name_sfx       IN  VARCHAR2
  , Event_Trace_Tabname  IN  VARCHAR2 default NULL
  , parallel             IN  PLS_INTEGER default NULL
  , online               IN  BOOLEAN default FALSE
  , status               IN  VARCHAR2 default NULL
  , operation            IN  VARCHAR2 default 'CREATE'
  , tablespace_name      IN  VARCHAR2 default NULL
  );

  PROCEDURE alter_index_on_rdf_graph (
    modelID          IN  NUMBER
  , index_code       IN  VARCHAR2
  , command          IN  VARCHAR2
  , parallel         IN  PLS_INTEGER default NULL
  , online           IN  BOOLEAN default FALSE
  , tablespace_name  IN  VARCHAR2 default NULL
  , rules_index_name IN  VARCHAR2 default NULL
  , use_compression  IN  BOOLEAN default NULL
  );

  PROCEDURE refresh_sem_network_index_info (
    model_id_list sys.ODCINumberList
  , roles_and_privs VARCHAR2
  , options       VARCHAR2 default NULL
  );

  PROCEDURE alter_rdf_graph (
    modelID          IN  NUMBER
  , command          IN  VARCHAR2
  , user_name        IN  VARCHAR2
  , tablespace_name  IN  VARCHAR2 default NULL
  , parallel         IN  PLS_INTEGER default NULL
  , rules_index_name IN  VARCHAR2 default NULL
  );

  PROCEDURE recreate_link_views(options  IN  VARCHAR2 default NULL);

  PROCEDURE recreate_rulebase_views (
    user_name IN VARCHAR2
  );

  PROCEDURE recreate_stats_partitions;

  PROCEDURE recreate_app_triggers;

  PROCEDURE recreate_meta_views (
    options  IN VARCHAR2 default NULL
  );

  PROCEDURE grant_pdb_dba_privs;

  PROCEDURE convert_old_rdf_data (
    log_level       IN PLS_INTEGER default 10
  , migrate         IN BOOLEAN     default TRUE
  , flags           IN VARCHAR2    default NULL
  , tablespace_name IN VARCHAR2    default NULL
  );

  PROCEDURE clear_net_data(user_name varchar2);

  FUNCTION encode_into_index_code (index_name VARCHAR2)
  RETURN VARCHAR2 DETERMINISTIC;

  PROCEDURE get_rdf_index_info (
    user_name IN VARCHAR2
  , flags     IN VARCHAR2 default NULL
  );

  FUNCTION uer2r (
    typ          varchar2
  , val          varchar2 CHARACTER SET ANY_CS
  , termType  IN varchar2
  , prefix    IN varchar2 CHARACTER SET ANY_CS default NULL
  , options   IN varchar2 default NULL
  ) return varchar2 CHARACTER SET val%CHARSET deterministic;
  --pragma restrict_references (uer2r,WNDS,RNDS,WNPS,RNPS);

  FUNCTION get_base_prefix_from_RR_table (col_val varchar2) RETURN varchar2 deterministic;
  pragma restrict_references (get_base_prefix_from_RR_table,WNDS,RNDS,WNPS,RNPS);

  FUNCTION get_col_name_from_RR_table (col_val varchar2) RETURN varchar2 deterministic;
  pragma restrict_references (get_col_name_from_RR_table,WNDS,RNDS,WNPS,RNPS);

  --
  -- A Private DEFINER right procedure that returns the partition name given
  -- a model name.
  --
  FUNCTION get_model_pname(model_name IN VARCHAR2) RETURN VARCHAR2;

  --=================== SEQUENCE adjustment related routines  =================--
  PROCEDURE adj_sequence_currval (seq_obj_name dbms_id, old_val number, new_val number);
  FUNCTION tgt_rdf_model_id_sq_nextval (owner_name dbms_id) RETURN number;
  FUNCTION tgt_rdf_rulebase_id_sq_nextval (owner_name dbms_id) RETURN number;
  FUNCTION tgt_rdf_hist_id_sq_nextval (owner_name dbms_id) RETURN number;
  FUNCTION tgt_rdf_long_lit_id_sq_nextval (owner_name dbms_id) RETURN number;

  --=================== EXPORT / IMPORT Procedures =================--
  -- Logic relocated from sdo_rdf_exp_imp to get around authid issues.
  -- Caller of sdo_rdf_exp_imp (invokers right) is not necessarily SYS,
  -- so MDSYS tables may be invisible to export/import user.
  --
  PROCEDURE system_callout (
    prepost        IN    PLS_INTEGER,
    version        IN    VARCHAR2
  );

  --********************************************************--
  -- Called for each registered instance during export
  -- Return action='EXPORT' for 12.1 target
  -- Need to skip or return pre-created Views for
  -- older targets for downgrade to work properly
  PROCEDURE instance_export_action (
          obj_name      IN   VARCHAR2,
          obj_schema    IN   VARCHAR2,
          obj_type      IN   NUMBER,
          tgt_version   IN   VARCHAR2,
          action        OUT  VARCHAR2,
          alt_name      OUT  VARCHAR2,
          where_clause  OUT  VARCHAR2
  );

  --*******************************************************--
  -- Called for each registered instance during import
  PROCEDURE instance_callout_imp (
             obj_name   IN   VARCHAR2,
             obj_schema IN   VARCHAR2,
             obj_type   IN   NUMBER,
             prepost    IN   PLS_INTEGER,
             action     OUT  VARCHAR2,
             alt_name   OUT  VARCHAR2
  );

  --******************************************************--
  -- Can do all fix up processing here when prepost=1
  PROCEDURE system_callout_imp (
             user_name  IN   VARCHAR2,
             prepost    IN   PLS_INTEGER
  );
  --================ End EXPORT / IMPORT Procedures ================--

END sdo_rdf_internal;
/

