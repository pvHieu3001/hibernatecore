create TYPE       SDO_GEOR_HISTOGRAM
                                                                      
AS OBJECT
(
   cellValue     SDO_NUMBER_ARRAY,
   count         SDO_NUMBER_ARRAY)
/

