create PACKAGE       SDO_CSW_INT AUTHID current_user AS

--------------------------------------------------------------------------------
-- Description:
-- This procedure optimizes the XML Query Full Text Index for Range Query by
-- first adding the prefix_ns_mapping, adding the sdata section, then setting the
-- sdata section to be opitimized for search.
-- Only the leaf XML elements (i.e., queryables/indexables) are listed.
-- These leaf XML elements (i.e., queryables/indexables) are for Summary mode and
-- they are listed in section 7.4.2 of OGC 07-045 document titled as
-- OpenGIS Catalogue Services Specification 2.0.2 - ISO Metadata Application Profile.
-- There is no limitation on the number of SDATA sections one can add. However,
-- if one XML element is only used for string equality comparison, there is no need
-- to add a SDATA section. The SDATA section is useful for range search like a > "foo", etc.
--------------------------------------------------------------------------------
    procedure opt_rq_for_summary
    (
        csw_xsd_id IN NUMBER
    );


--------------------------------------------------------------------------------
-- Populate in USER view of MDSYS.CSW_SERVICE_INFO (old name MDSYS.CSW_SCHEMANAME$)
--------------------------------------------------------------------------------
    procedure insert_user_sdo_cswserviceinfo
    (
        owner          IN VARCHAR2,
        csw_version    IN VARCHAR2,
        csw_xsd_id     IN NUMBER,
        csw_table_name IN VARCHAR2
    );


--------------------------------------------------------------------------------
-- Populate USER_SDO_GEOM_METADATA for USER CSW table if entry does not exist
--------------------------------------------------------------------------------
    procedure insert_user_sdo_geom_metadata
    (

        owner              IN VARCHAR2,
        new_csw_table_name IN VARCHAR2,
        new_column_name    IN VARCHAR2,
        diminfo            IN mdsys.sdo_dim_array,
        srid               IN number
    );


--------------------------------------------------------------------------------
-- Change USER_SDO_GEOM_METADATA for USER CSW table if entry exists
--------------------------------------------------------------------------------
    procedure change_user_sdo_geom_metadata
    (

       owner              IN VARCHAR2,
       old_csw_table_name IN VARCHAR2,
       old_column_name    IN VARCHAR2,
       new_csw_table_name IN VARCHAR2,
       new_column_name    IN VARCHAR2,
       diminfo            IN mdsys.sdo_dim_array,
       srid               IN number
    );



--------------------------------------------------------------------------------
-- Description:
-- This procedure prints SDO_GEOMETRY
--------------------------------------------------------------------------------
procedure print_geom(geom MDSYS.SDO_GEOMETRY);


--------------------------------------------------------------------------------
-- Description:
-- Private function to find whether fileIdentifier Element exists within an XML instance
-- If neither of the XPATHs /MD_Metadata/fileIdentifier, /gmd:MD_Metadata/gmd:fileIdentifier exist,
-- this function returns 0; otherwise returns the number of times the XPATH appears.
--------------------------------------------------------------------------------
/*
function find_fileidentifier_element
(
    xml_inst XMLType
)
RETURN NUMBER;
*/

--------------------------------------------------------------------------------
-- Description:
-- Private function to find whether an Element exists within an XML instance
-- If none of the XPATH(s) exist,
-- this function returns 0; otherwise returns the number of times the XPATH appears.
-- The lists have two elements: first without Namespace, the second with Namespace.
-- This is generic.
--------------------------------------------------------------------------------

function find_element
(
    xml_inst         XMLType,
    xpath_list       MDSYS.StringList,
    name_space_list  MDSYS.StringList
)
RETURN NUMBER;


--------------------------------------------------------------------------------
-- Description:
-- Private function to extract fileIdentifier Element from an XML instance
-- Due to calling sequence in generate_metadata_id procedure, it is guaranteed that
-- minimum 1 fileIdentifier element exists in the XML instance. However, this
-- function does not depend on such assumptions.
--------------------------------------------------------------------------------
/*
function extract_fileidentifier_element
(
    xml_inst XMLType
)
RETURN MDSYS.StringList;
*/

--------------------------------------------------------------------------------
-- Description:
-- Private function to extract an Element from an XML instance
-- Due to calling sequence in generate_metadata_id procedure, it is guaranteed that
-- minimum 1 seeking element exists in the XML instance. However, this
-- function does not depend on such assumptions.
-- CSW_XSD_ID parameter can only be 1, 2, 3 respectively for DCMI, ISO19139 and INSPIRE.
-- The lists have two elements: first without Namespace, the second with Namespace.
-- This is generic.
--------------------------------------------------------------------------------

function extract_element
(
    csw_xsd_id       NUMBER,
    xml_inst         XMLType,
    xpath_list       MDSYS.StringList,
    name_space_list  MDSYS.StringList
)
RETURN MDSYS.StringList;


--------------------------------------------------------------------------------
-- Description:
-- Private function to get next value from MDSYS.MD_identifier_sq$ sequence.
--
--------------------------------------------------------------------------------

function generate_md_identifier_sq
RETURN VARCHAR2;

END SDO_CSW_INT;
/

