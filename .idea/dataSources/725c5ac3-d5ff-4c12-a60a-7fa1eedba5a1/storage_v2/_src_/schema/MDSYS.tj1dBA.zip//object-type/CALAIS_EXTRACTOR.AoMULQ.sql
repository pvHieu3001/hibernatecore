create type calais_extractor under rdfctx_ws_extractor (

      constructor function calais_extractor (
                                      extr_params   sys.XMLType default null)
        return self as result,

      constructor function calais_extractor (
                                      ws_end_point  VARCHAR2,
                                      ws_soap_act   VARCHAR2,
                                      extr_params   sys.XMLType default null)
        return self as result,

      overriding member function extractRdf(document CLOB,
                                            docId    VARCHAR2) return CLOB

    )
/

