create TYPE SDO_NETWORK_MANAGER_I
  AUTHID current_user
  UNDER SDO_NETWORK_MANAGER_T
(
  ------------
  -- all_paths
  ------------
  STATIC FUNCTION all_paths_s(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    goal_node_id    NUMBER,
    depth_limit     NUMBER,
    cost_limit      NUMBER,
    no_of_solutions NUMBER,
    constraint      VARCHAR2
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.allPaths(
     java.lang.String,  oracle.sql.NUMBER, oracle.sql.NUMBER,
     oracle.sql.NUMBER, oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String)
     return oracle.spatial.type.SdoNumberArray',

  OVERRIDING MEMBER FUNCTION all_paths(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    goal_node_id    NUMBER,
    depth_limit     NUMBER,
    cost_limit      NUMBER,
    no_of_solutions NUMBER,
    constraint      VARCHAR2 :=NULL
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC,

  ----------------------------
  -- find_connected_components
  ----------------------------
  STATIC FUNCTION find_connected_components_s(
    net_mem   VARCHAR2
  )
    RETURN NUMBER DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.findConnectedComponents(
     java.lang.String) return oracle.sql.NUMBER',

  OVERRIDING MEMBER FUNCTION find_connected_components(
    net_mem   VARCHAR2
  )
    RETURN NUMBER DETERMINISTIC,

  -----------------------
  -- find_reachable_nodes
  -----------------------
  STATIC FUNCTION find_reachable_nodes_s(
    net_mem         VARCHAR2,
    source_node_id  NUMBER,
    constraint      VARCHAR2
  )
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.findReachableNodes(
     java.lang.String, oracle.sql.NUMBER, java.lang.String)
     return oracle.spatial.type.SdoNumberArray',

  OVERRIDING MEMBER FUNCTION find_reachable_nodes(
    net_mem   VARCHAR2, source_node_id NUMBER, constraint VARCHAR2 := NULL
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC,

  ------------------------
  -- find_reaching_nodes_s
  ------------------------
  STATIC FUNCTION find_reaching_nodes_s(
    net_mem VARCHAR2, target_node_id NUMBER, constraint VARCHAR2
  )
    RETURN SDO_NUMBER_ARRAY DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.findReachingNodes(
     java.lang.String, oracle.sql.NUMBER, java.lang.String)
     return oracle.spatial.type.SdoNumberArray',

  OVERRIDING MEMBER FUNCTION find_reaching_nodes(
    net_mem  VARCHAR2,  target_node_id   NUMBER, constraint VARCHAR2 := NULL
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC,

  ---------------
  -- is_reachable
  ---------------
  STATIC FUNCTION is_reachable_s(
    net_mem          VARCHAR2,
    source_node_id   NUMBER,
    target_node_id   NUMBER,
    constraint       VARCHAR2
  )
    RETURN VARCHAR2 DETERMINISTIC
    AS LANGUAGE JAVA NAME
      'oracle.spatial.type.NetworkWrapper.isReachable(
     java.lang.String, oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String)
     return java.lang.String',

  OVERRIDING MEMBER FUNCTION is_reachable(
    net_mem          VARCHAR2,
    source_node_id   NUMBER,
    target_node_id   NUMBER,
    constraint       VARCHAR2 := NULL
  ) RETURN VARCHAR2 DETERMINISTIC,

  -------------------------------------------------------------
  -- mcst_link: Minimal Cost Spanning Tree in the form of links
  -------------------------------------------------------------
  STATIC FUNCTION mcst_link_s(
    net_mem VARCHAR2
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.mcstLinkArray(java.lang.String)
     return oracle.spatial.type.SdoNumberArray',

  OVERRIDING MEMBER FUNCTION mcst_link(
    net_mem   VARCHAR2
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC,

  --------------------
  -- nearest_meighbors
  --------------------
  STATIC FUNCTION nearest_neighbors_s(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    no_of_neighbors NUMBER,
    constraint      VARCHAR2
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.nearestNeighbors(
     java.lang.String, oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String)
     return oracle.spatial.type.SdoNumberArray',

  OVERRIDING MEMBER FUNCTION nearest_neighbors(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    no_of_neighbors NUMBER,
    constraint      VARCHAR2 := NULL
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC,

  ----------------
  -- shortest_path
  ----------------
  STATIC FUNCTION shortest_path_s(net_map VARCHAR2,
    start_node_id NUMBER, goal_node_id NUMBER, constraint VARCHAR2
    ) RETURN NUMBER DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.shortestPath(
     java.lang.String, oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String)
     return oracle.sql.NUMBER',

  OVERRIDING MEMBER FUNCTION shortest_path(net_mem VARCHAR2,
      start_node_id NUMBER, goal_node_id NUMBER, constraint VARCHAR2 := NULL
    ) RETURN NUMBER DETERMINISTIC,

  -------------------------
  -- shortest_path_dijkstra
  -------------------------
  STATIC FUNCTION shortest_path_dijkstra_s(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    goal_node_id    NUMBER,
    constraint      VARCHAR2
  ) RETURN NUMBER DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.shortestPathDijkstra(
     java.lang.String, oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String)
     return oracle.sql.NUMBER',

  OVERRIDING MEMBER FUNCTION shortest_path_dijkstra(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    goal_node_id    NUMBER,
    constraint      VARCHAR2 := NULL
  ) RETURN NUMBER DETERMINISTIC,

  STATIC FUNCTION tsp_path_s(
    net_mem     VARCHAR2,  nd_array SDO_NUMBER_ARRAY,
    is_closed   VARCHAR2,  use_exact_cost   VARCHAR2, constraint VARCHAR2
  ) RETURN NUMBER DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.tspPath(
     java.lang.String, oracle.spatial.type.SdoNumberArray, java.lang.String,
     java.lang.String, java.lang.String)  return oracle.sql.NUMBER',

  OVERRIDING MEMBER FUNCTION tsp_path(
    net_mem   VARCHAR2,  nd_array  SDO_NUMBER_ARRAY,
    is_closed VARCHAR2,  use_exact_cost   VARCHAR2, constraint VARCHAR2 := NULL
  ) RETURN NUMBER DETERMINISTIC,

  --------------
  -- within_cost
  --------------
  STATIC FUNCTION within_cost_s(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    cost_limit      NUMBER,
    constraint      VARCHAR2
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.withinCost(
     java.lang.String, oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String)
     return oracle.spatial.type.SdoNumberArray',

  OVERRIDING MEMBER FUNCTION within_cost(
    net_mem         VARCHAR2,
    start_node_id   NUMBER,
    cost_limit      NUMBER,
    constraint      VARCHAR2 := NULL
  ) RETURN SDO_NUMBER_ARRAY DETERMINISTIC,
/*
  STATIC PROCEDURE create_logical_network_s(network_name VARCHAR2,
    no_of_hierarchy_levels NUMBER,   is_directed           VARCHAR2,
    node_table_name VARCHAR2,        node_cost_column      VARCHAR2,
    link_table_name VARCHAR2,        link_cost_column      VARCHAR2,
    path_table_name VARCHAR2,        path_link_table_name  VARCHAR2,
    is_complex VARCHAR2
  )
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.createLogicalNetwork(java.lang.String,
     oracle.sql.NUMBER, java.lang.String,
     java.lang.String, java.lang.String,
     java.lang.String, java.lang.String,
     java.lang.String, java.lang.String,
     java.lang.String)',
*/

  STATIC PROCEDURE  create_logical_network_s(network_name VARCHAR2,
    no_of_hierarchy_levels NUMBER,   is_directed           VARCHAR2,
    node_table_name VARCHAR2,        node_cost_column      VARCHAR2,
    link_table_name VARCHAR2,        link_cost_column      VARCHAR2,
    path_table_name VARCHAR2,        path_link_table_name  VARCHAR2,
    sub_path_table_name VARCHAR2,    is_complex VARCHAR2  )
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.createLogicalNetwork(java.lang.String,
     oracle.sql.NUMBER, java.lang.String,
     java.lang.String, java.lang.String,
     java.lang.String, java.lang.String,
     java.lang.String, java.lang.String,
     java.lang.String, java.lang.String)',

   OVERRIDING MEMBER PROCEDURE create_logical_network(network_name VARCHAR2,
     no_of_hierarchy_levels NUMBER,
     is_directed VARCHAR2,
     node_table_name VARCHAR2 DEFAULT NULL,
     node_cost_column VARCHAR2 DEFAULT NULL,
     link_table_name VARCHAR2 DEFAULT NULL,
     link_cost_column VARCHAR2  DEFAULT NULL,
     path_table_name VARCHAR2 DEFAULT NULL,
     path_link_table_name  VARCHAR2 DEFAULT NULL,
     sub_path_table_name VARCHAR2 DEFAULT NULL,
     is_complex VARCHAR2 DEFAULT 'FALSE'
   ) ,


  STATIC PROCEDURE create_lrs_network_s(
    network_name VARCHAR2,
    no_of_hierarchy_levels NUMBER,
    is_directed VARCHAR2,
    srid NUMBER,
    no_of_dims NUMBER,
    node_table_name VARCHAR2,
    node_cost_column VARCHAR2,
    link_table_name VARCHAR2,
    link_cost_column VARCHAR2,
    lrs_table_name  VARCHAR2,
    lrs_geom_column VARCHAR2,
    path_table_name VARCHAR2,
    path_geom_column VARCHAR2,
    path_link_table_name VARCHAR2,
    sub_path_table_name VARCHAR2,
    sub_path_geom_column VARCHAR2,
    is_complex VARCHAR2
     ) AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.createLRSNetwork(
      java.lang.String, oracle.sql.NUMBER, java.lang.String,
      oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String,
      java.lang.String, java.lang.String, java.lang.String,
      java.lang.String, java.lang.String, java.lang.String,
      java.lang.String, java.lang.String, java.lang.String,
      java.lang.String, java.lang.String)',

   OVERRIDING MEMBER PROCEDURE create_lrs_network(
    network_name VARCHAR2,
    no_of_hierarchy_levels NUMBER,
    is_directed VARCHAR2,
    srid NUMBER, no_of_dims NUMBER,
    node_table_name VARCHAR2 DEFAULT NULL,
    node_cost_column VARCHAR2 DEFAULT NULL,
    link_table_name VARCHAR2 DEFAULT NULL,
    link_cost_column VARCHAR2 DEFAULT NULL,
    lrs_table_name  VARCHAR2,
    lrs_geom_column VARCHAR2,
    path_table_name VARCHAR2 DEFAULT NULL,
    path_geom_column VARCHAR2 DEFAULT NULL,
    path_link_table_name VARCHAR2 DEFAULT NULL,
    sub_path_table_name VARCHAR2 DEFAULT NULL,
    sub_path_geom_column VARCHAR2 DEFAULT NULL,
    is_complex VARCHAR2 DEFAULT 'FALSE'
  ),

  STATIC PROCEDURE create_sdo_network_s(network_name VARCHAR2,
    no_of_hierarchy_levels NUMBER,
    is_directed VARCHAR2,
    srid NUMBER,
    no_of_dims NUMBER,
    node_table_name VARCHAR2, node_geom_column VARCHAR2,
    node_cost_column VARCHAR2, link_table_name VARCHAR2,
    link_geom_column VARCHAR2, link_cost_column VARCHAR2,
    path_table_name VARCHAR2, path_geom_column VARCHAR2,
    path_link_table_name VARCHAR2,
    sub_path_table_name VARCHAR2,
    sub_path_geom_column VARCHAR2,
    is_complex VARCHAR2
     ) AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.createSDONetwork(java.lang.String,
      oracle.sql.NUMBER, java.lang.String, oracle.sql.NUMBER,
      oracle.sql.NUMBER,  java.lang.String,
      java.lang.String, java.lang.String,
      java.lang.String, java.lang.String, java.lang.String,
      java.lang.String, java.lang.String, java.lang.String,
      java.lang.String, java.lang.String, java.lang.String)',

   OVERRIDING MEMBER PROCEDURE create_sdo_network(
    network_name VARCHAR2,
    no_of_hierarchy_levels NUMBER,
    is_directed VARCHAR2,
    srid NUMBER,
    no_of_dims NUMBER,
    node_table_name VARCHAR2 DEFAULT NULL,
    node_geom_column VARCHAR2 DEFAULT NULL,
    node_cost_column VARCHAR2 DEFAULT NULL,
    link_table_name VARCHAR2  DEFAULT NULL,
    link_geom_column VARCHAR2 DEFAULT NULL,
    link_cost_column VARCHAR2 DEFAULT NULL,
    path_table_name  VARCHAR2 DEFAULT NULL,
    path_geom_column VARCHAR2 DEFAULT NULL,
    path_link_table_name VARCHAR2 DEFAULT NULL,
    sub_path_table_name VARCHAR2 DEFAULT NULL,
    sub_path_geom_column VARCHAR2 DEFAULT NULL,
    is_complex VARCHAR2 DEFAULT 'FALSE'),

  ---------------
  -- read_network
  ---------------
  STATIC PROCEDURE read_network_s(
    net_mem  VARCHAR2,
    allow_updates VARCHAR2)
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.readMap(
     java.lang.String, java.lang.String)',

  OVERRIDING MEMBER PROCEDURE read_network(
    net_mem   VARCHAR2,
    allow_updates  VARCHAR2
  ),


  ------------
  -- list_networks
  ------------
  STATIC FUNCTION list_networks_s RETURN VARCHAR2 DETERMINISTIC
   AS LANGUAGE JAVA NAME
   'oracle.spatial.type.NetworkWrapper.listMaps()
    return java.lang.String',

  OVERRIDING MEMBER FUNCTION list_networks
   RETURN VARCHAR2 DETERMINISTIC,

  STATIC PROCEDURE write_network_s(net_mem VARCHAR2)
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.writeMap(java.lang.String)',

  OVERRIDING MEMBER PROCEDURE write_network(net_mem VARCHAR2),


  STATIC PROCEDURE drop_network_s(net_mem VARCHAR2)
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.dropMap(java.lang.String)',

  OVERRIDING MEMBER PROCEDURE drop_network(
    net_mem VARCHAR2),

  STATIC FUNCTION validate_network_schema_s(network VARCHAR2)
    RETURN VARCHAR2 DETERMINISTIC AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.validateNetworkSchema(
     java.lang.String)
    return java.lang.String',

  OVERRIDING MEMBER FUNCTION validate_network_schema(network VARCHAR2)
    RETURN VARCHAR2 DETERMINISTIC,

  STATIC PROCEDURE create_ref_constraints_s(network VARCHAR2)
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.createRefConstraints(
     java.lang.String)',

  OVERRIDING MEMBER PROCEDURE create_ref_constraints(network VARCHAR2),


  STATIC PROCEDURE enable_ref_constraints_s(network VARCHAR2)
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.enableRefConstraints(java.lang.String)',

  OVERRIDING MEMBER PROCEDURE enable_ref_constraints(network VARCHAR2),


  STATIC PROCEDURE disable_ref_constraints_s(network VARCHAR2)
    AS LANGUAGE JAVA NAME
    'oracle.spatial.type.NetworkWrapper.disableRefConstraints(
     java.lang.String)',

  OVERRIDING MEMBER PROCEDURE disable_ref_constraints(network VARCHAR2),

  --- register given network constraint into user_sdo_network_constraints
  OVERRIDING MEMBER PROCEDURE register_constraint(
    constraint_name VARCHAR2, class_name VARCHAR2,
    directory_name VARCHAR2,  description VARCHAR2),

  --- deregister given constraint from user_sdo_network_constraints
  OVERRIDING MEMBER PROCEDURE deregister_constraint(constraint_name VARCHAR2),

  MEMBER FUNCTION read_constraint(constraint_name VARCHAR2)
    RETURN VARCHAR2 DETERMINISTIC,

 STATIC PROCEDURE get_net_tab_names(net_mem IN VARCHAR2,
    link_tab_name OUT VARCHAR2, node_tab_name OUT VARCHAR2,
    path_tab_name OUT VARCHAR2, plink_tab_name OUT VARCHAR2),

 STATIC FUNCTION is_versioned_tab(tab_name IN VARCHAR2)
    RETURN BOOLEAN,

 STATIC FUNCTION is_versioned_s(net_mem IN VARCHAR2)
    RETURN BOOLEAN DETERMINISTIC,

 STATIC FUNCTION adjust_node_filter(tab_name IN VARCHAR2,
    sql_node_filter IN VARCHAR2, lock_id IN NUMBER)
  RETURN VARCHAR2,

 STATIC FUNCTION adjust_link_filter(tab_name IN VARCHAR2,
    node_filter IN VARCHAR2, sql_link_filter IN VARCHAR2, lock_id IN NUMBER)
  RETURN VARCHAR2,

 STATIC FUNCTION adjust_path_filter(path_tab IN VARCHAR2,
    plink_tab IN VARCHAR2, link_filter IN VARCHAR2,
    sql_path_filter IN VARCHAR2, lock_id IN NUMBER)
  RETURN VARCHAR2,

 STATIC PROCEDURE register_lock(lock_id IN NUMBER, net_mem IN VARCHAR2,
    wspace_name IN VARCHAR2, original_node_filter IN VARCHAR2,
    original_link_filter IN VARCHAR2, original_path_filter IN VARCHAR2,
    adjusted_node_filter IN VARCHAR2, adjusted_link_filter IN VARCHAR2,
    adjusted_path_filter IN VARCHAR2),

 STATIC PROCEDURE deregister_lock(lock_id IN NUMBER),

 STATIC FUNCTION get_lock_id
    RETURN NUMBER,

 STATIC PROCEDURE get_lock_info(lock_id IN NUMBER,
    net_mem OUT VARCHAR2, wspace_name OUT VARCHAR2,
    original_node_filter OUT VARCHAR2,
    original_link_filter OUT VARCHAR2, original_path_filter OUT VARCHAR2,
    adjusted_node_filter OUT VARCHAR2, adjusted_link_filter OUT VARCHAR2,
    adjusted_path_filter OUT VARCHAR2),

 OVERRIDING  MEMBER FUNCTION is_versioned_wm(net_mem IN VARCHAR2)
      RETURN BOOLEAN DETERMINISTIC,

 OVERRIDING  MEMBER PROCEDURE enable_versioning_wm(net_mem IN VARCHAR2),

 OVERRIDING  MEMBER PROCEDURE disable_versioning_wm(net_mem IN VARCHAR2),

 OVERRIDING  MEMBER FUNCTION lock_rows_wm(net_mem IN VARCHAR2,
    wspace_name IN VARCHAR2, sql_node_filter IN VARCHAR2 DEFAULT NULL,
    sql_link_filter IN VARCHAR2 DEFAULT NULL,
    sql_path_filter IN VARCHAR2 DEFAULT NULL)
    RETURN NUMBER DETERMINISTIC,

 OVERRIDING  MEMBER PROCEDURE unlock_rows_wm(net_mem IN VARCHAR2,
    wspace_name IN VARCHAR2, lock_id IN NUMBER) ,

  OVERRIDING MEMBER PROCEDURE read_network(
        net_mem         VARCHAR2,
        network         VARCHAR2,
        xmin            NUMBER,
        ymin            NUMBER,
        xmax            NUMBER,
        ymax            NUMBER,
        allow_updates   VARCHAR2),

   STATIC PROCEDURE read_network_s(
        net_mem         VARCHAR2,
        network         VARCHAR2,
        xmin            NUMBER,
        ymin            NUMBER,
        xmax            NUMBER,
        ymax            NUMBER,
        allow_updates   VARCHAR2)
      AS LANGUAGE JAVA NAME
      'oracle.spatial.type.NetworkWrapper.readMap(
       java.lang.String, java.lang.String, oracle.sql.NUMBER, oracle.sql.NUMBER,
      oracle.sql.NUMBER, oracle.sql.NUMBER, java.lang.String)',

  STATIC FUNCTION  get_default_value_s(
    parameter   VARCHAR2,
    default_val VARCHAR2) RETURN VARCHAR2

)
  ALTER TYPE SDO_NETWORK_MANAGER_I INSTANTIABLE CASCADE
/

