create function       SDO_Aggr_Union wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
92 be
9OdtXznwFtdo9QVGZMwVI96cajgwg+lKf8sVfC82Jk4Y1WvuHcOANG5WMcF9z9Fxvl8RrNu1
mfEbiQqI8DM99TNUiScW1rGB2oMz+X7qb3/n2jZsajteyw2x+OKkhfisBaKRpcmSF4Z3HXan
jNT8UugC8F7mq2k/G1kXQaPwxfWK6PjQxkNbWrM+zw==
/

