create TYPE       SDO_INTERACT_LINE_FEAT AS OBJECT (
        feature_layer_id  NUMBER,
        feature_id        NUMBER,
        feature_class_id  NUMBER,
        link_id           NUMBER,
        link_geom         MDSYS.SDO_GEOMETRY,
        start_node        MDSYS.SDO_INTERACT_POINT_FEAT,
        end_node          MDSYS.SDO_INTERACT_POINT_FEAT,
        bidirected        CHAR(1),
        intersection_location NUMBER,
        rule_side         CHAR(1),
        MAP MEMBER FUNCTION get_id RETURN VARCHAR2
       )
/

