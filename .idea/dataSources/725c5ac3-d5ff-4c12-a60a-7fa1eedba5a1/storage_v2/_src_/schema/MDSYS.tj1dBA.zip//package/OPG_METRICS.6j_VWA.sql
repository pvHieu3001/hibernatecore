create PACKAGE       opg_metrics authid current_user
AS
  --
  -- This function returns the number of triangles in a graph (denoted by its edge table/view)
  --
  function count_triangle_bind(
                          edge_tab_name  in varchar2,
                          num_ptns       in number default 1024, -- a positive integer, power of 2
                          part_id        in number default 6,    -- an integer in [0, num_ptns-1]
                          num_sub_ptns   in number default 1,    -- a positive integer, power of 2
                          dop            in number default 64,
                          use_outline    in number default 0,
                          s_id           in number default 0,     -- start ID
                          e_id           in number default 32767, -- end ID
                          wt_und         in varchar2 default null,-- a work table holding the single direction graph data
                          tablespace     in varchar2 default null,
                          options        in varchar2 default null
                         )
                         return number
  ;


  --
  -- This function returns the number of triangles in a graph (denoted by its edge table/view)
  --
  function count_triangle_bind_renum(
                          edge_tab_name in varchar2,
                          num_ptns      in number   default 1024, -- a positive integer, power of 2
                          part_id       in number   default 6,    -- an integer in [0, num_ptns-1]
                          num_sub_ptns  in number   default 1,    -- a positive integer, power of 2
                          dop           in number   default 64,
                          use_outline   in number   default 0,
                          s_id          in number   default 0,     -- start ID
                          e_id          in number   default 32767, -- end ID
                          wt_undBM      in varchar2,               -- undirected graph (before renum mapping)
                          wt_rnmap      in varchar2,               -- renum mapping table
                          wt_undAM      in varchar2,               -- undirected graph (after  renum mapping)
                          tablespace    in varchar2 default null,
                          options       in varchar2 default null
                         )
                         return number;

  --
  -- This function checks the range of the input dop value
  -- and normalize it to a proper string format
  --
  function process_dop(n integer) return varchar2;
END opg_metrics;
/

