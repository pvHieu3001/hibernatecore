create FUNCTION     "F$DATABASE_DOMAIN" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Database_Domain'); END;
/

